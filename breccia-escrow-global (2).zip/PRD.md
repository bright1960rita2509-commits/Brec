# Product Requirements Document (PRD): Breccia Escrow Global

## 1. Product Overview
**Breccia Escrow Global** is a secure, escrow-based African trade marketplace designed to build trust in cross-border and local trade. It addresses the "trust gap" in African commerce by providing a robust financial infrastructure that holds funds until milestones are met and verified.

## 2. Target Audience
*   **Importers/Buyers**: Need assurance that goods will be delivered as described before funds are released.
*   **Exporters/Sellers/Suppliers**: Need assurance that funds are secured in escrow before dispatching goods.
*   **Admins/Arbitrators**: Handle dispute resolution and platform compliance.

## 3. Core Functional Requirements
### 3.1 Authentication & Identity (IAM)
*   **Signup/Login**: JWT-based authentication with refresh token rotation.
*   **Role-Based Access Control (RBAC)**: Distinct interfaces and permissions for Buyer, Seller, and Admin.
*   **KYC/AML**: Document upload (CAC, ID, Utility bill) and verification workflow.

### 3.2 Escrow & Trade Lifecycle (State Machine)
*   **Trade Creation**: Sellers/Buyers draft trade terms.
*   **Funding**: Buyer deposits funds (Fiat/Crypto).
*   **Shipment/Dispatch**: Seller logs proof of dispatch (Bill of Lading, tracking).
*   **Inspection**: Buyer accepts delivery.
*   **Completion**: Funds released.
*   **Dispute Resolution**: Arbitrator intervention mechanism.

### 3.3 Financial Dashboard
*   **Wallet**: Balance overview (fiat/crypto), deposit/withdrawal logs.
*   **Transaction History**: Auditable records of all financial actions.

## 4. Technical Architecture (Production-Grade)
*   **Frontend**: React (or Next.js) with TailwindCSS, modular components, React Router.
*   **Backend**: Node.js/Express, TypeScript (as implemented).
*   **Database**: PostgreSQL managed via Prisma.
*   **Security**: JWT, RBAC, API rate-limiting, Helmet.js.
*   **Scalability**: Containerized Node/Express (ready for K8s deployment).

## 5. UI/UX Principles
*   **Stripe-like Aesthetic**: Clean, high-contrast, professional, minimalist.
*   **Responsive**: Mobile-first approach.
*   **State Management**: Explicit loading, error, and empty states.

## 6. Implementation Roadmap
1.  **Frontend Skeleton**: Mocked dashboards, navigation, auth screens.
2.  **Escrow Flow UI**: Visual tracking of trade stages.
3.  **Authentication**: Integration of JWT/Refresh flows.
4.  **Backend Swap**: Connect real APIs (Prisma/Express) to frontend components.
5.  **Payment Integration**: Final integration of real payment gateway abstractions (Stripe/Crypto RPC).
