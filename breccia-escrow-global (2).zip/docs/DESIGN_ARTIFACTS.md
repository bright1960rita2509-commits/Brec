# Breccia Platform Design Artifacts

## 1. Full Prisma Schema
*(The canonical source is /prisma/schema.prisma)*

## 2. ERD (Entity Relationship Diagram) - Conceptual
*   **Users** (1) -> (1) **KYC**
*   **Users** (1) -> (N) **Wallet**
*   **Users** (1) -> (N) **Dispute**
*   **Supplier** (1) -> (N) **Product**
*   **Wallet** (1) -> (N) **LedgerEntry**
*   **EscrowTransaction** (1) -> (1) **Dispute** (optional)

## 3. Wallet & Ledger Architecture
*   **Wallet**: Multi-currency container. One wallet record per user per currency (e.g., User A has one USD wallet, one NGN wallet).
*   **LedgerEntry**: Double-entry accounting system. Every transaction consists of matched Debit and Credit entries.
    *   *Deposit*: Credit User Wallet, Debit System Holding Account.
    *   *Escrow Funding*: Debit User Wallet, Credit Escrow Pool.
    *   *Escrow Release*: Debit Escrow Pool, Credit Supplier Wallet.

## 4. Escrow State Machine
1. `TRADE_CREATED` -> (Payment Made) -> `PAYMENT_RECEIVED`
2. `PAYMENT_RECEIVED` -> (Funds Locked) -> `ESCROW_FUNDED`
3. `ESCROW_FUNDED` -> (Supplier Accepts) -> `TRADE_ACTIVE`
4. `TRADE_ACTIVE` -> (Goods Shipped) -> `GOODS_SHIPPED`
5. `GOODS_SHIPPED` -> (Buyer Confirms) -> `GOODS_DELIVERED`
6. `GOODS_DELIVERED` -> (Escrow Release) -> `ESCROW_RELEASED` (Final)
*   *Dispute Path*: Any state -> `ESCROW_FROZEN` -> `ARBITRATION` -> `RESOLVED` (Refund or Release)

## 5. Payment Webhook Design
*   **Endpoint**: `POST /api/webhooks/payment/:provider`
*   **Validation**: Verify HMAC/Signature sent by provider (Paystack/Flutterwave/Stripe).
*   **Workflow**:
    1.  Receive payload.
    2.  Verify signature.
    3.  Acknowledge (Return 200).
    4.  Process payload (e.g., update `EscrowTransaction` status to `ESCROW_FUNDED`).
    5.  Trigger Ledger entries (Double-entry).
    6.  Notify User/Supplier.

## 6. API Specification Summary
### Auth
- `POST /api/auth/register` (Clerk-linked)
- `POST /api/auth/login`
### Marketplace
- `GET /api/products`
- `POST /api/products` (Supplier)
### Escrow
- `POST /api/escrow/create`
- `POST /api/escrow/:id/fund`
- `POST /api/escrow/:id/confirm-delivery`
### Webhooks
- `POST /api/webhooks/payment/:provider`
