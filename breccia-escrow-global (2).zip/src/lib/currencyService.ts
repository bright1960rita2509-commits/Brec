import { Currency } from '../types';

// Mock Exchange Rates
const RATES: Record<Currency, number> = {
  USD: 1,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 156.45,
  NGN: 1485.50,
  GHS: 14.20,
  ZAR: 18.50,
  BTC: 0.000015,
  ETH: 0.00028,
};

export const convertCurrency = (amount: number, from: Currency, to: Currency): number => {
  const amountInUsd = amount / RATES[from];
  return amountInUsd * RATES[to];
};
