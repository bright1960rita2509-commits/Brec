import { WorkflowTemplate } from '../types';

export const ESCROW_TEMPLATES: WorkflowTemplate[] = [
  {
    id: 'domain-transfer',
    name: 'Domain/Digital Asset Transfer',
    description: 'Specialized workflow for domain names and digital assets requiring registrar verification.',
    category: 'domain',
    requiredFields: ['domainName', 'registrar', 'authCode'],
    requiresOwnershipVerification: true,
  },
];
