// Mock Third-Party Marketplace API Integration
export interface MarketplaceListing {
  id: string;
  title: string;
  price: number;
  currency: string;
  source: string;
}

export const fetchMarketplaceListings = async (category: string): Promise<MarketplaceListing[]> => {
  // Simulate API call
  return [
    { id: '1', title: 'Premium Domain: breccia.io', price: 5000, currency: 'USD', source: 'Sedo' },
    { id: '2', title: 'Standard Service: Web Design', price: 1200, currency: 'USD', source: 'Fiverr' },
  ];
};
