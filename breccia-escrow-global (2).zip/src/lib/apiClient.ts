export const apiClient = {
  async getTransactions(userId: string) {
    const res = await fetch(`/api/transactions?userId=${userId}`);
    return res.json();
  },
  async createEscrow(data: any) {
    const res = await fetch('/api/escrow/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  // ... other methods
};
