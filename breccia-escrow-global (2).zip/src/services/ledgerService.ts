import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const ledgerService = {
  async createEntry(walletId: string, amount: number, type: 'DEBIT' | 'CREDIT', reference: string) {
    return prisma.ledgerEntry.create({
      data: {
        walletId,
        amount,
        type,
        reference,
      },
    });
  },
};
