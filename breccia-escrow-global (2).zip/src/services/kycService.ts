import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const kycService = {
  async updateVerification(userId: string, data: { status: boolean, type: 'CAC' | 'ID' | 'UTILITY', documentUrl?: string }) {
    const updateData: any = {};
    if (data.type === 'CAC') {
      updateData.cacVerified = data.status;
    } else if (data.type === 'ID') {
      updateData.idVerified = data.status;
    } else if (data.type === 'UTILITY') {
      updateData.utilityVerified = data.status;
    }
    if (data.documentUrl) {
      updateData.documentUrl = data.documentUrl;
    }

    return prisma.kyc.update({
      where: { userId },
      data: updateData,
    });
  },

  async getStatus(userId: string) {
    return prisma.kyc.findUnique({
      where: { userId },
    });
  }
};
