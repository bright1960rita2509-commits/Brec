import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const walletService = {
  async getWallet(userId: string, currency: string) {
    return prisma.wallet.findUnique({
      where: { userId_currency: { userId, currency } },
    });
  },

  async updateBalance(userId: string, currency: string, amount: number) {
    return prisma.wallet.update({
      where: { userId_currency: { userId, currency } },
      data: { balance: { increment: amount } },
    });
  },
};
