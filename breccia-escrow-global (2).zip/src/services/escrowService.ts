import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const escrowService = {
  async createTransaction(buyerId: string, sellerId: string, amount: number, currency: string) {
    return prisma.escrowTransaction.create({
      data: {
        buyerId,
        sellerId,
        amount,
        currency,
        status: 'TRADE_CREATED',
        milestoneStatus: 'PENDING',
      },
    });
  },

  async updateStatus(id: string, status: string) {
    return prisma.escrowTransaction.update({
      where: { id },
      data: { status },
    });
  },
};
