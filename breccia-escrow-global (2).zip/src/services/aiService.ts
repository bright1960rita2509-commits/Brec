export const aiService = {
  async analyzeRisk(userId: string, transactionAmount: number) {
    // Placeholder for AI-based fraud detection
    const riskScore = transactionAmount > 10000 ? 80 : 10;
    return { riskScore, riskLevel: riskScore > 50 ? 'HIGH' : 'LOW' };
  },
};
