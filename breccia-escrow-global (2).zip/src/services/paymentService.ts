export const paymentService = {
  // Mock initiation for Paystack
  async initiatePaystack(amount: number, email: string, reference: string) {
    // In production, call Paystack API
    console.log(`Initiating Paystack payment: ${amount} for ${email}, ref: ${reference}`);
    return { success: true, url: 'https://checkout.paystack.com/...' };
  },

  // Mock initiation for Flutterwave
  async initiateFlutterwave(amount: number, email: string, reference: string) {
    console.log(`Initiating Flutterwave payment: ${amount} for ${email}, ref: ${reference}`);
    return { success: true, url: 'https://checkout.flutterwave.com/...' };
  }
};
