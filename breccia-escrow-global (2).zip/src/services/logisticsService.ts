import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const logisticsService = {
  async createShipment(orderId: string, trackingNumber: string, carrier: string) {
    return prisma.shipment.create({
      data: { orderId, trackingNumber, carrier, status: 'CREATED' },
    });
  },

  async updateStatus(id: string, status: string) {
    return prisma.shipment.update({
      where: { id },
      data: { status },
    });
  },
};
