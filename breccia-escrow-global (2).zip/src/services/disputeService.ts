import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const disputeService = {
  async createDispute(complainantId: string, respondentId: string, evidence: string) {
    return prisma.dispute.create({
      data: { complainantId, respondentId, evidence, status: 'OPEN' },
    });
  },

  async resolveDispute(id: string, resolution: string) {
    return prisma.dispute.update({
      where: { id },
      data: { status: `RESOLVED: ${resolution}` },
    });
  },
};
