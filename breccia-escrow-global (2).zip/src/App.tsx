/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Shield, Landmark, Coins, Scale, HelpCircle, PhoneCall, Globe,
  ArrowUpRight, Heart, Users, CheckCircle2, MessageSquare, Flame 
} from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import EscrowStepTracker from './components/EscrowStepTracker';
import CryptoSection from './components/CryptoSection';
import Marketplace from './components/Marketplace';
import Dashboard from './components/Dashboard';
import UserSettings from './components/UserSettings';
import AboutContactFAQ from './components/AboutContactFAQ';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import { User, EscrowTransaction } from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeSection, setActiveSection] = useState<string>('home');
  const [authTab, setAuthTab] = useState<'login' | 'signup'>('signup');

  // Load authenticated session on mount from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('breccia_current_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (err) {
        console.error("Failed to parse local user session:", err);
      }
    }
  }, []);

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    setActiveSection('dashboard');
    toast.success('Successfully logged in.');
  };

  const handleLogout = () => {
    if (confirm("Disconnect from Breccia executive node?")) {
      localStorage.removeItem('breccia_current_user');
      setCurrentUser(null);
      setActiveSection('home');
      toast('Safely disconnected.', { icon: '👋' });
    }
  };

  const handleNavigate = (section: string) => {
    setActiveSection(section);
    
    // Smooth scroll support for main homepage sections
    setTimeout(() => {
      let targetElement = document.getElementById(section);
      if (section === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 50);
  };

  const handleOpenAuthFromNav = (tab: 'login' | 'signup') => {
    setAuthTab(tab);
    handleNavigate('home');
    // Focus or flash auth container
    setTimeout(() => {
      const authBox = document.getElementById('auth-sidebar-root');
      if (authBox) {
        authBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        authBox.classList.add('border-gold-accent');
        setTimeout(() => authBox.classList.remove('border-gold-accent'), 1500);
      }
    }, 100);
  };

  // Direct trigger to start predefined escrow deals from marketplace
  const handleStartMarketplaceEscrow = (supplierName: string, amount: number, initialTerms: string) => {
    if (!currentUser) {
      toast.error("Sign in to access Breccia's transaction protection dashboard.");
      handleOpenAuthFromNav('signup');
      return;
    }

    const newDeal: EscrowTransaction = {
      id: "BRC-" + Math.floor(1000 + Math.random() * 9000),
      title: `Bulk Sourcing Settle - Exporter: ${supplierName}`,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      sellerId: "u_exporter_gen",
      sellerName: supplierName,
      amount: amount,
      currency: "USD",
      paymentMethod: "crypto",
      status: "unfunded",
      terms: initialTerms,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      documents: []
    };

    const savedDeals: EscrowTransaction[] = JSON.parse(localStorage.getItem('breccia_transactions') || '[]');
    localStorage.setItem('breccia_transactions', JSON.stringify([newDeal, ...savedDeals]));

    toast.success(`Pre-configured deal created with Exporter ${supplierName}! Loading checkout desk...`);
    handleNavigate('dashboard');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-stone-250 flex flex-col selection:bg-gold-accent/20 selection:text-gold-accent">
      <Toaster 
        position="bottom-center" 
        toastOptions={{
          style: {
            background: '#1a1a1a',
            color: '#c4a661',
            border: '1px solid rgba(196, 166, 97, 0.2)',
            fontFamily: 'monospace',
            fontSize: '12px',
          },
        }} 
      />
      {/* Universal Top Navigation */}
      <Navigation
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenAuth={handleOpenAuthFromNav}
        activeSection={activeSection}
        onNavigate={handleNavigate}
      />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 space-y-20 z-10">
        <AnimatePresence mode="wait">
        {activeSection === 'dashboard' && currentUser ? (
          /* Render complete Multi-Mode Dashboard Workspace directly */
          <motion.div 
            key="dashboard"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <Dashboard 
              currentUser={currentUser}
              onLogout={handleLogout}
              onNavigate={handleNavigate}
            />
          </motion.div>
        ) : activeSection === 'settings' && currentUser ? (
          /* Render KYC & User Settings Workspace */
          <motion.div 
            key="settings"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="min-h-[70vh]"
          >
            <UserSettings />
          </motion.div>
        ) : (
          /* Render Homepage stacked panels sheet */
          <motion.div 
            key="home"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-24"
          >
            
            {/* 1. Hero segment with inline login/signup */}
            <section id="home">
              <Hero
                onAuthSuccess={handleAuthSuccess}
                onNavigate={handleNavigate}
                onOpenAuth={handleOpenAuthFromNav}
              />
            </section>

            {/* 2. Premium Analytics and Stats strip (Matches the graphic directly!) */}
            <section id="trust-metrics" className="py-2">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 bg-neutral-950/70 p-6 md:p-8 rounded-2xl border border-gold-400/10">
                
                <div className="flex items-center gap-4 text-left">
                  <div className="w-10 h-10 rounded-lg bg-gold-accent/5 border border-gold-400/10 flex items-center justify-center flex-shrink-0">
                    <Shield className="w-5 h-5 text-gold-accent" />
                  </div>
                  <div>
                    <span className="block font-display font-black text-lg md:text-xl text-gold-gradient">$250M+</span>
                    <span className="block text-[10px] font-mono tracking-wider uppercase text-zinc-500">Total Value Secured</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-left border-l border-neutral-905 pl-4 md:pl-6">
                  <div className="w-10 h-10 rounded-lg bg-gold-accent/5 border border-gold-400/10 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-gold-accent" />
                  </div>
                  <div>
                    <span className="block font-display font-black text-lg md:text-xl text-gold-gradient">10,000+</span>
                    <span className="block text-[10px] font-mono tracking-wider uppercase text-zinc-500">Successful Transactions</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-left border-l border-neutral-905 pl-4 md:pl-6">
                  <div className="w-10 h-10 rounded-lg bg-gold-accent/5 border border-gold-400/10 flex items-center justify-center flex-shrink-0">
                    <Globe className="w-5 h-5 text-gold-accent" />
                  </div>
                  <div>
                    <span className="block font-display font-black text-lg md:text-xl text-gold-gradient">150+</span>
                    <span className="block text-[10px] font-mono tracking-wider uppercase text-zinc-500">Countries Supported</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-left border-l border-neutral-905 pl-4 md:pl-6">
                  <div className="w-10 h-10 rounded-lg bg-gold-accent/5 border border-gold-400/10 flex items-center justify-center flex-shrink-0">
                    <Coins className="w-5 h-5 text-gold-accent" />
                  </div>
                  <div>
                    <span className="block font-display font-black text-lg md:text-xl text-gold-gradient">99.99%</span>
                    <span className="block text-[10px] font-mono tracking-wider uppercase text-zinc-500">Security Guarantee</span>
                  </div>
                </div>

              </div>
            </section>

            {/* 3. Sourcing Opportunities & Exporter Board */}
            <section id="marketplace">
              <Marketplace onStartEscrow={handleStartMarketplaceEscrow} />
            </section>

            {/* 4. Crypto Payment Alternate checkout (Simulates deposits) */}
            <section id="escrow-promo">
              <CryptoSection />
            </section>

            {/* 5. How Escrow Works */}
            <section id="how-it-works">
              <EscrowStepTracker />
            </section>

            {/* 6. Administrative Portal Quick Access (Allows demo auditing easily!) */}
            <section id="admin-quicklink" className="py-2 border-t border-neutral-900/40">
              <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 bg-neutral-950/40 text-left space-y-4">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <span className="text-[10px] font-mono text-gold-accent uppercase font-bold tracking-widest block">ADMINISTRATIVE TRANSPARENCY DECK</span>
                    <h3 className="font-display font-bold text-lg text-white mt-0.5">Explore Breccia's Compliance and Arbitration Office</h3>
                    <p className="text-zinc-500 text-xs font-sans mt-0.5">To maintain deep transparency for cross-border transactions, legal compliance logs and dispute files are publicly auditable here.</p>
                  </div>
                  <button
                    onClick={() => handleNavigate('admin')}
                    className="px-5 py-2 border border-gold-400/20 text-gold-accent hover:border-gold-accent hover:bg-gold-accent/5 text-xs font-mono tracking-wider font-extrabold rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    Enter Arbitrator Console
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </section>

            {/* 7. Special Admin Panel direct inject */}
            {activeSection === 'admin' && (
              <section id="admin" className="p-6 rounded-3xl bg-neutral-950/60 border border-gold-400/15">
                <AdminPanel />
              </section>
            )}

            {/* 8. About Us, Testimonials, FAQ & Support Desk */}
            <section id="about">
              <AboutContactFAQ />
            </section>

          </motion.div>
        )}
        </AnimatePresence>
      </main>

      {/* Global Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
