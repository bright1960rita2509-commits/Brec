/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'buyer' | 'seller' | 'supplier' | 'importer' | 'admin' | 'dispute_officer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  companyName?: string;
  verificationStatus: 'unverified' | 'pending' | 'verified';
  kycCompleted: boolean;
  twoFactorEnabled: boolean;
  joinDate: string;
}

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'NGN' | 'GHS' | 'ZAR' | 'BTC' | 'ETH';

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: 'domain' | 'service' | 'good' | 'vehicle' | 'other';
  requiredFields: string[];
  requiresOwnershipVerification: boolean;
}

export type EscrowStatus = 
  | 'unfunded' 
  | 'funded' 
  | 'dispatched' 
  | 'delivered' 
  | 'completed' 
  | 'cancelled' 
  | 'disputed';

export interface Milestone {
  id: string;
  title: string;
  description: string;
  amount: number;
  status: 'pending' | 'funded' | 'completed';
}

export interface EscrowTransaction {
  id: string;
  title: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  amount: number;
  currency: Currency;
  paymentMethod: 'crypto' | 'bank_transfer' | 'card' | 'wire' | 'rise' | 'paystack' | 'flutterwave' | 'binance_pay';
  status: EscrowStatus;
  terms: string;
  shippingTrackingUrl?: string;
  shippingTrackingNumber?: string;
  shippingCarrier?: string;
  paymentProofUrl?: string;
  paymentProofStatus?: 'pending' | 'verifying' | 'verified' | 'rejected';
  escrowFeeAmount: number;
  verificationFeeAmount: number;
  buyerVerified: boolean;
  supplierVerified: boolean;
  warehousingVerified: boolean;
  productQualityVerified: boolean;
  createdAt: string;
  category?: 'domain' | 'service' | 'good' | 'vehicle' | 'other';
  updatedAt: string;
  documents: { name: string; url: string; uploadedAt: string }[];
  milestones?: Milestone[];
  buyerSigned?: { username: string; signedAt: string } | null;
  sellerSigned?: { username: string; signedAt: string } | null;
}

export interface SupplierProfile {
  id: string;
  companyName: string;
  country: string;
  category: 'Agriculture' | 'Manufacturing' | 'Natural Resources' | 'Professional Services' | 'Wholesale';
  description: string;
  products: { id: string; name: string; price: string; minOrder: string }[];
  verificationBadge: boolean;
  rating: number;
  exportCapability: string;
}

export interface RequestForQuotation {
  id: string;
  importerName: string;
  importerEmail: string;
  productName: string;
  category: string;
  quantity: string;
  targetPrice?: string;
  details: string;
  status: 'pending' | 'responded' | 'accepted';
  responses?: { supplierName: string; quotePrice: string; timeline: string }[];
}

export interface Dispute {
  id: string;
  transactionId: string;
  transactionTitle: string;
  amount: number;
  raisedBy: string;
  reason: string;
  status: 'open' | 'negotiating' | 'under_review' | 'evidence_gathering' | 'arbitrator_assessment' | 'resolved_buyer' | 'resolved_seller' | 'closed';
  priority?: 'Low' | 'Medium' | 'High';
  assignedTo?: string;
  createdAt: string;
  chatHistory: { sender: string; text: string; time: string }[];
  auditLog: { timestamp: string; action: string; actor: string }[];
  documentIds?: string[];
}

export interface Document {
  id: string;
  transactionId?: string;
  title: string;
  type: 'Invoice' | 'Inspection' | 'Legal' | 'Other';
  uploadDate: string;
  size: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  text: string;
  timestamp: string;
}
