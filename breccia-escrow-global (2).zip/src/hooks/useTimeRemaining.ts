import { useMemo } from 'react';

export function useTimeRemaining(createdAt: string, durationDays: number = 30) {
  return useMemo(() => {
    if (!createdAt) return { daysRemaining: 0, isNearingExpiration: false, display: 'Unknown' };
    
    // Parse the creation date
    const start = new Date(createdAt);
    if (isNaN(start.getTime())) {
      return { daysRemaining: 0, isNearingExpiration: false, display: 'Invalid Date' };
    }
    
    // Calculate the expiration date
    const expirationDate = new Date(start.getTime() + durationDays * 24 * 60 * 60 * 1000);
    const now = new Date();
    
    // Calculate time difference in ms
    const diffMs = expirationDate.getTime() - now.getTime();
    
    const daysRemaining = Math.ceil(diffMs / (24 * 60 * 60 * 1000));
    
    const isNearingExpiration = daysRemaining <= 5 && daysRemaining > 0;
    
    let display = '';
    if (daysRemaining > 0) {
      display = `${daysRemaining} day${daysRemaining > 1 ? 's' : ''} left`;
    } else {
      display = 'Expired';
    }
    
    return {
      daysRemaining,
      isNearingExpiration,
      display
    };
  }, [createdAt, durationDays]);
}
