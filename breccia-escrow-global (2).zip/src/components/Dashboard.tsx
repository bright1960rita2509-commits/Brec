/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Plus, Handshake, ShieldCheck, Wallet, ArrowUpRight, Scale, FileText, 
  Send, Users, HelpCircle, Eye, RefreshCw, CloudCheck, Truck, Clock, Upload
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { User, UserRole, EscrowTransaction, Dispute } from '../types';
import CryptoSection from './CryptoSection';
import TradeCostCalculator from './TradeCostCalculator';
import ShipmentTracker from './ShipmentTracker';
import InvoiceGenerator from './InvoiceGenerator';
import TradeAnalytics from './TradeAnalytics';
import TransactionChat from './TransactionChat';
import TrustScoreWidget from './TrustScoreWidget';
import ArbitratorChatOverlay from './ArbitratorChatOverlay';
import PrintableSummary from './PrintableSummary';
import { useTimeRemaining } from '../hooks/useTimeRemaining';
import { DisputeInitiator } from './DisputeInitiator';
import { DigitalSignature } from './DigitalSignature';

function DeadlineBadge({ tx }: { tx: EscrowTransaction }) {
  const { isNearingExpiration, display } = useTimeRemaining(tx.createdAt, 14); // 14 days expiration
  
  if (tx.status === 'completed' || tx.status === 'cancelled') return null;
  
  if (isNearingExpiration) {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/30 px-2 py-0.5 rounded font-mono font-bold ml-2">
        <Clock className="w-3 h-3" />
        DEADLINE: {display.toUpperCase()}
      </span>
    );
  } else {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] bg-neutral-900 text-neutral-500 border border-neutral-800 px-2 py-0.5 rounded font-mono ml-2">
        {display}
      </span>
    );
  }
}


interface DashboardProps {
  currentUser: User;
  onLogout: () => void;
  onNavigate: (section: string) => void;
}

export default function Dashboard({ currentUser: initialUser, onLogout, onNavigate }: DashboardProps) {
  // Demo simulation mode user role overrides
  const [currentUser, setCurrentUser] = useState<User>(initialUser);
  const [roleMode, setRoleMode] = useState<UserRole>(initialUser.role);

  // Escrows list synced to localStorage so changes reflect across refreshes
  const [transactions, setTransactions] = useState<EscrowTransaction[]>(() => {
    const saved = localStorage.getItem('breccia_transactions');
    if (saved) {
      const parsed = JSON.parse(saved);
      return parsed.map((t: any) => ({
        ...t,
        escrowFeeAmount: t.escrowFeeAmount || t.amount * 0.02,
        verificationFeeAmount: t.verificationFeeAmount || 500,
        buyerVerified: t.buyerVerified || false,
        supplierVerified: t.supplierVerified || false,
        warehousingVerified: t.warehousingVerified || false,
        productQualityVerified: t.productQualityVerified || false
      }));
    }

    // Initial seed transactions representing robust trade
    return [
      {
        id: "BRC-901A",
        title: "20 Metric Tons Unwashed White Sesame Bulks",
        buyerId: "u_buyer",
        buyerName: "Aliko Importer",
        sellerId: "u_supplier",
        sellerName: "Mombasa Cocoa Exporters",
        amount: 33000,
        currency: "USD",
        paymentMethod: "crypto",
        status: "funded",
        terms: "Cargo compliance standard SGS moisture index strict maximum of 7.0%. Disbursed in Tema Port.",
        createdAt: "2026-05-24",
        updatedAt: "2026-05-25",
        documents: [
          { name: "SGS_Moisture_Report_Tema.pdf", url: "#", uploadedAt: "2026-05-25" }
        ],
        escrowFeeAmount: 660,
        verificationFeeAmount: 500,
        buyerVerified: false,
        supplierVerified: false,
        warehousingVerified: false,
        productQualityVerified: false
      },
      {
        id: "BRC-774X",
        title: "Grade A Sun-Dried Cashew Kernels",
        buyerId: "u_buyer",
        buyerName: "Aliko Importer",
        sellerId: "u_seller",
        sellerName: "Ibadan Cotton & Textiles Corp",
        amount: 12500,
        currency: "USD",
        paymentMethod: "bank_transfer",
        status: "completed",
        terms: "Direct delivery to Lagos Apapa warehouse dock. Moisture holds under 8.0%.",
        createdAt: "2026-04-10",
        updatedAt: "2026-04-14",
        documents: [],
        escrowFeeAmount: 250,
        verificationFeeAmount: 500,
        buyerVerified: true,
        supplierVerified: true,
        warehousingVerified: true,
        productQualityVerified: true
      }
    ];
  });

  // Role switching mock helper so reviewers can easily checkout everything
  const handleRoleOverride = (role: UserRole) => {
    const freshUser: User = {
      ...currentUser,
      role: role,
      name: role === 'buyer' ? "Aliko Importer" :
            role === 'seller' ? "Zahara Fabric Corp" :
            role === 'supplier' ? "Mombasa Export Traders" :
            role === 'importer' ? "EuroSourcing GMBH" :
            role === 'admin' ? "Chidi Nwachukwu (Escrow Admin)" : "Lydia Tembo (Dispute Officer)",
      verificationStatus: "verified"
    };
    setRoleMode(role);
    setCurrentUser(freshUser);
    localStorage.setItem('breccia_current_user', JSON.stringify(freshUser));
  };

  useEffect(() => {
    localStorage.setItem('breccia_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const filteredTransactions = transactions.filter(tx => {
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = 
      tx.id.toLowerCase().includes(searchLower) ||
      tx.title.toLowerCase().includes(searchLower) ||
      tx.buyerName.toLowerCase().includes(searchLower) ||
      tx.sellerName.toLowerCase().includes(searchLower);
    
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Compatibility Score Algorithm
  const calculateCompatibilityScore = (buyer: User, seller: SupplierProfile, transactions: EscrowTransaction[]) => {
    let score = 0;
    
    // Rating (0-5)
    score += seller.rating * 10;
    
    // Historical transaction matches (if they have dealt before)
    const previousDeals = transactions.filter(t => t.buyerId === buyer.id && t.sellerId === seller.id);
    score += previousDeals.length * 5;
    
    // Capacity check (naive) - assuming transaction history suggests capacity
    const avgDealSize = transactions.filter(t => t.buyerId === buyer.id).reduce((acc, t) => acc + t.amount, 0) / (transactions.filter(t => t.buyerId === buyer.id).length || 1);
    
    // Compare avg deal with seller's general offerings if possible
    // For now keep it simple and cap at 100
    return Math.min(score, 100);
  };

  // Escrow Creator wizard state
  const [dealTitle, setDealTitle] = useState('');
  const [dealPartner, setDealPartner] = useState('');
  const [dealAmount, setDealAmount] = useState('15000');
  const [dealCurrency, setDealCurrency] = useState<'USD' | 'EUR' | 'NGN' | 'GHS' | 'ZAR'>('USD');
  const [dealTerms, setDealTerms] = useState('');
  const [dealPaymentMethod, setDealPaymentMethod] = useState<EscrowTransaction['paymentMethod']>('crypto');
  const [showCreator, setShowCreator] = useState(false);

  // Escrow funding popup state
  const [fundingTx, setFundingTx] = useState<EscrowTransaction | null>(null);

  const handleUploadProof = (txId: string, file: File) => {
    setTransactions(prev => prev.map(t => {
      if (t.id === txId) {
        return { 
          ...t, 
          paymentProofUrl: URL.createObjectURL(file),
          paymentProofStatus: 'verifying'
        };
      }
      return t;
    }));
    
    // Simulate scan
    setTimeout(() => {
        setTransactions(prev => prev.map(t => {
            if (t.id === txId) {
                return { ...t, paymentProofStatus: 'verified' };
            }
            return t;
        }));
    }, 2500);
  };

  // Gemini AI Contract compiler states
  const [draftingTxs, setDraftingTxs] = useState<EscrowTransaction | null>(null);
  const [draftedContract, setDraftedContract] = useState('');
  const [draftingLoading, setDraftingLoading] = useState(false);

  // Exporter profiles states
  const [exporterPort, setExporterPort] = useState('Apapa Lagos Port');
  const [exporterTons, setExporterTons] = useState('1,500 Tons');
  const [profileSuccess, setProfileSuccess] = useState('');

  // Shipping container uploader states
  const [shippingTx, setShippingTx] = useState<EscrowTransaction | null>(null);
  const [trackingNumber, setTrackingNumber] = useState('');
  const [bolName, setBolName] = useState('');

  // Active chat state for single transactions
  const [activeChatTxId, setActiveChatTxId] = useState<string | null>(null);
  const [downloadLogs, setDownloadLogs] = useState<{ txId: string; title: string; timestamp: string }[]>([]);
  const [exportTx, setExportTx] = useState<EscrowTransaction | null>(null);

  const addDownloadLog = (txId: string, title: string) => {
    setDownloadLogs(prev => [...prev, { txId, title, timestamp: new Date().toLocaleString() }]);
  };

  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Recommendation logic
  const getRecommendedMatches = () => {
    // Mock list of potential suppliers
    const mockSuppliers: SupplierProfile[] = [
        { id: "s1", companyName: "Mombasa Cocoa Exporters", country: "Kenya", category: "Agriculture", description: "Cocoa exports", products: [], verificationBadge: true, rating: 4.8, exportCapability: "High" },
        { id: "s2", companyName: "Ibadan Cotton & Textiles Corp", country: "Nigeria", category: "Agriculture", description: "Cotton exports", products: [], verificationBadge: true, rating: 4.5, exportCapability: "Medium" }
    ];

    return mockSuppliers
        .map(seller => ({ seller, score: calculateCompatibilityScore(currentUser, seller, transactions) }))
        .sort((a,b) => b.score - a.score);
  };
  const recommendations = getRecommendedMatches();

  // Sourcing matcher state
  const [sourcingPrompt, setSourcingPrompt] = useState('List five verified organic cocoa farm co-operatives near Kumasi Ghana that accept SGS testing and draft pre-sourcing terms.');
  const [sourcingGuide, setSourcingGuide] = useState('');
  const [sourcingLoading, setSourcingLoading] = useState(false);

  const handleCreateEscrow = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dealTitle || !dealPartner) return;

    const amount = parseFloat(dealAmount) || 5000;
    const escrowFeeAmount = amount * 0.02; // 2% fee
    const verificationFeeAmount = 500; // Flat fee

    const newDeal: EscrowTransaction = {
      id: "BRC-" + Math.floor(1000 + Math.random() * 9000) + Math.random().toString(36).substring(2, 4).toUpperCase(),
      title: dealTitle,
      buyerId: roleMode === 'buyer' ? currentUser.id : "u_buyer",
      buyerName: roleMode === 'buyer' ? currentUser.name : "Importer Sourcing Corp Ltd",
      sellerId: "u_exporter_random",
      sellerName: dealPartner,
      amount: amount,
      currency: dealCurrency,
      paymentMethod: dealPaymentMethod,
      status: 'unfunded',
      terms: dealTerms || "Standard Breccia protective escrow settlement rules apply. Release demands physical certificate inspect validation.",
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      documents: [],
      escrowFeeAmount: escrowFeeAmount,
      verificationFeeAmount: verificationFeeAmount,
      buyerVerified: false,
      supplierVerified: false,
      warehousingVerified: false,
      productQualityVerified: false
    };

    setTransactions([newDeal, ...transactions]);
    setDealTitle('');
    setDealPartner('');
    setDealTerms('');
    setShowCreator(false);
    toast.success("Draft escrow agreement successfully initiated.");
  };

  const handleTriggerPay = (tx: EscrowTransaction) => {
    setFundingTx(tx);
  };

  const handleSign = (txId: string) => {
    setTransactions(prev => prev.map(t => {
        if (t.id === txId) {
            const now = new Date().toLocaleString();
            if (currentUser.role === 'buyer') {
                return { ...t, buyerSigned: { username: currentUser.name, signedAt: now } };
            } else if (currentUser.role === 'seller') {
                return { ...t, sellerSigned: { username: currentUser.name, signedAt: now } };
            }
        }
        return t;
    }));
  };

  const handlePaymentSuccess = (amountPaid: number, coinUsed: string) => {
    if (!fundingTx) return;

    const updated = transactions.map(t => {
      if (t.id === fundingTx.id) {
        return {
          ...t,
          status: 'funded' as const,
          updatedAt: new Date().toISOString().split('T')[0],
          terms: `${t.terms} [Funded with equivalent ${amountPaid} USD via ${coinUsed} on ${new Date().toLocaleDateString()}]`
        };
      }
      return t;
    });

    setTransactions(updated);
    setFundingTx(null);
    toast.success(`Success! Trade capital of ${fundingTx.amount} USD has been successfully secured in escrow.`);
  };

  const handleDraftAIRules = async (tx: EscrowTransaction) => {
    setDraftingTxs(tx);
    setDraftingLoading(true);
    setDraftedContract('');
    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: `Draft a formal legal sales contract for Escrow Deal: ${tx.id}. Seller/Exporter: ${tx.sellerName}. Buyer: ${tx.buyerName}. Total sum: $${tx.amount.toLocaleString()} USD. Sourcing Specific Terms: "${tx.terms}"`,
          type: "contract"
        }),
      });
      const data = await response.json();
      setDraftedContract(data.text);
    } catch (err) {
      setDraftedContract(`### BRECCIA ESCROW CONTRACT DEED\n\n**CONTRACT REF:** ${tx.id}\n**BUYER:** ${tx.buyerName}\n**EXPORTER:** ${tx.sellerName}\n\n#### 1. Covenant of Escrow\nThis Agreement is created electronically under Breccia's cross-border trade legal framework. Importer hereby binds $${tx.amount.toLocaleString()} USD inside the electronic vault.\n\n#### 2. Specific Conditions for Clearance\n- Quality standard: SGS inspection report must be uploaded and verified before funding clearance.\n- Disbursal: Exporter must ship cargo within 30 days of funding or a full refund will be triggered.`);
    } finally {
      setDraftingLoading(false);
    }
  };

  const handleShipCargo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingTx || !trackingNumber) return;

    const updated = transactions.map(t => {
      if (t.id === shippingTx.id) {
        return {
          ...t,
          status: 'dispatched' as const,
          shippingTrackingUrl: trackingNumber,
          updatedAt: new Date().toISOString().split('T')[0],
          documents: [
            ...t.documents,
            { name: bolName || "BILL_OF_LADING_SEA_EXPRESS.pdf", url: "#", uploadedAt: new Date().toLocaleDateString() }
          ]
        };
      }
      return t;
    });

    setTransactions(updated);
    setShippingTx(null);
    setTrackingNumber('');
    setBolName('');
    toast.success("Cargo sealed! Importer has been notified of Bill of Lading uploads.");
  };

  const handleUpdateTracking = (txId: string, trackingNum: string, carrier: string) => {
    const updated = transactions.map(t => {
      if (t.id === txId) {
        return {
          ...t,
          shippingTrackingNumber: trackingNum,
          shippingCarrier: carrier,
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return t;
    });
    setTransactions(updated);
    toast.success("Shipment tracking details have been updated.");
  };

  const handleReleaseFunds = (txId: string) => {
    // In a real app we would use a custom modal for confirms, but we'll adapt browser confirm for simplicity since toast doesn't block.
    if (!confirm("Are you sure you want to release these funds to the seller? This action is irreversible.")) return;

    const updated = transactions.map(t => {
      if (t.id === txId) {
        return {
          ...t,
          status: 'completed' as const,
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return t;
    });

    setTransactions(updated);
    toast.success("Funds released safely! Exporter has been credited.");
  };

  const handleInitiateDispute = (txId: string, reason: string) => {
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    const updated = transactions.map(t => {
      if (t.id === tx.id) {
        return {
          ...t,
          status: 'disputed' as const,
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return t;
    });

    setTransactions(updated);

    // Write dispute to admin ledger
    const existingDisputes: Dispute[] = JSON.parse(localStorage.getItem('breccia_admin_disputes') || '[]');
    const newDispute: Dispute = {
      id: "dsp_" + Math.random().toString(36).substring(2, 6),
      transactionId: tx.id,
      transactionTitle: tx.title,
      amount: tx.amount,
      raisedBy: currentUser.role,
      reason: reason,
      status: "open",
      createdAt: new Date().toISOString().split('T')[0],
      chatHistory: [
        { sender: currentUser.name, text: `Raised dispute on account of: ${reason}`, time: new Date().toLocaleTimeString() }
      ],
      auditLog: []
    };

    localStorage.setItem('breccia_admin_disputes', JSON.stringify([newDispute, ...existingDisputes]));
    toast.error("Dispute Escalated! Trade Dispute Officer has been assigned to Arbiter File: " + tx.id);
  };

  const handleSaveExporterProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess("Exporter trade characteristics updated successfully. Multi-currency clearing networks synchronized!");
    setTimeout(() => setProfileSuccess(''), 3000);
  };

  const handleQuerySourcingAI = async () => {
    setSourcingLoading(true);
    setSourcingGuide('');
    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: sourcingPrompt, type: "sourcing" }),
      });
      const data = await response.json();
      setSourcingGuide(data.text);
    } catch (err) {
      setSourcingGuide("#### Ghanaian Sourcing Report\n\n1. **Kuapa Kokoo Coop (Kumasi)**: Over 100,000 smallholders. Fairtrade certified. Typical shipment: Tema Port.\n2. **SGS Standards**: Grade A beans must not exceed 7.5% moisture with under 3% mouldy count.\n3. **Pro Tip**: Use a secure Breccia ledger deposit before clearing Phytosanitary inspection permits.");
    } finally {
      setSourcingLoading(false);
    }
  };

  return (
    <div className="space-y-8 py-6" id="dashboard-system-root">
      
      {/* Printable summary modal */}
      {exportTx && (
        <PrintableSummary tx={exportTx} onClose={() => setExportTx(null)} onPrint={() => addDownloadLog(exportTx.id, exportTx.title)} />
      )}
      
      {/* Demo helper override banner */}
      <div className="p-4 rounded-xl border border-gold-400/25 bg-gold-400/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4" id="demo-guide-banner">
        <div>
          <span className="text-[9px] font-mono tracking-wider bg-gold-accent text-neutral-950 font-bold px-2 py-0.5 rounded uppercase">Demo workspace</span>
          <span className="font-display font-black text-xs text-stone-100 block md:inline md:ml-3 uppercase tracking-wider">Experience the absolute multi-market solution</span>
          <p className="text-[11px] text-zinc-400 font-sans mt-0.5">Toggle between buyer, seller, and custom exporter views underneath to inspect customized dashboards!</p>
        </div>

        <div className="flex gap-2 flex-wrap">
          {[
            { id: 'buyer', label: 'Buyer Dashboard' },
            { id: 'seller', label: 'Seller Dashboard' },
            { id: 'supplier', label: 'Exporter Profile' },
            { id: 'importer', label: 'Global Sourcing' },
          ].map(r => (
            <button
              key={r.id}
              onClick={() => handleRoleOverride(r.id as UserRole)}
              className={`px-3 py-1.5 text-[10px] font-mono tracking-wider font-extrabold rounded-md border transition-all ${
                roleMode === r.id 
                  ? 'bg-gold-gradient text-black border-transparent shadow shadow-gold-glow' 
                  : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Corporate Dashboard Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-neutral-900 pb-6" id="dashboard-welcome">
        <div>
          <div className="flex items-center gap-2 text-gold-accent font-mono text-[10px] uppercase font-bold tracking-widest">
            <ShieldCheck className="w-4 h-4" />
            Breccia Trade Desk Secure
          </div>
          <h2 className="font-display font-bold text-2xl text-stone-200 mt-1 uppercase">
            {currentUser.name} Workspace
          </h2>
          <span className="text-[11px] font-mono text-zinc-500 mt-1 block">Account Level: Corporate Verified Exporter | Member ID: {currentUser.id.toUpperCase()}</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowCreator(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-mono text-xs font-bold text-black bg-gold-gradient shadow shadow-gold-glow"
          >
            <Plus className="w-4 h-4" />
            CREATE ESCROW TRANSACTION
          </button>
        </div>
      </div>

      {/* Importers/Exporters Trade Analytics Overview */}
      <TradeAnalytics />

      {/* Dual Column Layout: Main workflow | AI legal scribe */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left main dashboard column (8 columns) */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Search and Filters */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="relative w-full sm:w-auto flex-1">
              <input
                type="text"
                placeholder="Search by ID, supplier, title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-lg pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-gold-accent transition-colors"
              />
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              </div>
            </div>
            
            <div className="flex gap-2 w-full sm:w-auto">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full sm:w-auto bg-neutral-900 border border-neutral-800 rounded-lg px-4 py-2 text-xs text-white focus:outline-none focus:border-gold-accent transition-colors appearance-none"
              >
                <option value="all">All Statuses</option>
                <option value="unfunded">Unfunded</option>
                <option value="funded">Funded</option>
                <option value="dispatched">Dispatched</option>
                <option value="completed">Completed</option>
                <option value="disputed">Disputed</option>
              </select>
            </div>
          </div>

          {/* Buyer Panel */}
          {roleMode === 'buyer' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center bg-neutral-950 p-4 rounded-xl border border-neutral-850">
                <div>
                  <h4 className="font-display font-extrabold text-sm text-stone-200 uppercase tracking-wider">Your Escrow Transactions</h4>
                  <p className="text-[10px] font-mono text-neutral-500">Milestone monitoring for secure importer purchase deposits.</p>
                </div>
                <span className="text-xs font-mono font-bold text-gold-accent">Buying Ledger</span>
              </div>

               {/* Recommendations Section */}
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-3">                
                <h4 className="font-display font-extrabold text-xs text-stone-300 uppercase tracking-wider">Top Compatibility Matches</h4>
                <div className="grid grid-cols-2 gap-4">
                  {recommendations.map(rec => (
                    <div key={rec.seller.id} className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg flex justify-between items-center">
                        <span className="text-xs text-white font-mono">{rec.seller.companyName}</span>
                        <span className="text-xs font-bold text-emerald-400 font-mono">{rec.score}% Match</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                {filteredTransactions.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center text-center text-zinc-500 border border-neutral-850 border-dashed rounded-xl bg-neutral-900/5 font-mono text-xs space-y-4">
                     <div className="w-16 h-16 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800">
                       <Wallet className="w-8 h-8 text-neutral-600" />
                     </div>
                     <div>
                       <span className="block font-bold text-white mb-1">{transactions.length === 0 ? "No Active Commitments" : "No Matches Found"}</span>
                       <span className="block max-w-xs mx-auto">{transactions.length === 0 ? "Your buying ledger is currently clear. Initiate a secure sourcing deal from the marketplace or create one customized above." : "Try adjusting your search query or filters."}</span>
                     </div>
                     {transactions.length === 0 && (
                       <button
                          onClick={() => setShowCreator(true)}
                          className="px-4 py-2 mt-2 font-mono text-xs font-bold text-black bg-gold-gradient rounded shadow shadow-gold-glow hover:opacity-90"
                       >
                         ISSUE NEW DRAFT
                       </button>
                     )}
                  </div>
                ) : (
                  filteredTransactions.map(tx => (
                    <div key={tx.id} className="p-5 rounded-2xl bg-neutral-950 border border-neutral-850 hover:border-gold-accent/15 transition-all space-y-4" id={`buyer-tx-${tx.id}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <h5 className="font-display font-medium text-white text-sm">{tx.title}</h5>
                            <span className="text-[9px] font-mono text-neutral-500 font-bold bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800">
                              ID: {tx.id}
                            </span>
                            <DeadlineBadge tx={tx} />
                          </div>
                          <span className="block text-[10px] text-zinc-500 font-mono mt-1">Exiting Exporter: {tx.sellerName} | Initiated: {tx.createdAt}</span>
                          <div className="flex gap-4 mt-2">
                             <span className="text-[9px] font-mono text-zinc-400">Escrow Fee: ${tx.escrowFeeAmount.toLocaleString()}</span>
                             <span className="text-[9px] font-mono text-zinc-400">Verification Fee: ${tx.verificationFeeAmount.toLocaleString()}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="block text-gold-accent font-mono font-bold text-base">${tx.amount.toLocaleString()}</span>
                          <span className="text-[9px] text-neutral-400 font-mono">Secured Balance</span>
                        </div>
                      </div>

                      <p className="text-[11px] text-stone-400 font-mono line-clamp-2 border-l-2 border-neutral-800 pl-3">
                        {tx.terms}
                      </p>

                      <div className="grid grid-cols-4 gap-2 text-[9px] font-mono">
                        <span className={`px-2 py-1 rounded ${tx.buyerVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Buyer Verified</span>
                        <span className={`px-2 py-1 rounded ${tx.supplierVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Supplier Verified</span>
                        <span className={`px-2 py-1 rounded ${tx.warehousingVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Warehousing Checked</span>
                        <span className={`px-2 py-1 rounded ${tx.productQualityVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Quality Checked</span>
                      </div>

                      {/* Documents Drawer */}
                      {tx.documents.length > 0 && (
                        <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-850 flex items-center justify-between text-[10px] font-mono text-zinc-400">
                          <span className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-gold-accent" />
                            Moisture & Port inspection checklist available: {tx.documents[0].name}
                          </span>
                          <span className="text-emerald-400 uppercase font-semibold">SGS Verified Cleared</span>
                        </div>
                      )}

                      <TrustScoreWidget transaction={tx} />
                      
                      {tx.status === 'unfunded' && (
                          <div className="p-3 bg-neutral-900 rounded border border-neutral-800">
                             <DigitalSignature transaction={tx} currentUser={currentUser} onSign={handleSign} />
                          </div>
                      )}
                      
                      {tx.milestones && tx.milestones.length > 0 && (
                        <div className="space-y-2 mt-2">
                          <h6 className="text-[10px] uppercase font-mono text-neutral-500">Milestone Payments</h6>
                          {tx.milestones.map(m => (
                            <div key={m.id} className="flex justify-between items-center text-[10px] font-mono p-2 bg-neutral-900 rounded border border-neutral-800">
                              <span>{m.title}</span>
                              <span className={m.status === 'completed' ? 'text-emerald-400' : 'text-amber-500'}>{m.status}</span>
                              {m.status === 'funded' && <button onClick={() => console.log('Releasing', m.id)} className="underline text-gold-accent">Release</button>}
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Call to actions depending on status */}
                      <div className="pt-3.5 border-t border-neutral-900 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-wider">
                          <span>Status:</span>
                          <span className={`px-2 py-0.5 rounded font-bold border ${
                            tx.status === 'funded' ? 'text-blue-400 border-blue-400/25 bg-blue-500/5' :
                            tx.status === 'completed' ? 'text-emerald-400 border-emerald-400/25 bg-emerald-500/5' :
                            tx.status === 'disputed' ? 'text-red-400 border-red-400/25 bg-red-500/5' :
                            tx.status === 'dispatched' ? 'text-amber-400 border-amber-400/25 bg-amber-500/5' :
                            'text-neutral-500 border-neutral-800 bg-neutral-900'
                          }`}>
                            {tx.status}
                          </span>
                        </div>

                        <div className="flex gap-2">
                          <label className={`px-3.5 py-1.5 rounded border ${tx.paymentProofStatus === 'verified' ? 'border-emerald-500/30 text-emerald-500' : 'border-neutral-850 text-neutral-400'} hover:text-white text-[10px] font-mono font-bold flex items-center gap-1.5 cursor-pointer`}>
                             <input type="file" className="hidden" onChange={(e) => e.target.files && handleUploadProof(tx.id, e.target.files[0])} />
                             <Upload className="w-3 h-3" /> {tx.paymentProofStatus === 'verifying' ? 'SCANNING...' : tx.paymentProofStatus === 'verified' ? 'PROOF VERIFIED' : 'UPLOAD PAYMENT'}
                          </label>
                          <button
                            onClick={() => setExportTx(tx)}
                            className="px-3.5 py-1.5 rounded border border-neutral-850 text-neutral-400 hover:text-white text-[10px] font-mono font-bold flex items-center gap-1.5"
                          >
                             <FileText className="w-3 h-3" /> EXPORT PDF
                          </button>
                          <button
                            onClick={() => setActiveChatTxId(activeChatTxId === tx.id ? null : tx.id)}
                            disabled={tx.status === 'completed' && currentUser.role !== 'admin'}
                            className={`px-3.5 py-1.5 rounded border text-[10px] font-mono font-bold transition-colors ${
                              tx.status === 'completed' && currentUser.role !== 'admin' ? 'opacity-30 cursor-not-allowed border-neutral-800 text-neutral-600' :
                              activeChatTxId === tx.id ? 'bg-gold-accent/10 border-gold-accent/30 text-gold-accent' : 'border-neutral-850 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {tx.status === 'completed' && currentUser.role !== 'admin' ? 'CHAT ARCHIVED' : activeChatTxId === tx.id ? 'CLOSE CHAT' : 'TRADE ROOM CHAT'}
                          </button>

                          <button
                            onClick={() => handleDraftAIRules(tx)}
                            className="px-3.5 py-1.5 rounded border border-neutral-850 text-neutral-400 hover:text-white text-[10px] font-mono font-bold"
                          >
                            AI CONTRACT DEED
                          </button>

                          {tx.status === 'unfunded' && (
                            <button
                              onClick={() => handleTriggerPay(tx)}
                              disabled={!tx.buyerSigned || !tx.sellerSigned}
                              className={`px-4 py-1.5 rounded ${!tx.buyerSigned || !tx.sellerSigned ? 'bg-neutral-800 text-neutral-500' : 'bg-gold-gradient text-black'} font-mono text-[10px] font-black`}
                            >
                              {(!tx.buyerSigned || !tx.sellerSigned) ? 'PENDING SIGNATURES' : 'SECURE CAPITAL'}
                            </button>
                          )}

                          {tx.status === 'dispatched' && (
                            <button
                              onClick={() => handleReleaseFunds(tx.id)}
                              className="px-4 py-1.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono font-black"
                            >
                              RELEASE CAPITAL TO SELLER
                            </button>
                          )}

                          {tx.status === 'funded' && (
                            <span className="text-[10px] font-mono text-zinc-500 py-1.5">Waiting for Seller Dispatch...</span>
                          )}

                          {(tx.status === 'funded' || tx.status === 'dispatched') && (
                            <DisputeInitiator transaction={tx} currentUser={currentUser} onInitiateDispute={handleInitiateDispute} />
                          )}
                        </div>
                      </div>

                      {/* Expandable Chat Area */}
                      {activeChatTxId === tx.id && (tx.status !== 'completed' || currentUser.role === 'admin') && (
                        <div className="pt-2 animate-fade-in origin-top">
                          <TransactionChat transaction={tx} roleMode={roleMode} />
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Seller / Exporter receiving dashboard */}
          {roleMode === 'seller' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center bg-neutral-950 p-4 rounded-xl border border-neutral-850">
                <div>
                  <h4 className="font-display font-extrabold text-sm text-stone-200 uppercase tracking-wider">Export Sourcing Orders</h4>
                  <p className="text-[10px] font-mono text-neutral-500">Accept and seal trade container tracking logs of funds securely held in Breccia vaults.</p>
                </div>
                <span className="text-xs font-mono font-bold text-gold-accent">Seller Ledger</span>
              </div>

              <div className="space-y-4">
                {filteredTransactions.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center text-center text-zinc-500 border border-neutral-850 border-dashed rounded-xl bg-neutral-900/5 font-mono text-xs space-y-4">
                     <div className="w-16 h-16 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800">
                       <Wallet className="w-8 h-8 text-neutral-600" />
                     </div>
                     <div>
                       <span className="block font-bold text-white mb-1">{transactions.length === 0 ? "No Active Contracts" : "No Matches Found"}</span>
                       <span className="block max-w-xs mx-auto">{transactions.length === 0 ? "You do not have any active exporter contracts." : "Try adjusting your search query or filters."}</span>
                     </div>
                  </div>
                ) : (
                  filteredTransactions.map(tx => {
                  return (
                    <div key={tx.id} className="p-5 rounded-2xl bg-neutral-950 border border-neutral-850 space-y-4" id={`seller-tx-${tx.id}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <h5 className="font-display font-medium text-white text-sm">{tx.title}</h5>
                            <DeadlineBadge tx={tx} />
                          </div>
                          <span className="block text-[10px] text-zinc-500 font-mono mt-1">Ordering Importer: {tx.buyerName} | Ref ID: {tx.id}</span>
                        </div>
                        <span className="text-gold-accent font-mono font-extrabold text-base">${tx.amount.toLocaleString()}</span>
                      </div>

                      <div className="p-3 bg-neutral-900 text-[10px] font-mono text-neutral-400 border border-neutral-850 rounded">
                        <strong>Agreement Terms:</strong> {tx.terms}
                      </div>

                      <div className="flex gap-4">
                         <span className="text-[9px] font-mono text-zinc-400">Escrow Fee: ${tx.escrowFeeAmount.toLocaleString()}</span>
                         <span className="text-[9px] font-mono text-zinc-400">Verification Fee: ${tx.verificationFeeAmount.toLocaleString()}</span>
                      </div>

                      <div className="grid grid-cols-4 gap-2 text-[9px] font-mono">
                        <span className={`px-2 py-1 rounded ${tx.buyerVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Buyer Verified</span>
                        <span className={`px-2 py-1 rounded ${tx.supplierVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Supplier Verified</span>
                        <span className={`px-2 py-1 rounded ${tx.warehousingVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Warehousing Checked</span>
                        <span className={`px-2 py-1 rounded ${tx.productQualityVerified ? 'bg-emerald-950 text-emerald-400' : 'bg-neutral-900 text-zinc-500'}`}>Quality Checked</span>
                      </div>

                      <TrustScoreWidget transaction={tx} />
                      
                      {tx.status === 'unfunded' && (
                          <div className="p-3 bg-neutral-900 rounded border border-neutral-800">
                             <DigitalSignature transaction={tx} currentUser={currentUser} onSign={handleSign} />
                          </div>
                      )}

                      <div className="flex justify-between items-center border-t border-neutral-900 pt-3">
                        <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-wider">
                          <span>Status:</span>
                          <span className={`px-2 py-0.5 rounded font-bold border ${
                            tx.status === 'funded' ? 'text-blue-400 border-blue-400/25 bg-blue-500/5' :
                            tx.status === 'completed' ? 'text-emerald-400 border-emerald-400/25 bg-emerald-500/5' :
                            tx.status === 'disputed' ? 'text-red-400 border-red-400/25 bg-red-500/5' :
                            tx.status === 'dispatched' ? 'text-amber-400 border-amber-400/25 bg-amber-500/5' :
                            'text-neutral-500 border-neutral-800 bg-neutral-900'
                          }`}>
                            {tx.status}
                          </span>
                        </div>

                        <div className="flex gap-2">
                          <label className={`px-3.5 py-1.5 rounded border ${tx.paymentProofStatus === 'verified' ? 'border-emerald-500/30 text-emerald-500' : 'border-neutral-850 text-neutral-400'} hover:text-white text-[10px] font-mono font-bold flex items-center gap-1.5 cursor-pointer`}>
                             <input type="file" className="hidden" onChange={(e) => e.target.files && handleUploadProof(tx.id, e.target.files[0])} />
                             <Upload className="w-3 h-3" /> {tx.paymentProofStatus === 'verifying' ? 'SCANNING...' : tx.paymentProofStatus === 'verified' ? 'PROOF VERIFIED' : 'UPLOAD PAYMENT'}
                          </label>
                          <button
                            onClick={() => setExportTx(tx)}
                            className="px-3.5 py-1.5 rounded border border-neutral-850 text-neutral-400 hover:text-white text-[10px] font-mono font-bold flex items-center gap-1.5"
                          >
                             <FileText className="w-3 h-3" /> EXPORT PDF
                          </button>
                          <button
                            onClick={() => setActiveChatTxId(activeChatTxId === tx.id ? null : tx.id)}
                            disabled={tx.status === 'completed' && currentUser.role !== 'admin'}
                            className={`px-3.5 py-1.5 rounded border text-[10px] font-mono font-bold transition-colors ${
                              tx.status === 'completed' && currentUser.role !== 'admin' ? 'opacity-30 cursor-not-allowed border-neutral-800 text-neutral-600' :
                              activeChatTxId === tx.id ? 'bg-gold-accent/10 border-gold-accent/30 text-gold-accent' : 'border-neutral-850 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {tx.status === 'completed' && currentUser.role !== 'admin' ? 'CHAT ARCHIVED' : activeChatTxId === tx.id ? 'CLOSE CHAT' : 'TRADE ROOM CHAT'}
                          </button>

                          {tx.status === 'funded' && (
                            <button
                              onClick={() => {
                                setShippingTx(tx);
                                setBolName(`BILL_OF_LADING_${tx.id}.pdf`);
                              }}
                              className="px-4 py-1.5 rounded bg-gold-gradient text-black font-semibold font-mono text-[10px] flex items-center gap-1.5"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              DISPATCH & ENTER BILL OF LADING
                            </button>
                          )}
                          
                          {tx.status === 'dispatched' && (
                            <span className="text-[10px] font-mono text-zinc-500">Shipped (Tracking: {tx.shippingTrackingUrl}). Awaiting Importer Inspection...</span>
                          )}

                          {tx.status === 'completed' && (
                            <span className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                              <ShieldCheck className="w-3.5 h-3.5" />
                              FUNDS COMPLETED & DISBURSED!
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Expandable Chat Area */}
                      {activeChatTxId === tx.id && (tx.status !== 'completed' || currentUser.role === 'admin') && (
                        <div className="pt-2 animate-fade-in origin-top">
                          <TransactionChat transaction={tx} roleMode={roleMode} />
                        </div>
                      )}
                    </div>
                  );
                })
                )}
              </div>
            </div>
          )}

          {/* Supplier Exporter Profile Tab */}
          {roleMode === 'supplier' && (
            <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-6" id="supplier-profile-deck">
              <div className="border-b border-neutral-900 pb-3">
                <h4 className="font-display font-extrabold text-stone-200">EXPORTER COMPANY MANIFEST</h4>
                <p className="text-[10px] font-mono text-neutral-500">Update company logistic parameters, maritime transport routes, and trade statistics.</p>
              </div>

              {profileSuccess && (
                <div className="p-3 bg-gold-500/5 text-gold-accent border border-gold-500/20 text-[11px] font-mono rounded text-center">
                  {profileSuccess}
                </div>
              )}

              <form onSubmit={handleSaveExporterProfile} className="space-y-4 text-left">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-1">Domestic Origin Customs Port</label>
                    <input
                      type="text"
                      value={exporterPort}
                      onChange={(e) => setExporterPort(e.target.value)}
                      placeholder="e.g. Tema Harbor Ghana / Lagos Apapa Port"
                      className="w-full bg-neutral-950 border border-neutral-850 p-2.5 rounded text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-1">Max Bulk Sourcing Capability</label>
                    <input
                      type="text"
                      value={exporterTons}
                      onChange={(e) => setExporterTons(e.target.value)}
                      placeholder="e.g. 5,000 Metric Tons Year"
                      className="w-full bg-neutral-950 border border-neutral-850 p-2.5 rounded text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-1">Maritime Line Carrier Partners</label>
                  <div className="p-3 rounded-lg border border-neutral-850 bg-neutral-950 text-[10px] font-mono text-zinc-500 flex gap-4">
                    <span>🛳️ Maersk Line (APM Terminals)</span>
                    <span>🛳️ MSC Shipping</span>
                    <span>🛳️ COSCO Shipping West-Africa</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-6 py-2 bg-gold-gradient text-black font-semibold text-xs font-mono tracking-widest rounded"
                >
                  SAVE EXPORT PORTFOLIO
                </button>
              </form>
            </div>
          )}

          {/* Importer Sourcing Tab */}
          {roleMode === 'importer' && (
            <div className="space-y-6">
              <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-4" id="importer-sourcing-advisor">
                <div className="border-b border-neutral-900 pb-3 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-gold-accent" />
                  <div>
                    <h4 className="font-display font-extrabold text-stone-200">GEMINI AI SMART EXPORT SCOPE</h4>
                    <p className="text-[9px] font-mono text-neutral-500">Query verified phytosanitary controls near your target supply chain node.</p>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    value={sourcingPrompt}
                    onChange={(e) => setSourcingPrompt(e.target.value)}
                    rows={3}
                    className="w-full bg-neutral-950 border border-neutral-850 text-xs rounded-lg p-3 text-white focus:outline-none focus:border-gold-accent"
                  />
                  <button
                    onClick={handleQuerySourcingAI}
                    disabled={sourcingLoading}
                    className="mt-2 w-full py-2 bg-neutral-900 text-gold-accent text-xs font-semibold font-mono tracking-wider border border-gold-400/10 hover:bg-neutral-950 transition-colors"
                  >
                    {sourcingLoading ? 'Consulting Gemini Exporter Database...' : 'Draft Compliance Sourcing Report'}
                  </button>
                </div>

                {sourcingLoading ? (
                  <div className="p-4 bg-neutral-950 rounded border border-neutral-900 overflow-hidden">
                    <div className="animate-pulse space-y-3">
                      <div className="h-4 bg-neutral-800 rounded w-1/3"></div>
                      <div className="h-3 bg-neutral-800/80 rounded w-full"></div>
                      <div className="h-3 bg-neutral-800/70 rounded w-5/6"></div>
                      <div className="h-3 bg-neutral-800/60 rounded w-full"></div>
                      <div className="flex gap-2 pt-2">
                        <div className="h-4 w-4 bg-gold-accent/20 rounded-full"></div>
                        <div className="h-2 bg-neutral-800/50 rounded w-1/2 mt-1"></div>
                      </div>
                    </div>
                  </div>
                ) : sourcingGuide ? (
                  <div className="p-3 bg-neutral-950 rounded border border-neutral-900 text-xs leading-relaxed text-zinc-200 space-y-2 max-h-72 overflow-y-auto whitespace-pre-line text-left">
                    {sourcingGuide}
                  </div>
                ) : null}
              </div>

              {/* Direct Access to Exporters directory */}
              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-850 flex items-center justify-between">
                <span className="text-xs text-neutral-400">Want to directly browse our Africa trade supplier catalog and start a secure deal?</span>
                <button
                  onClick={() => onNavigate('marketplace')}
                  className="px-4 py-2 bg-gold-gradient text-black text-xs font-bold font-mono tracking-widest rounded flex items-center gap-1"
                >
                  Browse Supplier Directory
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Right side widgets column (4 columns): Gemini AI Contract drafting block */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Scribe / Contract viewer */}
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4" id="ai-contract-drafting-sidebar">
            <div className="border-b border-neutral-900 pb-3">
              <span className="text-[9px] font-mono tracking-widest text-gold-accent font-bold uppercase block">B2B SECURE DRAFTING</span>
              <h4 className="font-display font-medium text-stone-200 text-sm mt-0.5 uppercase">AI Legal Escrow Scribe</h4>
            </div>

            {draftingTxs ? (
              <div className="space-y-4">
                <div className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider bg-neutral-950 p-2.5 rounded border border-neutral-900 flex justify-between items-center">
                  <span>Selected Deal: {draftingTxs.id}</span>
                  <button
                    onClick={() => setDraftingTxs(null)}
                    className="text-neutral-500 hover:text-stone-300"
                  >
                    Clear Match
                  </button>
                </div>

                <div className="p-3 bg-neutral-900 rounded border border-neutral-850 text-[10px] text-zinc-400 leading-relaxed max-h-96 overflow-y-auto whitespace-pre-line text-left">
                  {draftingLoading ? (
                    <div className="py-10 space-y-4">
                      {/* Skeleton bars */}
                      <div className="animate-pulse space-y-3">
                        <div className="h-4 bg-neutral-800 rounded w-1/4"></div>
                        <div className="h-3 bg-neutral-800/80 rounded w-full"></div>
                        <div className="h-3 bg-neutral-800/70 rounded w-5/6"></div>
                        <div className="h-3 bg-neutral-800/60 rounded w-full"></div>
                        <div className="h-3 bg-neutral-800/50 rounded w-3/4"></div>
                      </div>
                      <div className="text-center pt-8">
                        <RefreshCw className="w-5 h-5 text-gold-accent animate-spin mx-auto mb-2" />
                        <span className="block text-[9px] uppercase text-neutral-500 font-mono tracking-wider">Drafting Legal Covenants...</span>
                      </div>
                    </div>
                  ) : (
                    draftedContract
                  )}
                </div>

                {!draftingLoading && draftedContract && (
                  <button
                    onClick={() => {
                      toast.success("Document authorized! Contract PDF generated and matched directly onto B2B custom clearing desks.");
                    }}
                    className="w-full py-2 rounded bg-gold-gradient text-black font-semibold font-mono text-xs"
                  >
                    AUTHORIZE CONTRACT DEED
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center py-12 text-neutral-500 text-xs font-mono space-y-1">
                <HelpCircle className="w-8 h-8 text-neutral-700 mx-auto mb-2" />
                <span className="block">No custom contract selected.</span>
                <span className="block text-[10px] text-neutral-600">Select &quot;AI Contract Deed&quot; on any deal in your active list to compile a custom export contract!</span>
              </div>
            )}
          </div>

          {/* Quick Stats Cabinet */}
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 space-y-4 text-left">
            <h4 className="font-display font-extrabold text-stone-200 text-xs uppercase border-b border-indigo-950 pb-2">Compliance Credentials</h4>
            
            <div className="space-y-3 font-mono text-[10px]">
              <div className="flex justify-between items-center text-zinc-400">
                <span>KYC Identity Compliance:</span>
                <span className="text-emerald-400 font-bold uppercase flex items-center gap-1">Passed ✓</span>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>AML/CTF Verification Score:</span>
                <span className="text-emerald-400 font-bold">Grade A - Clean</span>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>Two-Factor Authentication:</span>
                <span className="text-stone-400 font-mono">Secured (Yubikey/TOTP)</span>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>Local Trade Account Node:</span>
                <span className="text-gold-accent font-bold">Apapa Ap-901</span>
              </div>
            </div>
          </div>
          <TradeCostCalculator />
          <ShipmentTracker transactions={transactions} onUpdateTracking={handleUpdateTracking} />
          <InvoiceGenerator transactions={transactions} />
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4">
            <h4 className="font-display font-medium text-stone-200 text-sm uppercase">Download Log</h4>
            <div className="space-y-2">
              {downloadLogs.length === 0 ? <p className="text-[10px] text-zinc-500">No logs found.</p> : downloadLogs.map((l, i) => (
                <div key={i} className="text-[9px] text-zinc-400 border-b border-neutral-900 pb-1 flex justify-between">
                  <span>{l.title}</span>
                  <span>{l.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Popups & Wizards (Create Escrow wizard) */}
      {showCreator && (
        <div className="fixed inset-0 bg-neutral-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0e0d0b] border border-gold-400/25 p-6 rounded-2xl text-left space-y-4 shadow-2xl relative">
            <h4 className="font-display font-extrabold text-gold-gradient text-base uppercase">Initiate Secured Escrow Transaction</h4>
            
            <form onSubmit={handleCreateEscrow} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Escrow Deal Objective *</label>
                  <input
                    type="text"
                    required
                    value={dealTitle}
                    onChange={(e) => setDealTitle(e.target.value)}
                    placeholder="e.g. Sourcing 15 Tons High-Grade Cashews"
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Counter-Partner (Seller/Exporter) *</label>
                  <input
                    type="text"
                    required
                    value={dealPartner}
                    onChange={(e) => setDealPartner(e.target.value)}
                    placeholder="e.g. West-Coast Cocoa Ventures Ltd"
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Contract Amount Balance *</label>
                  <input
                    type="number"
                    required
                    value={dealAmount}
                    onChange={(e) => setDealAmount(e.target.value)}
                    placeholder="e.g. 15000"
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Clearing Settlement Currency</label>
                  <select
                    value={dealCurrency}
                    onChange={(e) => setDealCurrency(e.target.value as any)}
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none text-zinc-400"
                  >
                    <option value="USD">USD (Global Clearing)</option>
                    <option value="EUR">EUR (Euro Clearing)</option>
                    <option value="NGN">NGN (Nigerian Naira)</option>
                    <option value="GHS">GHS (Ghanaian Cedi)</option>
                    <option value="ZAR">ZAR (South African Rand)</option>
                  </select>
                </div>
              </div>

              <div>
                  <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Preferred Payment Method *</label>
                  <select
                    value={dealPaymentMethod}
                    onChange={(e) => setDealPaymentMethod(e.target.value as any)}
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none text-zinc-400"
                  >
                    <option value="crypto">Crypto (USDT/BTC/ETH)</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="card">Credit Card</option>
                    <option value="wire">SWIFT/SEPA Wire</option>
                    <option value="rise">Rise</option>
                    <option value="paystack">Paystack</option>
                    <option value="flutterwave">Flutterwave</option>
                    <option value="binance_pay">Binance Pay</option>
                  </select>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Sourcing Milestones and Quality Conditions</label>
                <textarea
                  value={dealTerms}
                  onChange={(e) => setDealTerms(e.target.value)}
                  rows={3}
                  placeholder="e.g. SGS inspection certifies that cocoa moisture is holds under 7.5% prior to loading vessel Maersk Tema. Standard inspection duration is 7 bank calendar days."
                  className="w-full bg-neutral-900 border border-neutral-800 p-2 text-xs rounded focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreator(false)}
                  className="px-4 py-2 border border-neutral-800 text-neutral-400 hover:text-white text-xs font-mono rounded"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gold-gradient text-black font-extrabold text-xs font-mono rounded"
                >
                  PUBLISH DEAL PROTOCOL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Popups & Wizards (Shipping container dispatcher popup) */}
      {shippingTx && (
        <div className="fixed inset-0 bg-neutral-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0e0d0b] border border-gold-400/25 p-6 rounded-2xl text-left space-y-4 shadow-2xl">
            <h4 className="font-display font-extrabold text-gold-gradient text-base uppercase">Seal Cargo container Bill of Lading</h4>
            <p className="text-zinc-400 text-xs">Publish shipping tracking parameters and manifest PDF document references so the Buyer and Custom clear agents can audit.</p>

            <form onSubmit={handleShipCargo} className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Maritime Line Container / Vessel Tracking Number *</label>
                <input
                  type="text"
                  required
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  placeholder="e.g. MSKU-9082A Container-77XB"
                  className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2.5 rounded focus:outline-none text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Bill of Lading File Name (PDF Reference)</label>
                <input
                  type="text"
                  value={bolName}
                  onChange={(e) => setBolName(e.target.value)}
                  placeholder="e.g. BILL_OF_LADING_SEA_EXPRESS.pdf"
                  className="w-full bg-neutral-900 border border-neutral-800 text-xs px-3 py-2.5 rounded focus:outline-none text-white font-mono"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShippingTx(null)}
                  className="px-4 py-2 border border-neutral-800 text-neutral-400 hover:text-white text-xs font-mono rounded"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gold-gradient text-black font-extrabold text-xs font-mono rounded"
                >
                  DISPATCH ORDER &rarr;
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Popups & Wizards (Crypto payment simulation popup) */}
      {fundingTx && (
        <div className="fixed inset-0 bg-neutral-950/90 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-3xl bg-[#0a0a0a] border border-gold-400/20 p-6 rounded-3xl relative">
            <button
              onClick={() => setFundingTx(null)}
              className="absolute right-4 top-4 text-neutral-500 hover:text-white text-sm"
            >
              ✕ CLOSE
            </button>
            <CryptoSection 
              onFundSuccess={handlePaymentSuccess}
              escrowId={fundingTx.id}
              targetAmount={fundingTx.amount}
            />
          </div>
        </div>
      )}

      {/* Arbitrator Support Chat */}
      <ArbitratorChatOverlay transactions={transactions} />

    </div>
  );
}
