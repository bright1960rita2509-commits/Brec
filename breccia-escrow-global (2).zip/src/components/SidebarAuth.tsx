/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, User as UserIcon, ShieldCheck } from 'lucide-react';
import { User, UserRole } from '../types';

interface SidebarAuthProps {
  onAuthSuccess: (user: User) => void;
  initialTab?: 'login' | 'signup';
}

export default function SidebarAuth({ onAuthSuccess, initialTab = 'signup' }: SidebarAuthProps) {
  const [activeTab, setActiveTab] = useState<'login' | 'signup'>(initialTab);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');
  const [companyName, setCompanyName] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !password) {
      setError('Please fill in email and password.');
      return;
    }

    if (activeTab === 'signup') {
      if (!fullName) {
        setError('Full Name is required.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
      if (!agreeTerms) {
        setError('You must agree to the Terms of Service.');
        return;
      }

      // Read existing users to emulate true decentralized local persistence
      const users: User[] = JSON.parse(localStorage.getItem('breccia_users') || '[]');
      const userExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());

      if (userExists) {
        setError('An account with this email already exists.');
        return;
      }

      const newUser: User = {
        id: 'u_' + Math.random().toString(36).substring(2, 9),
        name: fullName,
        email: email,
        role: role,
        companyName: companyName || undefined,
        verificationStatus: role === 'supplier' ? 'pending' : 'verified',
        kycCompleted: true,
        twoFactorEnabled: true,
        joinDate: new Date().toLocaleDateString()
      };

      users.push(newUser);
      localStorage.setItem('breccia_users', JSON.stringify(users));
      localStorage.setItem('breccia_current_user', JSON.stringify(newUser));

      setSuccess('Account created successfully! Redirecting...');
      setTimeout(() => {
        onAuthSuccess(newUser);
      }, 1000);

    } else {
      // Mock log in
      const users: User[] = JSON.parse(localStorage.getItem('breccia_users') || '[]');
      
      // Seed default accounts representing our multi-market system
      const demoUsers: User[] = [
        { id: 'u_buyer', name: "Aliko Importer", email: "buyer@breccia.com", role: 'buyer', kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2026-01-01" },
        { id: 'u_seller', name: "Zahara Textiles", email: "seller@breccia.com", role: 'seller', companyName: "Zahara Fabric LLC", kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2026-02-15" },
        { id: 'u_supplier', name: "Mombasa Cocoa Exporters", email: "supplier@breccia.com", role: 'supplier', companyName: "Mombasa Agricultural Group", kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2026-03-10" },
        { id: 'u_importer', name: "EuroFood Import GMBH", email: "importer@breccia.com", role: 'importer', companyName: "EuroFood Sourcing GMBH", kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2026-04-01" },
        { id: 'u_admin', name: "Chidi Nwachukwu", email: "admin@breccia.com", role: 'admin', kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2025-12-01" },
        { id: 'u_dispute', name: "Lydia Tembo", email: "dispute@breccia.com", role: 'dispute_officer', kycCompleted: true, twoFactorEnabled: true, verificationStatus: "verified", joinDate: "2026-01-10" }
      ];

      const matchedUser = [...users, ...demoUsers].find(u => u.email.toLowerCase() === email.toLowerCase());

      if (matchedUser) {
        localStorage.setItem('breccia_current_user', JSON.stringify(matchedUser));
        setSuccess('Login successful! Accessing platform...');
        setTimeout(() => {
          onAuthSuccess(matchedUser);
        }, 1000);
      } else {
        // Create auto-guest user if credentials not pre-registered to make user onboarding seamless and foolproof
        const guestUser: User = {
          id: 'u_guest_' + Math.random().toString(36).substring(2, 9),
          name: email.split('@')[0].toUpperCase(),
          email: email,
          role: 'buyer',
          verificationStatus: 'verified',
          kycCompleted: true,
          twoFactorEnabled: false,
          joinDate: new Date().toLocaleDateString()
        };
        localStorage.setItem('breccia_current_user', JSON.stringify(guestUser));
        setSuccess('Welcome, First-Time User! Created automatic Buyer portfolio.');
        setTimeout(() => {
          onAuthSuccess(guestUser);
        }, 1000);
      }
    }
  };

  const setDemoAccount = (demEmail: string) => {
    setEmail(demEmail);
    setPassword('demopass123');
    setActiveTab('login');
  };

  return (
    <div className="w-full max-w-md glass-panel p-6 rounded-2xl border border-gold-400/15 relative overflow-hidden" id="auth-sidebar-root">
      {/* Absolute background accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gold-accent/5 rounded-full filter blur-3xl"></div>

      <div className="text-center mb-6">
        <h4 className="font-display font-bold text-lg tracking-wider text-gold-gradient" id="auth-title">
          WELCOME TO BRECCIA
        </h4>
        <p className="text-stone-400 text-xs mt-1" id="auth-subtitle">Secure. Trusted. Premium.</p>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-2 bg-neutral-900/80 p-1.5 rounded-lg mb-6 border border-neutral-800">
        <button
          onClick={() => { setActiveTab('login'); setError(''); }}
          id="tab-auth-login"
          className={`py-2 text-center text-xs font-mono tracking-widest font-semibold transition-all rounded ${
            activeTab === 'login' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          LOGIN
        </button>
        <button
          onClick={() => { setActiveTab('signup'); setError(''); }}
          id="tab-auth-signup"
          className={`py-2 text-center text-xs font-mono tracking-widest font-semibold transition-all rounded ${
            activeTab === 'signup' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          SIGN UP
        </button>
      </div>

      {/* States */}
      {error && (
        <div id="auth-error" className="mb-4 text-center p-3 rounded-lg border border-red-900/30 bg-red-950/20 text-red-400 text-xs font-mono">
          {error}
        </div>
      )}
      {success && (
        <div id="auth-success" className="mb-4 text-center p-3 rounded-lg border border-gold-900/30 bg-gold-950/25 text-gold-accent text-xs font-mono">
          {success}
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleAuth} className="space-y-4" id="auth-form">
        {activeTab === 'signup' && (
          <>
            <div>
              <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Aliko Mensah"
                  id="auth-input-fullname"
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-gold-accent/50 rounded-lg py-2.5 pl-10 pr-4 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-gold-accent/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Select Target Role</label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: 'buyer', label: 'Local Buyer' },
                  { value: 'seller', label: 'Local Seller' },
                  { value: 'supplier', label: 'African Exporter' },
                  { value: 'importer', label: 'Global Importer' },
                ].map((rOption) => (
                  <button
                    key={rOption.value}
                    type="button"
                    onClick={() => setRole(rOption.value as UserRole)}
                    className={`py-2 px-1 text-center font-mono text-[10px] rounded border transition-all ${
                      role === rOption.value 
                        ? 'border-gold-accent text-gold-accent bg-gold-accent/5 font-semibold' 
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950 hover:text-stone-200'
                    }`}
                  >
                    {rOption.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Company Name (Optional)</label>
              <div className="relative">
                <ShieldCheck className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. West African Agribusiness Group"
                  id="auth-input-company"
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-gold-accent/50 rounded-lg py-2.5 pl-10 pr-4 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-gold-accent/50"
                />
              </div>
            </div>
          </>
        )}

        <div>
          <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. contact@domain.com"
              id="auth-input-email"
              className="w-full bg-neutral-900 border border-neutral-800 focus:border-gold-accent/50 rounded-lg py-2.5 pl-10 pr-4 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-gold-accent/50"
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Password</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Create strong password"
              id="auth-input-password"
              className="w-full bg-neutral-900 border border-neutral-800 focus:border-gold-accent/50 rounded-lg py-2.5 pl-10 pr-10 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-gold-accent/50"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-3 text-neutral-500 hover:text-stone-300 cursor-pointer"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {activeTab === 'signup' && (
          <div>
            <label className="block text-[10px] font-semibold tracking-wider text-neutral-400 mb-1.5 uppercase">Confirm Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-neutral-500" />
              <input
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repeat selected password"
                id="auth-input-confirmpass"
                className="w-full bg-neutral-900 border border-neutral-800 focus:border-gold-accent/50 rounded-lg py-2.5 pl-10 pr-10 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-gold-accent/50"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3.5 top-3 text-neutral-500 hover:text-stone-300 cursor-pointer"
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'signup' ? (
          <div className="flex items-start gap-2.5 pt-1">
            <input
              type="checkbox"
              id="agree-terms"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-0.5 rounded accent-gold-accent border-neutral-800 cursor-pointer"
            />
            <label htmlFor="agree-terms" className="text-[10px] text-neutral-400 leading-normal selection:bg-none">
              I agree to the <span className="text-gold-accent underline hover:text-gold-400 cursor-pointer">Terms of Service</span> and <span className="text-gold-accent underline hover:text-gold-400 cursor-pointer">Privacy Policy</span>
            </label>
          </div>
        ) : (
          <div className="flex justify-end pt-1">
            <span className="text-[10px] text-gold-accent hover:text-gold-400 cursor-pointer transition-colors">Forgot Password?</span>
          </div>
        )}

        <button
          type="submit"
          id="btn-auth-submit"
          className="w-full py-3 mt-2 rounded-lg bg-gold-gradient text-black font-semibold text-xs tracking-wider font-mono hover:opacity-95 active:scale-98 transition-all duration-150 flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-gold-glow"
        >
          <ShieldCheck className="w-4 h-4" />
          {activeTab === 'signup' ? 'CREATE ACCOUNT' : 'SECURE SIGN IN'}
        </button>
      </form>

      {/* Divider */}
      <div className="relative my-5">
        <div className="absolute inset-x-0 top-1/2 h-px bg-neutral-800/80"></div>
        <div className="relative flex justify-center text-[10px] font-mono tracking-widest uppercase">
          <span className="bg-[#0e0d0b] px-3 text-neutral-500">Quick Access Roles</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => setDemoAccount('buyer@breccia.com')}
          className="py-1.5 px-0.5 text-center font-mono text-[9px] text-zinc-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded transition-all active:scale-95"
        >
          Buyer Demo
        </button>
        <button
          onClick={() => setDemoAccount('supplier@breccia.com')}
          className="py-1.5 px-0.5 text-center font-mono text-[9px] text-zinc-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded transition-all active:scale-95"
        >
          Supplier Demo
        </button>
        <button
          onClick={() => setDemoAccount('admin@breccia.com')}
          className="py-1.5 px-0.5 text-center font-mono text-[9px] text-zinc-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded transition-all active:scale-95"
        >
          Admin Demo
        </button>
      </div>

      <div className="text-center mt-4">
        <button
          onClick={() => {
            setActiveTab(activeTab === 'signup' ? 'login' : 'signup');
            setError('');
          }}
          className="text-[11px] font-medium text-neutral-400 hover:text-gold-accent transition-all cursor-pointer"
        >
          {activeTab === 'signup' 
            ? 'Already have an account? Login' 
            : "Don't have an account yet? Sign Up"}
        </button>
      </div>
    </div>
  );
}
