import React, { useState } from 'react';
import { EscrowTransaction, User } from '../types';

interface DisputeInitiatorProps {
  transaction: EscrowTransaction;
  currentUser: User;
  onInitiateDispute: (txId: string, reason: string) => void;
}

export const DisputeInitiator: React.FC<DisputeInitiatorProps> = ({ transaction, currentUser, onInitiateDispute }) => {
  const [reason, setReason] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="text-[10px] text-red-500 hover:text-red-400 font-mono underline"
      >
        Initiate Dispute
      </button>
    );
  }

  return (
    <div className="p-4 bg-neutral-900 border border-red-900/30 rounded-lg space-y-3">
      <h4 className="text-xs font-bold text-red-500 uppercase">Initiate Dispute</h4>
      <textarea
        className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded text-xs text-white"
        placeholder="Describe the reason for the dispute..."
        value={reason}
        onChange={(e) => setReason(e.target.value)}
        rows={3}
      />
      <div className="flex gap-2">
        <button
          onClick={() => {
            onInitiateDispute(transaction.id, reason);
            setIsOpen(false);
          }}
          className="px-3 py-1 bg-red-900/20 text-red-500 border border-red-800 rounded text-xs font-bold font-mono"
        >
          Confirm Dispute
        </button>
        <button
          onClick={() => setIsOpen(false)}
          className="px-3 py-1 bg-neutral-800 text-neutral-400 rounded text-xs font-mono"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
