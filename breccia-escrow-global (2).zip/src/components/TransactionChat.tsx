import React, { useState, useEffect, useRef } from 'react';
import { Send, Shield, User, Bot, CheckCheck, Clock, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EscrowTransaction, UserRole } from '../types';

interface Message {
  id: string;
  sender: 'me' | 'partner' | 'system';
  text: string;
  timestamp: string;
}

interface TransactionChatProps {
  transaction: EscrowTransaction;
  roleMode: UserRole;
}

export default function TransactionChat({ transaction, roleMode }: TransactionChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isChatClosed, setIsChatClosed] = useState(false);
  const [closureReason, setClosureReason] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Initialize with some contextual messages
  useEffect(() => {
    const defaultMessages: Message[] = [
      { id: 'm1', sender: 'system', text: `Chat room initialized for Ref: ${transaction.id}. Exchange of personal contact information is prohibited to maintain escrow integrity.`, timestamp: transaction.createdAt },
    ];
    setMessages(defaultMessages);
  }, [transaction.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const partnerName = roleMode === 'buyer' || roleMode === 'importer' ? transaction.sellerName : transaction.buyerName;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isChatClosed) return;

    // Contact info validation
    const phoneRegex = /\+?\d[\d -]{8,}\d/g;
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+)/g;

    if (phoneRegex.test(input) || emailRegex.test(input) || urlRegex.test(input)) {
        const reason = "Exchange of direct contact info (phones, emails, links) is prohibited.";
        setIsChatClosed(true);
        setClosureReason(reason);
        setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: 'system',
            text: `Chat closed by system: ${reason}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
        return;
    }

    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'me',
      text: input.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMsg]);
    setInput('');
    setIsTyping(true);

    // Mock response from partner
    setTimeout(() => {
      const responses = [
        "Received loud and clear. I will attach the latest customs clearance report shortly.",
        "Understood. Please ensure the escrow funds are locked so we can dispatch the trucks to Tema Port.",
        "Thanks for the update. The SGS inspectors are scheduled for tomorrow.",
        "Perfect. I agree with these conditions. Let's proceed to Bill of Lading generation.",
        "We are currently consolidating the cargo. Should be ready by end of week."
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'partner',
        text: randomResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setIsTyping(false);
    }, 1500 + Math.random() * 2000);
  };

  return (
    <div className="flex flex-col h-[400px] bg-neutral-1000 border border-neutral-800 rounded-xl overflow-hidden mt-4 shadow-inner">
      {/* Header */}
      <div className="bg-neutral-900 border-b border-neutral-800 p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
            <User className="w-4 h-4 text-neutral-400" />
          </div>
          <div>
            <h5 className="font-display font-medium text-white text-xs">{partnerName}</h5>
            <span className="text-[9px] font-mono text-emerald-500 font-semibold flex items-center gap-1">
               <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
               Online • Verified Counterparty
            </span>
          </div>
        </div>
        <div className="px-2.5 py-1 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] uppercase font-mono font-bold flex items-center gap-1">
          <Shield className="w-3 h-3" /> Encrypted Room
        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-neutral-950">
        <AnimatePresence initial={false}>
          {messages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col ${msg.sender === 'me' ? 'items-end' : 'items-start'}`}
            >
              {msg.sender === 'system' ? (
                <div className="w-full text-center my-2">
                  <span className="bg-neutral-900/80 border border-neutral-800 px-3 py-1 rounded-full text-[9px] font-mono text-neutral-500 uppercase tracking-widest inline-flex items-center gap-1.5">
                    <Bot className="w-3 h-3 text-gold-accent" />
                    {msg.text}
                  </span>
                </div>
              ) : (
                <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 ${
                  msg.sender === 'me' 
                    ? 'bg-gold-accent text-neutral-950 rounded-tr-sm' 
                    : 'bg-neutral-900 text-stone-200 border border-neutral-800 rounded-tl-sm'
                }`}>
                  <p className="text-xs font-sans leading-relaxed">{msg.text}</p>
                  <div className={`mt-1 text-[8px] font-mono flex items-center gap-1 justify-end ${
                    msg.sender === 'me' ? 'text-black/60' : 'text-neutral-500'
                  }`}>
                    {msg.timestamp}
                    {msg.sender === 'me' && <CheckCheck className="w-3 h-3" />}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
          {isTyping && (
             <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-start">
               <div className="bg-neutral-900 text-neutral-400 border border-neutral-800 rounded-2xl rounded-tl-sm px-4 py-3 flex gap-1 items-center h-9">
                 <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce"></div>
                 <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                 <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
               </div>
             </motion.div>
          )}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>

      {/* Input Area */}
      <div className="bg-neutral-900 border-t border-neutral-800">
        {isChatClosed ? (
           <div className="px-4 py-3 text-xs text-red-500 font-mono text-center italic bg-red-950/20 border-t border-red-900/50">
             Chat closed: {closureReason}
           </div>
        ) : (
          <form onSubmit={handleSend} className="p-3 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Message to counterparty (auditable by admin)..."
              className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-gold-accent transition-colors"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="px-4 py-2.5 bg-gold-gradient text-black rounded-lg disabled:opacity-50 disabled:grayscale transition-all flex items-center justify-center hover:opacity-90 shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
