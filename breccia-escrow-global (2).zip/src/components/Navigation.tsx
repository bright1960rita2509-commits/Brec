/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, LayoutDashboard, LogOut, Menu, X, Globe } from 'lucide-react';
import { User } from '../types';

interface NavigationProps {
  currentUser: User | null;
  onLogout: () => void;
  onOpenAuth: (tab: 'login' | 'signup') => void;
  activeSection: string;
  onNavigate: (section: string) => void;
}

export default function Navigation({
  currentUser,
  onLogout,
  onOpenAuth,
  activeSection,
  onNavigate
}: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const menuItems = [
    { id: 'home', label: 'HOME' },
    { id: 'about', label: 'ABOUT US' },
    { id: 'how-it-works', label: 'HOW IT WORKS' },
    { id: 'escrow-promo', label: 'ESCROW' },
    { id: 'marketplace', label: 'TRADE MARKETPLACE' },
    { id: 'pricing', label: 'PRICING' },
    { id: 'faq', label: 'FAQ' },
    { id: 'contact', label: 'CONTACT' }
  ];

  const handleItemClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 w-full glass-panel border-b border-gilded/15 py-4 px-6 md:px-12 flex items-center justify-between">
      {/* Brand Logo */}
      <div 
        onClick={() => onNavigate('home')} 
        className="flex items-center gap-3 cursor-pointer group"
        id="nav-logo-container"
      >
        <div className="relative w-10 h-10 flex items-center justify-center rounded-xl bg-gradient-to-tr from-neutral-900 to-neutral-800 border border-gold-400/30 group-hover:border-gold-accent transition-colors">
          <Shield className="w-5 h-5 text-gold-accent" />
          <div className="absolute inset-0 rounded-xl bg-gold-accent/5 filter blur-sm group-hover:bg-gold-accent/10 transition-all"></div>
        </div>
        <div>
          <span className="font-display font-bold text-2xl tracking-wider text-gold-accent">BRECCIA</span>
          <div className="text-[9px] font-mono tracking-[0.25em] text-neutral-500 group-hover:text-gold-400 transition-colors">ESCROW & TRADE</div>
        </div>
      </div>

      {/* Desktop Menu */}
      <div className="hidden lg:flex items-center gap-8 text-xs font-medium tracking-widest text-neutral-400">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleItemClick(item.id)}
            id={`nav-link-${item.id}`}
            className={`transition-colors duration-200 hover:text-gold-accent relative py-2 cursor-pointer ${
              activeSection === item.id ? 'text-gold-accent' : ''
            }`}
          >
            {item.label}
            {activeSection === item.id && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-gold-400 to-gold-600 rounded"></span>
            )}
          </button>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="hidden lg:flex items-center gap-4">
        {currentUser ? (
          <div className="flex items-center gap-4" id="nav-user-info">
            <button
              onClick={() => onNavigate('dashboard')}
              id="btn-nav-dashboard"
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-mono text-xs font-semibold tracking-wider text-black bg-gold-gradient hover:opacity-90 active:scale-95 transition-all duration-150 shadow-md shadow-gold-glow"
            >
              <LayoutDashboard className="w-4 h-4" />
              DASHBOARD
            </button>
            <button
              onClick={() => onNavigate('settings')}
              id="btn-nav-settings"
              className="px-4 py-2.5 rounded-lg border border-neutral-800 text-neutral-400 font-mono text-xs hover:text-gold-accent hover:border-gold-accent/40 transition-colors cursor-pointer"
            >
              SETTINGS / KYC
            </button>
            <button
              onClick={onLogout}
              id="btn-nav-logout"
              title="Logout"
              className="p-2.5 rounded-lg border border-neutral-800 text-neutral-400 hover:text-red-400 hover:border-red-400/45 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-4" id="nav-guest-actions">
            <button
              onClick={() => onOpenAuth('login')}
              id="btn-nav-login"
              className="px-5 py-2.5 text-xs font-semibold tracking-wider text-gold-accent hover:text-white transition-colors cursor-pointer border border-gold-400/20 hover:border-gold-accent/40 rounded-lg"
            >
              LOGIN
            </button>
            <button
              onClick={() => onOpenAuth('signup')}
              id="btn-nav-signup"
              className="px-6 py-2.5 text-xs font-semibold tracking-wider text-black bg-gold-gradient hover:opacity-95 rounded-lg shadow-sm font-mono active:scale-95 transition-all"
            >
              SIGN UP
            </button>
          </div>
        )}
      </div>

      {/* Mobile Menu Icon */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className="lg:hidden p-2 rounded-lg text-neutral-400 hover:text-gold-accent border border-neutral-800 transition-colors"
        id="btn-mobile-menu"
      >
        {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="absolute top-[73px] left-0 w-full bg-neutral-950/98 backdrop-blur-xl border-b border-gilded/15 p-6 flex flex-col gap-5 z-40 lg:hidden">
          <div className="flex flex-col gap-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`text-left text-sm tracking-wider py-2 font-medium ${
                  activeSection === item.id ? 'text-gold-accent pl-2 border-l-2 border-gold-accent' : 'text-neutral-400'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="border-t border-neutral-900 pt-4 flex flex-col gap-3">
            {currentUser ? (
              <>
                <div className="text-xs text-neutral-500 font-mono">Logged in as {currentUser.email}</div>
                <button
                  onClick={() => handleItemClick('dashboard')}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-lg text-black bg-gold-gradient font-bold text-xs tracking-widest font-mono"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  DASHBOARD
                </button>
                <button
                  onClick={onLogout}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-lg border border-neutral-800 text-neutral-400 font-bold text-xs tracking-widest"
                >
                  <LogOut className="w-4 h-4" />
                  LOG OUT
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setMobileMenuOpen(false);
                  }}
                  className="py-3 text-center rounded-lg border border-neutral-800 text-neutral-300 font-semibold text-xs tracking-widest"
                >
                  LOGIN
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('signup');
                    setMobileMenuOpen(false);
                  }}
                  className="py-3 text-center rounded-lg bg-gold-gradient text-black font-semibold text-xs tracking-widest font-mono"
                >
                  SIGN UP
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
