import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, ShieldAlert, Mic, FileWarning, Image as ImageIcon, Zap } from 'lucide-react';
import { EscrowTransaction } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ArbitratorChatOverlayProps {
  transactions: EscrowTransaction[];
}

interface Message {
  id: string;
  sender: 'user' | 'arbitrator';
  text: string;
  timestamp: string;
  images?: string[];
}

export default function ArbitratorChatOverlay({ transactions }: ArbitratorChatOverlayProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTxId, setSelectedTxId] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isDisputeModalOpen, setIsDisputeModalOpen] = useState(false);
  const [disputeReason, setDisputeReason] = useState('');
  const [disputeDescription, setDisputeDescription] = useState('');
  const [evidenceImages, setEvidenceImages] = useState<string[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setInput(prev => prev + (prev.length > 0 && !prev.endsWith(' ') ? ' ' : '') + finalTranscript);
        }
      };

      recognitionRef.current.onerror = () => setIsRecording(false);
      recognitionRef.current.onend = () => setIsRecording(false);
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      try {
        recognitionRef.current?.start();
        setIsRecording(true);
      } catch (e) {
        console.error(e);
      }
    }
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          id: 'welcome',
          sender: 'arbitrator',
          text: 'Hello, I am Lydia Tembo, your assigned Arbitration Officer. How can I assist you with your trade today?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [isOpen]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const [showQuickReponses, setShowQuickResponses] = useState(false);

  const quickResponses = [
    "Could you please elaborate on the quality issues you observed?",
    "Please upload the relevant SGS certification for our review.",
    "I have logged this dispute and locked the transaction funds.",
    "We will need 48 hours to complete the preliminary investigation."
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !selectedTxId) return;

    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: input.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'arbitrator',
        text: `I'm reviewing the details for transaction ${selectedTxId}. Please hold on a moment while I pull up the escrow agreement and SGS records.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleFormalizeDispute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTxId || !disputeReason || !disputeDescription) return;

    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: `FORMAL DISPUTE FILED\nReason: ${disputeReason}\nDescription: ${disputeDescription}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      images: evidenceImages.length > 0 ? evidenceImages : undefined
    };

    setMessages(prev => [...prev, newMsg]);
    setIsDisputeModalOpen(false);
    setDisputeReason('');
    setDisputeDescription('');
    setEvidenceImages([]);
    setIsTyping(true);

    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'arbitrator',
        text: `I have received your formal dispute for transaction ${selectedTxId}. I am officially opening an Arbitration File and locking the escrow funds until this is resolved.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setIsTyping(false);
    }, 2000 + Math.random() * 1000);
  };

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 p-4 bg-gold-gradient text-black rounded-full shadow-[0_0_20px_rgba(196,166,97,0.3)] hover:scale-105 transition-transform z-40"
      >
        <MessageSquare className="w-6 h-6" />
      </button>

      {/* Chat Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-24 right-6 w-[360px] h-[500px] bg-neutral-950 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-neutral-900 border-b border-neutral-800 p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center border border-rose-500/30 text-rose-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-white font-display font-medium text-sm">Dispute & Support</h4>
                  <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                    Officer Online
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {selectedTxId && (
                  <button 
                    onClick={() => setIsDisputeModalOpen(true)}
                    className="p-1.5 text-rose-400 hover:bg-neutral-800 rounded transition-colors"
                    title="Formalize Dispute"
                  >
                    <FileWarning className="w-4 h-4" />
                  </button>
                )}
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 text-neutral-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex flex-col flex-1 overflow-hidden bg-neutral-900/50">
              
              {/* Transaction Selector */}
              <div className="p-3 border-b border-neutral-800 bg-neutral-950 shrink-0">
                <label className="block text-[10px] font-mono text-neutral-500 uppercase tracking-wider mb-1.5">Regarding Transaction</label>
                <select
                  value={selectedTxId}
                  onChange={(e) => setSelectedTxId(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold-accent transition-colors"
                >
                  <option value="" disabled>Select a transaction ID...</option>
                  {transactions.map(tx => (
                    <option key={tx.id} value={tx.id}>{tx.id} - {tx.title}</option>
                  ))}
                </select>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map(msg => (
                  <div key={msg.id} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 ${
                      msg.sender === 'user' 
                        ? 'bg-neutral-800 text-white rounded-tr-sm border border-neutral-700' 
                        : 'bg-rose-950/30 text-rose-100 border border-rose-900/50 rounded-tl-sm'
                    }`}>
                      <p className="text-xs font-sans leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                      {msg.images && msg.images.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {msg.images.map((src, i) => (
                            <img key={i} src={src} alt="Evidence attached" className="w-16 h-16 rounded border border-neutral-700/50 object-cover" />
                          ))}
                        </div>
                      )}
                      <span className={`block mt-1 text-[9px] font-mono ${msg.sender === 'user' ? 'text-neutral-400 text-right' : 'text-rose-400/60'}`}>
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex items-start">
                    <div className="bg-rose-950/30 border border-rose-900/50 rounded-2xl rounded-tl-sm px-4 py-3 flex gap-1 items-center h-9">
                      <div className="w-1.5 h-1.5 bg-rose-400/50 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-rose-400/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-1.5 h-1.5 bg-rose-400/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>
            </div>

            {/* Input */}
            <div className="bg-neutral-950 border-t border-neutral-800 shrink-0 relative">
              <AnimatePresence>
                {showQuickReponses && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute bottom-full left-0 right-0 p-2 bg-neutral-900 border-t border-neutral-800 flex flex-col gap-1 max-h-32 overflow-y-auto"
                  >
                    <div className="text-[9px] font-mono text-neutral-500 uppercase px-2 py-1 tracking-wider sticky top-0 bg-neutral-900">Arbitrator Templates</div>
                    {quickResponses.map((qr, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setInput(qr);
                          setShowQuickResponses(false);
                        }}
                        className="text-left text-xs text-neutral-300 hover:text-white hover:bg-neutral-800 px-2 py-1.5 rounded transition-colors whitespace-nowrap overflow-hidden text-ellipsis"
                      >
                        {qr}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              <form onSubmit={handleSend} className="p-3">
                {!selectedTxId ? (
                  <div className="text-center text-xs text-neutral-500 py-2 font-mono">
                    Please select a transaction above to start chatting.
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setShowQuickResponses(!showQuickReponses)}
                      className={`p-2 rounded-lg transition-colors border ${showQuickReponses ? 'bg-amber-500/10 text-amber-500 border-amber-500/30' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-white'}`}
                      title="Quick Templates"
                    >
                      <Zap className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={toggleRecording}
                      className={`p-2 rounded-lg transition-colors border ${isRecording ? 'bg-rose-500/20 text-rose-400 border-rose-500/50 animate-pulse' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-white'}`}
                      title={isRecording ? "Stop recording" : "Start voice text"}
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Describe your issue..."
                      className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-gold-accent transition-colors"
                    />
                    <button
                      type="submit"
                      disabled={!input.trim()}
                      className="p-2 bg-neutral-800 text-gold-accent rounded-lg disabled:opacity-50 transition-colors border border-neutral-700 disabled:border-transparent hover:bg-neutral-700"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </form>
            </div>

            <AnimatePresence>
              {isDisputeModalOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="absolute inset-0 bg-neutral-950/95 backdrop-blur-sm flex flex-col z-50 overflow-hidden"
                >
                  <div className="p-4 border-b border-neutral-800 flex justify-between items-center bg-rose-500/10">
                    <h3 className="font-display text-white text-sm">Formalize Dispute</h3>
                    <button onClick={() => setIsDisputeModalOpen(false)} className="text-neutral-500 hover:text-white">
                      <X className="w-5 h-5"/>
                    </button>
                  </div>
                  <form onSubmit={handleFormalizeDispute} className="flex-1 p-4 flex flex-col gap-4 overflow-y-auto">
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-500 uppercase tracking-wider mb-2">Dispute Reason</label>
                      <select 
                        required
                        value={disputeReason}
                        onChange={(e) => setDisputeReason(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 text-white text-xs rounded-lg px-3 py-2 focus:border-rose-500 focus:outline-none"
                      >
                        <option value="" disabled>Select reason...</option>
                        <option value="Quality significantly below contract">Quality significantly below contract</option>
                        <option value="SGS documentation fails to match">SGS documentation fails to match</option>
                        <option value="Moisture content exceeds limits">Moisture content exceeds limits</option>
                        <option value="Non-delivery or extreme delay">Non-delivery or extreme delay</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div className="flex-1 flex flex-col min-h-0">
                      <label className="block text-[10px] font-mono text-neutral-500 uppercase tracking-wider mb-2 shrink-0">Evidence & Context</label>
                      <textarea 
                        required
                        value={disputeDescription}
                        onChange={(e) => setDisputeDescription(e.target.value)}
                        placeholder="Provide details of the dispute..."
                        className="w-full flex-1 mb-3 bg-neutral-900 border border-neutral-800 text-white text-xs rounded-lg px-3 py-2 resize-none focus:border-rose-500 focus:outline-none"
                      />
                      <div className="flex flex-col gap-2 shrink-0">
                        <div className="flex items-center gap-2">
                          <button 
                            type="button"
                            onClick={() => {
                              const num = Math.floor(Math.random() * 1000);
                              setEvidenceImages(prev => [...prev, `https://picsum.photos/seed/${num}/150/150`]);
                            }}
                            className="px-3 py-2 border border-neutral-800 bg-neutral-900 rounded-lg text-neutral-400 hover:text-white hover:border-neutral-700 text-[10px] font-mono font-bold flex items-center gap-1.5 transition-colors"
                          >
                            <ImageIcon className="w-3.5 h-3.5" />
                            ATTACH EVIDENCE
                          </button>
                        </div>
                        {evidenceImages.length > 0 && (
                          <div className="flex flex-wrap gap-2 pb-2">
                            {evidenceImages.map((src, idx) => (
                              <div key={idx} className="relative group">
                                <img src={src} alt="Evidence preview" className="w-12 h-12 rounded border border-neutral-800 object-cover" />
                                <button
                                   type="button"
                                   onClick={() => setEvidenceImages(prev => prev.filter((_, i) => i !== idx))}
                                   className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <X className="w-2.5 h-2.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <button 
                      type="submit"
                      disabled={!disputeReason || !disputeDescription}
                      className="w-full shrink-0 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold rounded-lg transition-colors disabled:opacity-50"
                    >
                      FILE DISPUTE & LOCK FUNDS
                    </button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
