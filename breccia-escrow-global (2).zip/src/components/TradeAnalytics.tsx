import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Activity } from 'lucide-react';

const data = [
  { month: 'Jan', volume: 120000, active: 45 },
  { month: 'Feb', volume: 155000, active: 52 },
  { month: 'Mar', volume: 142000, active: 48 },
  { month: 'Apr', volume: 195000, active: 61 },
  { month: 'May', volume: 220000, active: 75 },
  { month: 'Jun', volume: 285000, active: 89 },
];

export default function TradeAnalytics() {
  return (
    <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 mb-8 shadow-xl relative overflow-hidden" id="analytics-widget">
      <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
        <Activity className="w-32 h-32 text-gold-accent" />
      </div>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-neutral-900 pb-4 mb-6">
        <div>
          <span className="text-[10px] font-mono tracking-widest text-gold-accent font-bold uppercase block">Breccia Global Liquidity</span>
          <h4 className="font-display font-bold text-stone-200 text-lg mt-0.5 uppercase flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-gold-accent" />
            Trade Volume Analytics
          </h4>
        </div>
        <div className="mt-4 md:mt-0 text-right">
          <span className="block text-[10px] text-zinc-500 font-mono tracking-wider uppercase mb-1">Total Cross-Border Volume (6M)</span>
          <span className="font-mono text-2xl font-black text-white">$1,117,000 <span className="text-sm text-gold-accent">USD</span></span>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#c4a661" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#c4a661" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
            <XAxis dataKey="month" stroke="#737373" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#737373" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value/1000}k`} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333', borderRadius: '8px', fontSize: '12px', fontFamily: 'monospace' }}
              itemStyle={{ color: '#c4a661' }}
            />
            <Area type="monotone" dataKey="volume" stroke="#c4a661" strokeWidth={2} fillOpacity={1} fill="url(#colorVolume)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 border-t border-neutral-900 pt-5">
         <div>
            <span className="block text-[10px] text-zinc-500 font-mono tracking-wider uppercase">Escrow Success Rate</span>
            <span className="text-emerald-400 font-black font-mono text-base">99.8%</span>
         </div>
         <div>
            <span className="block text-[10px] text-zinc-500 font-mono tracking-wider uppercase">Avg. Dispute Resolution</span>
            <span className="text-stone-200 font-black font-mono text-base">&lt; 48 Hrs</span>
         </div>
         <div>
            <span className="block text-[10px] text-zinc-500 font-mono tracking-wider uppercase">Active Corridors</span>
            <span className="text-stone-200 font-black font-mono text-base">14 Africa-EU</span>
         </div>
         <div>
            <span className="block text-[10px] text-zinc-500 font-mono tracking-wider uppercase">Default Prevention</span>
            <span className="text-emerald-400 font-black font-mono text-base">$4.2M Insured</span>
         </div>
      </div>
    </div>
  );
}
