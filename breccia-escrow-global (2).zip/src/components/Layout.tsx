import React from 'react';
import { Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#050505] text-stone-250 flex flex-col">
      <header>Navigation will go here</header>
      <main className="flex-1 w-full max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
        <Outlet />
      </main>
      <footer>Footer will go here</footer>
    </div>
  );
}
