/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, Globe, Play, ArrowRight, ShieldAlert, Award } from 'lucide-react';
import SidebarAuth from './SidebarAuth';
import { User } from '../types';

interface HeroProps {
  onAuthSuccess: (user: User) => void;
  onNavigate: (section: string) => void;
  onOpenAuth: (authTab: 'login' | 'signup') => void;
}

export default function Hero({ onAuthSuccess, onNavigate, onOpenAuth }: HeroProps) {
  return (
    <div className="relative w-full overflow-hidden py-10 md:py-16 dot-grid text-left" id="hero-arena">
      {/* Intricate floating golden background glows mapping the reference design */}
      <div className="absolute top-1/4 left-1/2 w-[500px] h-[500px] rounded-full gold-glow-back pointer-events-none z-0"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Left Column (7 columns) */}
        <div className="lg:col-span-7 space-y-7 z-20">
          
          {/* Top Premium Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-gold-450/20 bg-gold-450/5 text-[11px] font-mono tracking-widest text-gold-accent font-semibold uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-gold-accent animate-ping"></span>
            PREMIUM ESCROW & SECURE PAYMENTS
          </div>

          {/* Master headlines */}
          <div className="space-y-2">
            <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-[1.08] text-white">
              Secure Today.
              <span className="block text-gold-gradient">Trade Globally Tomorrow.</span>
            </h1>
            <p className="text-zinc-400 text-sm sm:text-base leading-relaxed max-w-xl font-sans pt-1">
              Breccia connects African businesses and international buyers through secure escrow-powered transactions, verified supplier catalogs, and trusted cross-border contract clearing.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 items-center">
            <button
              onClick={() => onNavigate('dashboard')}
              id="hero-btn-getstarted"
              className="px-8 py-3.5 rounded-lg bg-gold-gradient text-black font-semibold text-xs tracking-wider font-mono hover:opacity-95 hover:shadow-lg active:scale-95 transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-gold-glow"
            >
              GET STARTED
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('how-it-works')}
              id="hero-btn-howitwork"
              className="px-6 py-3.5 rounded-lg border border-neutral-800 text-white font-semibold text-xs tracking-widest font-mono hover:bg-neutral-900 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 text-gold-accent" />
              HOW IT WORKS
            </button>
          </div>

          {/* Trust cards grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-neutral-900/60" id="hero-trust-elements">
            
            <div className="flex gap-3.5 items-start p-3 rounded-lg bg-neutral-950/40 border border-neutral-900">
              <div className="w-8 h-8 rounded-lg bg-gold-accent/5 border border-gold-accent/15 flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="w-4.5 h-4.5 text-gold-accent" />
              </div>
              <div className="space-y-0.5">
                <span className="text-xs font-display font-bold text-stone-200 block">Bank-Grade Security</span>
                <span className="text-[10px] text-zinc-500 font-sans block">256-bit encryption & custody protection.</span>
              </div>
            </div>

            <div className="flex gap-3.5 items-start p-3 rounded-lg bg-neutral-950/40 border border-neutral-900">
              <div className="w-8 h-8 rounded-lg bg-gold-accent/5 border border-gold-accent/15 flex items-center justify-center flex-shrink-0">
                <Globe className="w-4.5 h-4.5 text-gold-accent" />
              </div>
              <div className="space-y-0.5">
                <span className="text-xs font-display font-bold text-stone-200 block">Global & Borderless</span>
                <span className="text-[10px] text-zinc-500 font-sans block">Trade securely across Africa & globally.</span>
              </div>
            </div>

            <div className="flex gap-3.5 items-start p-3 rounded-lg bg-neutral-950/40 border border-neutral-900">
              <div className="w-8 h-8 rounded-lg bg-gold-accent/5 border border-gold-accent/15 flex items-center justify-center flex-shrink-0">
                <Award className="w-4.5 h-4.5 text-gold-accent" />
              </div>
              <div className="space-y-0.5">
                <span className="text-xs font-display font-bold text-stone-200 block">Trusted by Elite</span>
                <span className="text-[10px] text-zinc-500 font-sans block">KYC checked and SGS-audited trade lines.</span>
              </div>
            </div>

          </div>

        </div>

        {/* Right Column Auth & Large Crest Overlay (5 columns) */}
        <div className="lg:col-span-5 relative flex justify-center items-center z-10 p-2">
          
          {/* Intricate Glowing SVG Crest positioned behind or next to Auth. */}
          <div className="absolute -left-20 top-1/2 w-[350px] h-[350px] transform -translate-y-1/2 pointer-events-none opacity-40 mix-blend-screen hidden xl:block animate-pulse">
            <svg viewBox="0 0 400 400" className="w-full h-full text-gold-accent fill-none stroke-current">
              {/* Outer light circles */}
              <circle cx="200" cy="200" r="160" strokeWidth="1" strokeDasharray="4 8" className="opacity-25" />
              <circle cx="200" cy="200" r="130" strokeWidth="1" className="opacity-20" />
              
              {/* Gold Crest Filigree Wings / Shield Artwork */}
              <path d="M 200 40 L 260 90 L 260 180 C 260 250 200 310 200 330 C 200 310 140 250 140 180 L 140 90 Z" strokeWidth="2" className="opacity-75" />
              
              {/* Internal abstract African circular design layers */}
              <circle cx="200" cy="180" r="45" strokeWidth="1.5" className="opacity-80" />
              <path d="M 200 135 C 225 135 245 155 245 180 C 245 205 225 225 200 225 C 175 225 155 205 155 180" strokeWidth="1" strokeDasharray="2 4" />
              
              {/* Central crown and drops */}
              <path d="M 175 100 L 185 115 L 200 95 L 215 115 L 225 100" strokeWidth="1.5" />
              <circle cx="200" cy="90" r="3" fill="currentColor" />
              <circle cx="175" cy="95" r="2" fill="currentColor" />
              <circle cx="225" cy="95" r="2" fill="currentColor" />
              
              {/* Breccia Text curve indicator */}
              <path d="M 120 330 Q 200 365 280 330" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>

          <SidebarAuth onAuthSuccess={onAuthSuccess} />
        </div>

      </div>

      {/* Massive Glowing Center Crest Block for Desktop Screens (Aligns precisely, positioned below Hero Column layout as wide layout element) */}
      <div className="w-full max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 gap-4 text-center mt-12 py-10 border-b border-neutral-900/40 relative">
        <div className="inline-block relative">
          {/* Animated Gold rays radiating outwards */}
          <div className="absolute inset-x-0 bottom-0 top-0 bg-gradient-to-t from-gold-accent/5 to-transparent filter blur-3xl rounded-full"></div>
          
          <svg viewBox="0 0 200 150" className="w-32 h-32 mx-auto text-gold-accent stroke-current fill-none">
            {/* The Breccia intricate crest */}
            <path d="M 100 20 C 130 20 150 45 150 75 C 150 115 100 140 100 140 C 100 140 50 115 50 75 C 50 45 70 20 100 20 Z" strokeWidth="1.5" className="opacity-80" />
            <path d="M 100 30 Q 120 50 100 70 Q 80 50 100 30 Z" strokeWidth="1" strokeDasharray="3 3" />
            <circle cx="100" cy="70" r="15" strokeWidth="1.5" />
            
            {/* Crown peaks */}
            <path d="M 85 45 L 100 38 L 115 45" strokeWidth="1" />
            
            {/* Splashing particle drops decoration underneath from reference graphic */}
            <circle cx="100" cy="95" r="2" fill="currentColor" />
            <circle cx="92" cy="100" r="1.5" fill="currentColor" />
            <circle cx="108" cy="100" r="1.5" fill="currentColor" />
          </svg>
          <span className="block font-display font-black text-xs tracking-[0.4em] text-white uppercase mt-4 select-none">BRECCIA CREST</span>
          <span className="block text-[10px] font-mono tracking-widest text-gold-accent uppercase mt-1">Multi-Port Custodian Certificate Protection Nodes</span>
        </div>
      </div>
    </div>
  );
}
