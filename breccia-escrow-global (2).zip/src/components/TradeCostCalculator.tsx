import React, { useState } from 'react';
import { Calculator, DollarSign, Truck, Percent } from 'lucide-react';

export default function TradeCostCalculator() {
  const [amount, setAmount] = useState<number>(10000);
  const [currency, setCurrency] = useState<'USD' | 'EUR' | 'NGN' | 'GHS' | 'ZAR'>('USD');
  const [complexity, setComplexity] = useState<number>(3); // 1-5 scale

  // Fees calculation
  const escrowFeeRate = 0.01; // 1%
  const convFeeRate = 0.005; // 0.5%
  
  const escrowFee = amount * escrowFeeRate;
  const convFee = amount * convFeeRate;
  const shippingEstimate = complexity * 500; // Simplified
  const totalCost = amount + escrowFee + convFee + shippingEstimate;

  return (
    <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4" id="trade-cost-calculator">
      <div className="border-b border-neutral-900 pb-3">
        <span className="text-[9px] font-mono tracking-widest text-gold-accent font-bold uppercase block">Tool</span>
        <h4 className="font-display font-medium text-stone-200 text-sm mt-0.5 uppercase flex items-center gap-2">
          <Calculator className="w-4 h-4" />
          Trade Cost Calculator
        </h4>
      </div>

      <div className="space-y-3">
        <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold">Base Trade Amount ({currency})</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
          className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white"
        />

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Currency</label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as any)}
              className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white"
            >
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="NGN">NGN</option>
              <option value="GHS">GHS</option>
              <option value="ZAR">ZAR</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Logistics Complexity (1-5)</label>
            <input
              type="number"
              min="1"
              max="5"
              value={complexity}
              onChange={(e) => setComplexity(parseInt(e.target.value) || 1)}
              className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white"
            />
          </div>
        </div>
      </div>

      <div className="border-t border-neutral-900 pt-4 space-y-2 font-mono text-[11px] text-zinc-400">
        <div className="flex justify-between">
          <span>Escrow Fee (1%):</span>
          <span className="text-white">${escrowFee.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
        </div>
        <div className="flex justify-between">
          <span>Conv. Fee (0.5%):</span>
          <span className="text-white">${convFee.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
        </div>
        <div className="flex justify-between">
          <span>Shipping Est.:</span>
          <span className="text-white">${shippingEstimate.toLocaleString()}</span>
        </div>
        <div className="flex justify-between border-t border-neutral-900 pt-2 text-gold-accent font-bold">
          <span>Total Estimated:</span>
          <span>${totalCost.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
        </div>
      </div>
    </div>
  );
}
