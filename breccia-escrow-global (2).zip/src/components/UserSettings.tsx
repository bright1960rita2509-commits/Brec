import React, { useState, useRef } from 'react';
import { UploadCloud, ShieldCheck, CheckCircle2, Clock, Info, User, FileText, RefreshCw, Camera, X } from 'lucide-react';

export default function UserSettings() {
  const [activeTab, setActiveTab] = useState<'profile' | 'kyc'>('kyc');
  const [files, setFiles] = useState<{ name: string; progress: number; status: 'uploading' | 'completed' | 'error' }[]>([]);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const startCamera = async () => {
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
       const stream = videoRef.current.srcObject as MediaStream;
       stream.getTracks().forEach(track => track.stop());
       videoRef.current.srcObject = null;
    }
    setShowCamera(false);
  };

  const capturePhoto = () => {
      if (videoRef.current && canvasRef.current) {
          const context = canvasRef.current.getContext('2d');
          if (context) {
            context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
            canvasRef.current.toBlob(blob => {
                if (blob) {
                    const file = new File([blob], `capture_${Date.now()}.jpg`, { type: "image/jpeg" });
                    simulateUpload(file);
                    stopCamera();
                }
            }, 'image/jpeg');
          }
      }
  };

  const simulateUpload = (file: File) => {
    const newFile = { name: file.name, progress: 0, status: 'uploading' as const };
    setFiles((prev) => [...prev, newFile]);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      setFiles((prev) =>
        prev.map((f) => {
          if (f.name === file.name) {
            return {
              ...f,
              progress: Math.min(progress, 100),
              status: progress >= 100 ? 'completed' : 'uploading',
            };
          }
          return f;
        })
      );

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => setShowFeedbackModal(true), 500);
      }
    }, 500);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    droppedFiles.forEach(simulateUpload);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      selectedFiles.forEach(simulateUpload);
    }
  };

  return (
    <div className="space-y-8 py-6 w-full max-w-5xl mx-auto" id="user-settings-root">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-neutral-900 pb-4">
        <div>
          <h2 className="text-2xl font-display font-medium text-white uppercase tracking-wider">Settings & Compliance</h2>
          <p className="text-sm font-mono text-neutral-400 mt-1">Manage your account credentials and verification levels.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Nav */}
        <div className="w-full md:w-64 space-y-2 font-mono text-sm">
          <button
            onClick={() => setActiveTab('profile')}
            className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              activeTab === 'profile' ? 'bg-neutral-900 text-gold-accent border-l-2 border-gold-accent' : 'text-neutral-500 hover:text-white hover:bg-neutral-900/50 hover:border-l-2 hover:border-neutral-600'
            }`}
          >
            <User className="w-4 h-4" /> Personal Details
          </button>
          <button
            onClick={() => setActiveTab('kyc')}
            className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              activeTab === 'kyc' ? 'bg-neutral-900 text-gold-accent border-l-2 border-gold-accent' : 'text-neutral-500 hover:text-white hover:bg-neutral-900/50 hover:border-l-2 hover:border-neutral-600'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> KYC Verification
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1">
          {activeTab === 'kyc' && (
            <div className="glass-panel p-6 rounded-2xl border border-gold-400/20 shadow-xl space-y-6 bg-neutral-950/40">
              <div>
                <h3 className="text-lg font-display font-bold text-white mb-1 uppercase text-gold-gradient">Identity Documentation</h3>
                <p className="text-xs text-neutral-400 font-sans">
                  Upload strict compliance documents required for international exporter clearance and Tier-3 wallet unlocking.
                </p>
              </div>

              {/* Upload Zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center text-center transition-all cursor-pointer bg-neutral-950/60
                  ${isDragOver ? 'border-gold-accent bg-gold-accent/5 scale-[1.01]' : 'border-neutral-800 hover:border-gold-400/50'}
                `}
                onClick={() => document.getElementById('kyc-uploader')?.click()}
              >
                <div className="w-14 h-14 bg-neutral-900 rounded-full flex items-center justify-center mb-4">
                  <UploadCloud className={`w-7 h-7 ${isDragOver ? 'text-gold-accent' : 'text-neutral-500'}`} />
                </div>
                <h4 className="font-mono text-sm text-white font-bold tracking-wider mb-2">DRAG AND DROP DOCUMENTS HERE</h4>
                <p className="text-xs text-neutral-500 mb-4 px-8">
                  Support formats: PDF, JPG, PNG. Maximum file size: 10MB.<br />
                  Accepted files: Government ID, Passports, Bill of Registration, SGS Certs.
                </p>
                <div className="flex gap-4">
                  <button
                    onClick={() => document.getElementById('kyc-uploader')?.click()}
                    className="px-5 py-2 font-mono text-xs text-black font-extrabold bg-gold-gradient rounded-md tracking-wider"
                  >
                    BROWSE FILES
                  </button>
                  <button
                    onClick={startCamera}
                    className="px-5 py-2 font-mono text-xs text-white bg-neutral-800 rounded-md tracking-wider flex items-center gap-2 hover:bg-neutral-700"
                  >
                    <Camera className="w-3 h-3" /> CAPTURE DOCUMENT
                  </button>
                </div>
                <input
                  id="kyc-uploader"
                  type="file"
                  multiple
                  accept=".pdf, .png, .jpg, .jpeg"
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>

              {/* Uploading List */}
              {files.length > 0 && (
                <div className="space-y-3 mt-6">
                  <h4 className="font-mono text-[10px] text-neutral-500 tracking-widest uppercase mb-2">Uploaded & Processing Files</h4>
                  {files.map((file, idx) => (
                    <div key={idx} className="bg-neutral-900 p-3 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <FileText className="w-4 h-4 text-neutral-500" />
                        <div>
                          <span className="block text-xs font-mono text-neutral-300">{file.name}</span>
                          {file.status === 'uploading' ? (
                            <span className="block text-[10px] text-blue-400 mt-1 tracking-wider uppercase flex items-center gap-1">
                              <RefreshCw className="w-3 h-3 animate-spin" /> Verifying... {file.progress}%
                            </span>
                          ) : (
                            <span className="block text-[10px] text-emerald-500 mt-1 tracking-wider uppercase flex items-center gap-1 font-bold">
                              <CheckCircle2 className="w-3 h-3" /> Encrypted & Analyzed
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {file.status === 'uploading' && (
                         <div className="w-24 h-1 bg-neutral-950 rounded overflow-hidden">
                           <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${file.progress}%` }}></div>
                         </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'profile' && (
             <div className="py-12 text-center text-neutral-500 font-mono text-sm border border-neutral-900 rounded-xl bg-neutral-950/20">
                Personal details tab is currently disabled in this demo environment.
             </div>
          )}
        </div>
      </div>

      {/* Camera Modal */}
      {showCamera && (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-6 relative">
             <button onClick={stopCamera} className="absolute top-4 right-4 text-white"><X /></button>
             <h3 className="text-white font-mono text-xs mb-4">CAPTURE DOCUMENT</h3>
             <video ref={videoRef} className="w-full h-64 object-cover rounded-lg bg-black" />
             <canvas ref={canvasRef} width="640" height="480" className="hidden" />
             <button
               onClick={capturePhoto}
               className="w-full mt-6 py-3 bg-gold-gradient text-black font-extrabold text-xs rounded-lg uppercase tracking-wider"
             >
               Capture Photo
             </button>
          </div>
        </div>
      )}

      {/* Under Review Modal */}
      {showFeedbackModal && (
        <div className="fixed inset-0 bg-neutral-950/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-gold-400/40 p-6 rounded-2xl shadow-2xl relative text-center">
            <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-500/30">
              <Clock className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-xl font-display font-medium text-white mb-2 tracking-wider">DOCUMENTS UNDER REVIEW</h3>
            <p className="text-sm font-sans text-neutral-400 mb-6 leading-relaxed">
              Your identity documentation has been securely transmitted to the Breccia Compliance Team. Manual review typically takes 24-48 business hours. 
              We will notify you via email once your Tier-3 clearance is approved.
            </p>
            <button
              onClick={() => setShowFeedbackModal(false)}
              className="w-full py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-mono text-xs font-bold rounded-lg tracking-widest transition-colors"
            >
              ACKNOWLEDGE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
