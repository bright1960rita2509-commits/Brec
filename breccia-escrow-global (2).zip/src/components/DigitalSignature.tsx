import React from 'react';
import { EscrowTransaction, User } from '../types';

interface DigitalSignatureProps {
  transaction: EscrowTransaction;
  currentUser: User;
  onSign: (txId: string) => void;
}

export const DigitalSignature: React.FC<DigitalSignatureProps> = ({ transaction, currentUser, onSign }) => {
  const isBuyer = currentUser.role === 'buyer';
  const isSigned = isBuyer ? !!transaction.buyerSigned : !!transaction.sellerSigned;

  return (
    <div className="space-y-4">
      {isSigned ? (
        <div className="p-3 bg-emerald-900/20 border border-emerald-800 rounded text-xs text-emerald-400 font-mono">
          Agreement Signed by {currentUser.name} at {isBuyer ? transaction.buyerSigned?.signedAt : transaction.sellerSigned?.signedAt}
        </div>
      ) : (
        <button
          onClick={() => onSign(transaction.id)}
          className="w-full px-4 py-2 bg-gold-accent text-black text-xs font-bold font-mono rounded hover:bg-gold-accent/90 transition-colors"
        >
          Digitally Sign Agreement
        </button>
      )}
    </div>
  );
};
