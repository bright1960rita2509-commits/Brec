/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, Landmark, Check, AlertOctagon, UserCheck, RefreshCw, BarChart3, TrendingUp, Handshake, ChevronRight, FileText, Download, History, X, Activity, Users, Cpu, AlertTriangle, ArrowUp } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { SupplierProfile, Dispute, EscrowTransaction, Document } from '../types';
import RiskMap from './RiskMap';

// Mock data for sparkline trend (last 30 days)
const disputeTrendData = Array.from({ length: 30 }, () => ({
  value: Math.floor(Math.random() * 10),
}));

// Mock data for historical monthly volume
const volumeTrendData = [
    { month: 'Jan', volume: 450000 },
    { month: 'Feb', volume: 480000 },
    { month: 'Mar', volume: 520000 },
    { month: 'Apr', volume: 490000 },
    { month: 'May', volume: 550000 },
    { month: 'Jun', volume: 600000 },
];

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState<'disputes' | 'verification' | 'transactions' | 'documents'>('disputes');
  const [language, setLanguage] = useState('English');
  const [loading, setLoading] = useState(false);
  const [showAuditLog, setShowAuditLog] = useState<Dispute | null>(null);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [documents, setDocuments] = useState<Document[]>(() => [
    { id: '1', transactionId: 'BRC-901A', title: 'SGS Inspection Report', type: 'Inspection', uploadDate: '2026-05-28', size: '2.4 MB' },
    { id: '2', transactionId: 'BRC-901A', title: 'Commercial Invoice', type: 'Invoice', uploadDate: '2026-05-29', size: '1.1 MB' },
  ]);

  // Exporters wanting verification
  const [pendingExporters, setPendingExporters] = useState<SupplierProfile[]>(() => {
    return [
      { id: "e_1", companyName: "Accra Shea-Butter Co-ops", country: "Ghana", category: "Agriculture", description: "Direct sun-dried shea extract bulk processor looking to expand into central EU markets.", products: [], verificationBadge: false, rating: 4.1, exportCapability: "200 Tons Monthly" },
      { id: "e_2", companyName: "Abuja Zinc Ore Harvesters Ltd", country: "Nigeria", category: "Natural Resources", description: "High purity non-oxidized zinc and industrial copper concentrate exporter based out of Port Harcourt.", products: [], verificationBadge: false, rating: 4.4, exportCapability: "9,000 Tons Semiannually" }
    ];
  });

  // Hot disputes list
  const [disputes, setDisputes] = useState<Dispute[]>(() => {
    const saved = localStorage.getItem('breccia_admin_disputes');
    if (saved) return JSON.parse(saved);

    return [
      {
        id: "dsp_1",
        transactionId: "BRC-901A",
        transactionTitle: "Grade-A Sun-Dried Cashew Kernels Sourcing",
        amount: 15400,
        raisedBy: "buyer",
        reason: "SGS cargo report claims moisture target holds at 8.9% which violates the pre-agreed contract threshold of 7.5% maximum. Exporter refused immediate re-drying.",
        status: "open",
        createdAt: "2026-05-28",
        chatHistory: [
          { sender: "Buyer", text: "We cannot accept cashews with 8.9% moisture. They will mold prior to reaching Antwerp harbor.", time: "2026-05-28" },
          { sender: "Seller", text: "The vessel took heavy fog during terminal loading in Tema. This is a force majeure, we did not cause this.", time: "2026-05-29" }
        ],
        auditLog: [
            { timestamp: "2026-05-28 09:00:00", action: "Dispute opened by buyer", actor: "System" },
            { timestamp: "2026-05-28 10:00:00", action: "Priority set to High", actor: "System" }
        ]
      },
      {
        id: "dsp_2",
        transactionId: "BRC-882C",
        transactionTitle: "15,000 Yards Grade A Indigo Dye Cotton Sacks",
        amount: 8500,
        raisedBy: "buyer",
        reason: "Delay in custom export clearance at Lagos. Seller is unresponsive to container relocation requests.",
        status: "open",
        createdAt: "2026-05-30",
        chatHistory: [],
        auditLog: [
            { timestamp: "2026-05-30 14:00:00", action: "Dispute opened by buyer", actor: "System" }
        ]
      }
    ];
  });

  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(disputes[0]);
  const [officerMessage, setOfficerMessage] = useState('');
  const [selectedDisputeIds, setSelectedDisputeIds] = useState<Set<string>>(new Set());

  const handleToggleSelectDispute = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newSelected = new Set(selectedDisputeIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedDisputeIds(newSelected);
  };

  const handleSelectAllDisputes = () => {
    if (selectedDisputeIds.size === disputes.length && disputes.length > 0) {
      setSelectedDisputeIds(new Set());
    } else {
      setSelectedDisputeIds(new Set(disputes.map(d => d.id)));
    }
  };

  const handleBulkAssignToMe = () => {
    if (selectedDisputeIds.size === 0) return;
    const updated = disputes.map(d => selectedDisputeIds.has(d.id) ? { ...d, assignedTo: 'Admin' } : d);
    setDisputes(updated);
    if (selectedDispute && selectedDisputeIds.has(selectedDispute.id)) {
      setSelectedDispute(updated.find(u => u.id === selectedDispute.id) || null);
    }
    setSelectedDisputeIds(new Set());
    toast.success("Assigned to you");
  };

  const handleBulkMarkUnderReview = () => {
    if (selectedDisputeIds.size === 0) return;
    const updated = disputes.map(d => selectedDisputeIds.has(d.id) ? { ...d, status: 'under_review' as const } : d);
    setDisputes(updated);
    if (selectedDispute && selectedDisputeIds.has(selectedDispute.id)) {
      setSelectedDispute(updated.find(u => u.id === selectedDispute.id) || null);
    }
    setSelectedDisputeIds(new Set());
    toast.success("Marked as Under Review");
  };

  // Core global transactions running
  const [transactions, setTransactions] = useState<EscrowTransaction[]>(() => {
    return JSON.parse(localStorage.getItem('breccia_transactions') || '[]');
  });

  useEffect(() => {
    localStorage.setItem('breccia_admin_disputes', JSON.stringify(disputes));
  }, [disputes]);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const handleVerifyExporter = (id: string) => {
    setLoading(true);
    setTimeout(() => {
      setPendingExporters(prev => prev.filter(e => e.id !== id));
      setLoading(false);
      toast.success("Verification Badge Authorized! Exporter listed as Verified Partner on Trade Board.");
    }, 800);
  };

  const handleResolveDispute = (disputeId: string, resolution: 'buyer' | 'seller') => {
    setLoading(true);
    setTimeout(() => {
      const updated = disputes.map(d => {
        if (d.id === disputeId) {
          return {
            ...d,
            status: resolution === 'buyer' ? 'resolved_buyer' as const : 'resolved_seller' as const,
          };
        }
        return d;
      });

      setDisputes(updated);
      setSelectedDispute(updated.find(u => u.id === disputeId) || null);
      
      // Also notify/remedy active escrow transactions if matched
      const currentDispute = disputes.find(d => d.id === disputeId);
      if (currentDispute) {
        const matchingTxId = currentDispute.transactionId;
        const savedTxs: EscrowTransaction[] = JSON.parse(localStorage.getItem('breccia_transactions') || '[]');
        const updatedTxs = savedTxs.map(t => {
          if (t.id === matchingTxId) {
            return {
              ...t,
              status: resolution === 'buyer' ? 'cancelled' as const : 'completed' as const,
              terms: `${t.terms} [Arbitration Ruling: Case resolved in favor of the ${resolution.toUpperCase()}. Funds dispersed accordingly.]`
            };
          }
          return t;
        });
        localStorage.setItem('breccia_transactions', JSON.stringify(updatedTxs));
        setTransactions(updatedTxs);
      }

      setLoading(false);
    }, 600);
  };

  const handleSetPriority = (disputeId: string, priority: 'Low' | 'Medium' | 'High') => {
    const updated = disputes.map(d => d.id === disputeId ? { ...d, priority } : d);
    setDisputes(updated);
    if (selectedDispute && selectedDispute.id === disputeId) {
      setSelectedDispute(updated.find(u => u.id === disputeId) || null);
    }
  };

  const handlePostOfficerMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!officerMessage || !selectedDispute) return;

    const updated = disputes.map(d => {
      if (d.id === selectedDispute.id) {
        return {
          ...d,
          chatHistory: [
            ...d.chatHistory,
            { sender: "Dispute Arbitrator", text: officerMessage, time: new Date().toLocaleTimeString() }
          ]
        };
      }
      return d;
    });

    setDisputes(updated);
    setSelectedDispute(updated.find(u => u.id === selectedDispute.id) || null);
    setOfficerMessage('');
  };

  const handleExportCSV = () => {
    const activeDisputes = disputes.filter(d => d.status === 'open' || d.status === 'under_review');
    if (activeDisputes.length === 0) {
       toast.error('No active disputes to export.');
       return;
    }
    
    const headers = ['ID', 'Transaction ID', 'Title', 'Amount', 'Reason', 'Priority', 'Status', 'Created At'];
    const rows = activeDisputes.map(d => [
      d.id,
      d.transactionId,
      `"${d.transactionTitle.replace(/"/g, '""')}"`,
      d.amount,
      `"${d.reason.replace(/"/g, '""')}"`,
      d.priority || 'N/A',
      d.status,
      d.createdAt
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(row => row.join(","))].join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `active_disputes_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportTransactionsCSV = () => {
    if (transactions.length === 0) {
      toast.error('No transactions to export.');
      return;
    }

    const headers = ['ID', 'Title', 'Buyer', 'Seller', 'Amount', 'Currency', 'Status'];
    const rows = transactions.map(t => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      t.buyerName,
      t.sellerName,
      t.amount,
      t.currency,
      t.status
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(row => row.join(","))].join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `transactions_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Transactions exported successfully.");
  };

  return (
    <div className="space-y-8 px-2" id="admin-panel-main">
      <div className="flex justify-end">
        <select 
          value={language} 
          onChange={(e) => setLanguage(e.target.value)}
          className="bg-neutral-900 border border-neutral-800 text-[10px] font-mono py-1 px-2 rounded-lg text-white focus:outline-none focus:border-gold-accent cursor-pointer"
        >
          {['English', 'French', 'Norwegian', 'Finnish', 'Spanish', 'Portuguese', 'Arabic', 'Hindi', 'Chinese', 'Japanese'].map(lang => (
            <option key={lang} value={lang}>{lang}</option>
          ))}
        </select>
      </div>

      {/* System Status Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center gap-3">
          <Activity className="w-5 h-5 text-emerald-400" />
          <div>
            <div className="text-[10px] text-zinc-500 font-mono font-bold">System Health</div>
            <div className="text-sm font-bold text-white">99.98% Uptime</div>
          </div>
        </div>
        <div className="glass-panel p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center gap-3">
          <Users className="w-5 h-5 text-blue-400" />
          <div>
            <div className="text-[10px] text-zinc-500 font-mono font-bold">Active Users</div>
            <div className="text-sm font-bold text-white">1,240 Online</div>
          </div>
        </div>
        <div className="glass-panel p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center gap-3">
          <Cpu className="w-5 h-5 text-amber-400" />
          <div>
            <div className="text-[10px] text-zinc-500 font-mono font-bold">System Load</div>
            <div className="text-sm font-bold text-white">12% Utilization</div>
          </div>
        </div>
        <div className="glass-panel p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400" />
          <div>
            <div className="text-[10px] text-zinc-500 font-mono font-bold">Security Risk</div>
            <div className="text-sm font-bold text-white">Low Threshold</div>
          </div>
        </div>
      </div>

      {/* Visual Analytics Header */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4" id="admin-metrics-grid">
        <div className="glass-panel p-5 rounded-xl border border-gold-400/10 bg-neutral-900/10">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Safeguarded Capital</span>
            <BarChart3 className="w-4.5 h-4.5 text-gold-accent" />
          </div>
          <div className="text-xl font-display font-black text-gold-gradient mt-2">$502,484,200</div>
          <div className="text-[9px] font-mono mt-1 text-emerald-400 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            +18.4% monthly trade boost
          </div>
        </div>

        <div className="glass-panel p-5 rounded-xl border border-gold-400/10 bg-neutral-900/10 relative overflow-hidden">
          <div className="flex justify-between items-start relative z-10">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Dispute Volume (30d)</span>
            <AlertOctagon className="w-4.5 h-4.5 text-gold-accent" />
          </div>
          <div className="text-xl font-display font-black text-white mt-2 relative z-10">{disputes.length} active</div>
          <div className="absolute bottom-0 left-0 right-0 h-16 opacity-30">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={disputeTrendData}>
                <Line type="monotone" dataKey="value" stroke="#fbbf24" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-xl border border-gold-400/10 bg-neutral-900/10">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">KYC/AML Status</span>
            <ShieldCheck className="w-4.5 h-4.5 text-gold-accent" />
          </div>
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-zinc-400">Identity</span>
              <span className="text-white">85%</span>
            </div>
            <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
              <div className="h-full bg-gold-accent" style={{ width: '85%' }}></div>
            </div>
          </div>
          <div className="mt-3 space-y-2">
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-zinc-400">AML</span>
              <span className="text-white">92%</span>
            </div>
            <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500" style={{ width: '92%' }}></div>
            </div>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-xl border border-gold-400/10 bg-neutral-900/10 col-span-2">
            <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Historical Trade Volume</span>
                <TrendingUp className="w-4.5 h-4.5 text-gold-accent" />
            </div>
            <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={volumeTrendData}>
                        <XAxis dataKey="month" stroke="#525252" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis stroke="#525252" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value / 1000}k`} />
                        <Tooltip contentStyle={{ backgroundColor: '#171717', borderColor: '#262626', fontSize: '10px' }} />
                        <Line type="monotone" dataKey="volume" stroke="#fbbf24" strokeWidth={3} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>
      
      {/* Risk Map Section */}
      <div className="grid grid-cols-1 gap-4">
        <div className="glass-panel p-5 rounded-xl border border-gold-400/10 bg-neutral-900/10">
            <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Geographical Risk Visualization</span>
            </div>
            <RiskMap />
        </div>
      </div>


      {/* Main admin navigation tabs */}
      <div className="flex bg-neutral-950 p-1.5 rounded-lg border border-neutral-900 justify-start gap-3">
        <button
          onClick={() => setActiveTab('disputes')}
          className={`px-4 py-2 text-xs font-mono tracking-widest rounded transition-all font-semibold ${
            activeTab === 'disputes' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          DISPUTE RESOLUTION ({disputes.filter(d => d.status === 'open' || d.status === 'under_review').length})
        </button>
        <button
          onClick={() => setActiveTab('verification')}
          className={`px-4 py-2 text-xs font-mono tracking-widest rounded transition-all font-semibold ${
            activeTab === 'verification' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          SUPPLIER COMPLIANCE ({pendingExporters.length})
        </button>
        <button
          onClick={() => setActiveTab('transactions')}
          className={`px-4 py-2 text-xs font-mono tracking-widest rounded transition-all font-semibold ${
            activeTab === 'transactions' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          GLOBAL ESCROW LEDGER ({transactions.length})
        </button>
        <button
          onClick={() => setActiveTab('documents')}
          className={`px-4 py-2 text-xs font-mono tracking-widest rounded transition-all font-semibold ${
            activeTab === 'documents' ? 'bg-gold-gradient text-black font-bold' : 'text-neutral-400 hover:text-white'
          }`}
        >
          DOCUMENT ARCHIVE ({documents.length})
        </button>
      </div>

      {/* Verification content */}
      {activeTab === 'verification' && (
        <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-4" id="compliance-verification-box">
          <div className="border-b border-neutral-900 pb-3">
            <h4 className="font-display font-bold text-base text-stone-200">EXPORTER COMPLIANCE DESK</h4>
            <p className="text-[10px] font-mono text-neutral-500">Cross-reference corporate registration documents, tax IDs, and physical warehouse checks in Port West-Africa.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingExporters.length === 0 ? (
              <div className="md:col-span-2 text-center py-10 font-mono text-xs text-zinc-500">No active African exporters waiting for verification. All accounts cleared!</div>
            ) : (
              pendingExporters.map(exp => (
                <div key={exp.id} className="p-4 rounded-xl bg-neutral-950 border border-neutral-850 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h5 className="font-display font-bold text-white text-sm">{exp.companyName}</h5>
                      <span className="text-[10px] text-zinc-500 font-mono">📍 Region: {exp.country} | Capacity: {exp.exportCapability}</span>
                    </div>
                    <span className="text-[9px] bg-amber-500/5 text-amber-400 font-mono border border-amber-500/20 px-2 py-0.5 rounded">AWAITING COMPLIANCE AUDIT</span>
                  </div>
                  <p className="text-[11px] text-stone-400 leading-relaxed font-sans">{exp.description}</p>
                  
                  <div className="pt-2 flex justify-end gap-3 border-t border-neutral-900">
                    <button
                      onClick={() => handleVerifyExporter(exp.id)}
                      disabled={loading}
                      className="px-4 py-1.5 rounded bg-gold-gradient text-black font-mono text-[10px] font-bold tracking-widest hover:opacity-90 flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      AUTHORIZE EXPORTER
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Disputes content */}
      {activeTab === 'disputes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="compliance-disputes-grid">
          
          {/* List (5 columns) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleSelectAllDisputes}
                  className="w-4 h-4 border border-neutral-700 rounded bg-neutral-900 flex items-center justify-center hover:border-gold-accent transition-colors relative"
                >
                  {selectedDisputeIds.size === disputes.length && disputes.length > 0 && <Check className="w-3 h-3 text-gold-accent absolute" />}
                  {selectedDisputeIds.size > 0 && selectedDisputeIds.size < disputes.length && <div className="w-2 h-2 bg-gold-accent rounded-sm absolute" />}
                </button>
                <h3 className="font-display font-bold text-stone-200">Active Disputes</h3>
              </div>
              <div className="flex items-center gap-2 flex-wrap justify-end">
                {selectedDisputeIds.size > 0 && (
                  <>
                    <button
                      onClick={handleBulkAssignToMe}
                      className="px-2 py-1 bg-gold-accent/10 border border-gold-accent/30 rounded text-[9px] font-mono font-bold text-gold-accent hover:bg-gold-accent/20 transition-colors"
                    >
                      Assign to Me
                    </button>
                    <button
                      onClick={handleBulkMarkUnderReview}
                      className="px-2 py-1 bg-amber-500/10 border border-amber-500/30 rounded text-[9px] font-mono font-bold text-amber-500 hover:bg-amber-500/20 transition-colors"
                    >
                      Under Review
                    </button>
                  </>
                )}
                <button
                  onClick={handleExportCSV}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-[10px] font-mono text-neutral-400 hover:text-white transition-colors"
                  title="Export active disputes as CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                  EXPORT CSV
                </button>
              </div>
            </div>
            {disputes.length === 0 ? (
               <div className="py-20 flex flex-col items-center justify-center text-center text-zinc-500 border border-neutral-850 border-dashed rounded-xl bg-neutral-900/5 font-mono text-xs space-y-4">
                 <div className="w-16 h-16 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800">
                   <ShieldCheck className="w-8 h-8 text-neutral-600" />
                 </div>
                 <span className="block font-bold text-white max-w-xs mx-auto">No Active Disputes</span>
               </div>
            ) : disputes.map(disp => (
              <div
                key={disp.id}
                onClick={() => setSelectedDispute(disp)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedDispute?.id === disp.id 
                    ? 'bg-neutral-900/80 border-gold-accent' 
                    : 'bg-neutral-950 border-neutral-850 hover:bg-neutral-900/30'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <button
                      onClick={(e) => handleToggleSelectDispute(e, disp.id)}
                      className="mt-1 w-4 h-4 border border-neutral-700 rounded bg-neutral-900 flex items-center justify-center hover:border-gold-accent transition-colors shrink-0"
                    >
                      {selectedDisputeIds.has(disp.id) && <Check className="w-3 h-3 text-gold-accent" />}
                    </button>
                    <div>
                      <span className="text-[9px] font-mono text-gold-accent font-bold block">{disp.transactionId}</span>
                      <span className="font-display font-bold text-xs text-stone-100 line-clamp-1 mt-0.5">{disp.transactionTitle}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-wrap justify-end">
                    {disp.assignedTo && (
                      <span className="text-[9px] px-2 py-0.5 font-mono rounded font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                        {disp.assignedTo}
                      </span>
                    )}
                    {disp.priority && (
                      <span className={`text-[9px] px-2 py-0.5 font-mono rounded font-bold ${
                        disp.priority === 'High' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' :
                        disp.priority === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                        'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                      }`}>
                        {disp.priority}
                      </span>
                    )}
                    {disp.status === 'evidence_gathering' ? (
                      <span className="text-[9px] px-2 py-0.5 font-mono rounded bg-blue-500/5 text-blue-400 border border-blue-500/25 font-bold uppercase">
                        Evidence Gathering
                      </span>
                    ) : disp.status === 'arbitrator_assessment' ? (
                      <span className="text-[9px] px-2 py-0.5 font-mono rounded bg-purple-500/5 text-purple-400 border border-purple-500/25 font-bold uppercase">
                        Arbitrator Assessment
                      </span>
                    ) : disp.status === 'under_review' ? (
                      <span className="text-[9px] px-2 py-0.5 font-mono rounded bg-amber-500/5 text-amber-400 border border-amber-500/25 font-bold uppercase">
                        UNDER REVIEW
                      </span>
                    ) : (
                      <span className={`text-[9px] px-2 py-0.5 font-mono rounded font-bold uppercase ${
                        disp.status === 'open' 
                          ? 'bg-red-500/5 text-red-400 border border-red-500/25' 
                          : 'bg-emerald-500/5 text-emerald-400 border border-emerald-500/25'
                      }`}>
                        {disp.status}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex justify-between items-center mt-3 text-[10px] font-mono text-zinc-500 border-t border-neutral-900 pt-2">
                  <span>Involved Capital: <span className="text-white font-bold">${disp.amount.toLocaleString()}</span></span>
                  <div className="flex items-center gap-3">
                    <span>Opened: {disp.createdAt}</span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); setShowAuditLog(disp); }}
                      className="flex items-center gap-1 text-gold-accent hover:text-gold-400 font-bold"
                    >
                      <History className="w-3 h-3" />
                      LOG
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Adjudication Deck (7 columns) */}
          <div className="lg:col-span-7">
            {selectedDispute ? (
              <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-6">
                <div className="flex justify-between items-start border-b border-neutral-900 pb-4">
                  <div>
                    <span className="text-[10px] font-mono text-neutral-500">OFFICER MEDIATION CASE: {selectedDispute.transactionId}</span>
                    <h4 className="font-display font-extrabold text-stone-200 text-sm mt-0.5">{selectedDispute.transactionTitle}</h4>
                    <span className="text-[11px] font-mono text-gold-accent font-bold mt-1 block">Arbitration Target Balance: ${selectedDispute.amount.toLocaleString()} USD</span>
                  </div>
                  
                  {(selectedDispute.status === 'open' || selectedDispute.status === 'under_review') ? (
                    <div className="flex flex-col gap-3 items-end">
                      <div className="flex items-center gap-2">
                        <label className="text-[10px] font-mono text-neutral-500 uppercase font-bold tracking-wider">Priority:</label>
                        <select 
                          value={selectedDispute.priority || ''}
                          onChange={(e) => handleSetPriority(selectedDispute.id, e.target.value as any)}
                          className="bg-neutral-900 border border-neutral-800 text-[10px] font-mono py-1 px-2 rounded-lg text-white focus:outline-none focus:border-gold-accent cursor-pointer"
                        >
                          <option value="" disabled>Set Priority</option>
                          <option value="Low">Low</option>
                          <option value="Medium">Medium</option>
                          <option value="High">High</option>
                        </select>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleResolveDispute(selectedDispute.id, 'buyer')}
                          className="px-3 py-1.5 rounded bg-red-900/20 text-red-400 border border-red-900/40 text-[10px] font-mono font-bold hover:bg-neutral-900"
                        >
                          Refund Importer
                        </button>
                        <button
                          onClick={() => {
                              const updated = disputes.map(d => d.id === selectedDispute.id ? { ...d, status: 'evidence_gathering' } : d);
                              setDisputes(updated);
                              setSelectedDispute(updated.find(u => u.id === selectedDispute.id) || null);
                              toast.success("Evidence requested from parties");
                          }}
                          className="px-3 py-1.5 rounded bg-blue-900/20 text-blue-400 border border-blue-900/40 text-[10px] font-mono font-bold hover:bg-neutral-900"
                        >
                          Request Evidence
                        </button>
                        <button
                          onClick={() => {
                              const updated = disputes.map(d => d.id === selectedDispute.id ? { ...d, status: 'arbitrator_assessment' } : d);
                              setDisputes(updated);
                              setSelectedDispute(updated.find(u => u.id === selectedDispute.id) || null);
                              toast.success("Case moved to Arbitrator Assessment");
                          }}
                          className="px-3 py-1.5 rounded bg-purple-900/20 text-purple-400 border border-purple-900/40 text-[10px] font-mono font-bold hover:bg-neutral-900"
                        >
                          To Assessment
                        </button>
                        <button
                          onClick={() => handleResolveDispute(selectedDispute.id, 'seller')}
                          className="px-3 py-1.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono font-bold hover:bg-neutral-900"
                        >
                          Compensate Exporter
                        </button>
                      </div>
                    </div>
                  ) : (
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/5 px-3 py-1 rounded border border-emerald-500/20 font-bold uppercase">
                      CASE SETTLED
                    </span>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-850 space-y-1 text-left">
                    <span className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-bold">Filing Exporter Complaint:</span>
                    <div className="flex gap-2 pt-1 text-xs text-white">
                      <AlertOctagon className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="font-sans text-[11px] leading-relaxed text-zinc-300">{selectedDispute.reason}</p>
                    </div>
                  </div>

                  {/* Arbitration chat */}
                  <div className="space-y-3 pt-2">
                    <div className="text-[9px] font-mono text-stone-500 uppercase tracking-widest font-bold">Mediation Logs:</div>
                    <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                      {selectedDispute.chatHistory.length === 0 ? (
                        <div className="text-center py-6 font-mono text-[10px] text-zinc-500">No communication logs recorded yet.</div>
                      ) : (
                        selectedDispute.chatHistory.map((ch, idx) => (
                          <div key={idx} className={`p-2.5 rounded-lg text-[10px] font-mono text-left ${
                            ch.sender.includes('Arbitrator') 
                              ? 'bg-gold-accent/5 border border-gold-accent/25 text-gold-accent' 
                              : 'bg-neutral-900 text-stone-300'
                          }`}>
                            <div className="flex justify-between items-center mb-1">
                              <span className="font-bold">{ch.sender}</span>
                              <span className="text-[8px] text-neutral-500">{ch.time}</span>
                            </div>
                            <p className="font-sans text-[11px] leading-normal text-stone-300">{ch.text}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {(selectedDispute.status === 'open' || selectedDispute.status === 'under_review') && (
                    <form onSubmit={handlePostOfficerMsg} className="flex gap-2 pt-2 border-t border-neutral-900">
                      <input
                        type="text"
                        value={officerMessage}
                        onChange={(e) => setOfficerMessage(e.target.value)}
                        placeholder="Intervene in case. Paste regulatory guidelines here..."
                        className="flex-1 bg-neutral-950 border border-neutral-850 px-3 py-2 text-xs rounded-lg text-white font-medium focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded bg-gold-gradient text-black font-semibold text-xs font-mono"
                      >
                        SEND ADVISORY
                      </button>
                    </form>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-20 bg-neutral-950 rounded-2xl border border-neutral-900 font-mono text-xs text-zinc-500">Select an escalation file from the left to review.</div>
            )}
          </div>
        </div>
      )}

      {/* Transactions list content */}
      {activeTab === 'transactions' && (
        <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-4" id="compliance-ledger-box">
          <div className="border-b border-neutral-900 pb-3 flex justify-between items-center">
            <div>
              <h4 className="font-display font-bold text-base text-stone-200">GLOBAL TRANSACTION REGISTRY</h4>
              <p className="text-[10px] font-mono text-neutral-500">Audit logs tracking global money deposits, release milestones, and active escrow contracts.</p>
            </div>
            <button
              onClick={() => {
                const txs = JSON.parse(localStorage.getItem('breccia_transactions') || '[]');
                setTransactions(txs);
              }}
              className="p-2 border border-neutral-800 hover:border-gold-accent rounded-lg text-neutral-400 hover:text-white cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={handleExportTransactionsCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-[10px] font-mono text-neutral-400 hover:text-white transition-colors"
              title="Export transactions as CSV"
            >
              <Download className="w-3.5 h-3.5" />
              EXPORT CSV
            </button>
          </div>

          <div className="overflow-x-auto">
            {transactions.length === 0 ? (
              <div className="text-center py-10 font-mono text-xs text-zinc-500">No active local trade escrow agreements found in this browser node. Use Buyer Dashboard to issue one.</div>
            ) : (
              <table className="w-full text-left font-mono text-xs text-zinc-400 border-collapse">
                <thead>
                  <tr className="border-b border-neutral-850 text-neutral-500 text-[10px] uppercase font-bold tracking-wider">
                    <th className="py-3 px-2">Escrow Deal ID</th>
                    <th className="py-3 px-2">Description Term</th>
                    <th className="py-3 px-2">Importer (Buyer)</th>
                    <th className="py-3 px-2">Exporter (Seller)</th>
                    <th className="py-3 px-2 text-right">Escrowed Funds</th>
                    <th className="py-3 px-2 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-900/60">
                  {transactions.map(tx => (
                    <tr key={tx.id} className="hover:bg-neutral-900/20">
                      <td className="py-3.5 px-2 font-bold text-gold-accent">{tx.id}</td>
                      <td className="py-3.5 px-2 max-w-[200px] truncate" title={tx.terms}>{tx.title}</td>
                      <td className="py-3.5 px-2">{tx.buyerName}</td>
                      <td className="py-3.5 px-2">{tx.sellerName}</td>
                      <td className="py-3.5 px-2 text-right text-stone-100 font-bold">${tx.amount.toLocaleString()} <span className="text-[9px] text-zinc-500">{tx.currency}</span></td>
                      <td className="py-3.5 px-2 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                          tx.status === 'completed' ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20' :
                          tx.status === 'disputed' ? 'bg-red-500/5 text-red-400 border-red-500/20' :
                          tx.status === 'funded' ? 'bg-blue-500/5 text-blue-400 border-blue-500/20' :
                          'bg-neutral-900 text-neutral-500 border-neutral-800'
                        }`}>
                          {tx.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* Audit Log Modal */}
      {showAuditLog && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-neutral-950 border border-neutral-800 rounded-2xl w-full max-w-lg p-6 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="font-display font-bold text-lg text-stone-200">Dispute Audit Log: {showAuditLog.transactionId}</h3>
              <button onClick={() => setShowAuditLog(null)} className="text-stone-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {showAuditLog.auditLog.map((log, i) => (
                <div key={i} className="flex gap-3 text-xs font-mono text-zinc-400 border-b border-neutral-900 pb-2">
                  <span className="text-zinc-600 w-24 flex-shrink-0">{log.timestamp.split(' ')[1]}</span>
                  <div className="flex-1">
                    <span className="font-bold text-stone-200 block">{log.action}</span>
                    <span className="text-[10px] text-zinc-600">Actor: {log.actor}</span>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => setShowAuditLog(null)} className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-bold text-xs uppercase transition-colors">Close</button>
          </div>
        </div>
      )}

      {/* Document Archive content */}
      {activeTab === 'documents' && (
        <div className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-4" id="document-archive-box">
          <h4 className="font-display font-bold text-base text-stone-200 border-b border-neutral-900 pb-3">DOCUMENT ARCHIVE</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs text-zinc-400 border-collapse">
              <thead>
                <tr className="border-b border-neutral-850 text-neutral-500 text-[10px] uppercase font-bold tracking-wider">
                  <th className="py-3 px-2">Document Title</th>
                  <th className="py-3 px-2">Type</th>
                  <th className="py-3 px-2">Associated Transaction</th>
                  <th className="py-3 px-2">Upload Date</th>
                  <th className="py-3 px-2">Size</th>
                  <th className="py-3 px-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900/60">
                {documents.map(doc => (
                  <tr key={doc.id} className="hover:bg-neutral-900/20">
                    <td className="py-3.5 px-2 font-bold text-stone-200">{doc.title}</td>
                    <td className="py-3.5 px-2">{doc.type}</td>
                    <td className="py-3.5 px-2 text-gold-accent font-bold">{doc.transactionId}</td>
                    <td className="py-3.5 px-2">{doc.uploadDate}</td>
                    <td className="py-3.5 px-2">{doc.size}</td>
                    <td className="py-3.5 px-2 text-right">
                      <button className="text-gold-accent font-bold text-[10px] hover:underline">VIEW</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-3 bg-neutral-950 border border-gold-400/20 text-gold-accent rounded-full shadow-lg hover:bg-neutral-900 transition-all z-50"
          title="Back to Top"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
}
