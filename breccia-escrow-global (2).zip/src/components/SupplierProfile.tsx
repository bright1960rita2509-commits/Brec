import React from 'react';
import { SupplierProfile } from '../types';
import { ShieldCheck, Star, Users, TrendingUp, History } from 'lucide-react';

interface SupplierProfileProps {
  supplier: SupplierProfile;
  onClose: () => void;
}

// Mocks for additional fields
const mockVerificationHistory = [
  { date: '2026-01-15', action: 'Initial Compliance Audit', status: 'Passed' },
  { date: '2025-06-20', action: 'Annual Capacity Verification', status: 'Verified' },
];

const mockFeedback = [
    { user: 'Global Trade Corp', comment: 'Excellent quality and timely delivery.', rating: 5 },
    { user: 'Euro Foods Ltd', comment: 'Responsive communication, professional.', rating: 4 },
];

export default function SupplierProfileDisplay({ supplier, onClose }: SupplierProfileProps) {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 p-4 flex items-center justify-center overflow-y-auto">
      <div className="bg-neutral-950 border border-neutral-800 rounded-2xl w-full max-w-2xl p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-neutral-500 hover:text-white">✕</button>
        
        <h2 className="text-2xl font-bold text-stone-200">{supplier.companyName}</h2>
        <div className="flex items-center gap-2 text-sm text-neutral-400 mt-2">
            <span>{supplier.country}</span> | <span>{supplier.category}</span>
        </div>
        
        <div className="mt-6 p-4 bg-neutral-900 rounded-xl border border-neutral-800">
            <h3 className="text-sm font-bold text-neutral-300">Description</h3>
            <p className="text-xs text-neutral-400 mt-2">{supplier.description}</p>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border border-neutral-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                    <History className="w-4 h-4 text-gold-accent" />
                    <h3 className="text-sm font-bold text-neutral-300">Verification History</h3>
                </div>
                {mockVerificationHistory.map((item, i) => (
                    <div key={i} className="text-xs text-neutral-400 py-1 border-b border-neutral-800 last:border-0">
                        {item.date} - {item.action}: <span className="text-emerald-400 font-semibold">{item.status}</span>
                    </div>
                ))}
            </div>
            
            <div className="border border-neutral-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-4 h-4 text-gold-accent" />
                    <h3 className="text-sm font-bold text-neutral-300">Past Trade Volume</h3>
                </div>
                <div className="text-2xl font-bold text-white">45,000+ MT</div>
                <div className="text-xs text-neutral-500">Total volume shipped</div>
            </div>
        </div>

        <div className="mt-6 border border-neutral-800 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
                <Users className="w-4 h-4 text-gold-accent" />
                <h3 className="text-sm font-bold text-neutral-300">Customer Feedback</h3>
            </div>
            {mockFeedback.map((f, i) => (
                <div key={i} className="mt-2 text-xs">
                    <div className="flex justify-between">
                        <span className="font-semibold text-stone-200">{f.user}</span>
                        <div className="flex items-center text-gold-accent">
                            <Star className="w-3 h-3 fill-gold-accent" />
                            {f.rating}
                        </div>
                    </div>
                    <p className="text-neutral-400">"{f.comment}"</p>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
}
