/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Scanner } from '@yudiel/react-qr-scanner';
import { Search, Filter, ShieldCheck, Star, Ship, FileSpreadsheet, ArrowUpRight, HelpCircle, Bot, Send, QrCode, X, Info } from 'lucide-react';
import { SupplierProfile, RequestForQuotation } from '../types';
import SupplierProfileDisplay from './SupplierProfile';

interface MarketplaceProps {
  onStartEscrow: (supplierName: string, amount: number, initialTerms: string) => void;
}

export default function Marketplace({ onStartEscrow }: MarketplaceProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortCriterion, setSortCriterion] = useState<'default' | 'price' | 'rating' | 'verification'>('default');
  const [showScanner, setShowScanner] = useState(false);
  const [selectedSupplierProfile, setSelectedSupplierProfile] = useState<SupplierProfile | null>(null);
  
  // Currency Conversion State
  const [currency, setCurrency] = useState<'USD' | 'NGN' | 'GHS' | 'KES' | 'ZAR'>('USD');
  const currencyRates = { USD: 1, NGN: 1515, GHS: 14.2, KES: 131.5, ZAR: 18.2 };
  const currencySymbols = { USD: '$', NGN: '₦', GHS: 'GH₵', KES: 'KSh ', ZAR: 'R ' };

  
  // Exporter listings representing major African trades and export industries
  const [suppliers] = useState<SupplierProfile[]>([
    {
      id: "sup_1",
      companyName: "Olam Cocoa Ventures Ltd",
      country: "Ghana",
      category: "Agriculture",
      description: "Premier cocoa beans harvester and processing facility in Kumasi/Tema. Backed by organic certification and direct dock links.",
      products: [
        { id: "p1", name: "Premium Unfermented Dried Cocoa Beans (SGS Quality Cert)", price: "2850", minOrder: "15 Metric Tons" },
        { id: "p2", name: "Organic Extra-Fine Cocoa Butter Bulk", price: "4100", minOrder: "5 Metric Tons" }
      ],
      verificationBadge: true,
      rating: 4.9,
      exportCapability: "5,000 Metric Tons annually. Shipped from Port of Tema."
    },
    {
      id: "sup_2",
      companyName: "Ibadan Cotton & Textiles Corp",
      country: "Nigeria",
      category: "Manufacturing",
      description: "Direct-to-wholesale textile mills manufacturing certified high-tensile organic packaging cotton fibers and pre-woven sacks.",
      products: [
        { id: "p3", name: "Grade A Organic Cotton Yardage Textiles", price: "450", minOrder: "20,000 Yards" },
        { id: "p4", name: "Heavy-Duty Recyclable Woven Packaging Sacks", price: "12", minOrder: "5,000 Pieces" }
      ],
      verificationBadge: true,
      rating: 4.8,
      exportCapability: "1.2 Million yards monthly. Shipped from Lagos Apapa Port."
    },
    {
      id: "sup_3",
      companyName: "Great Lakes Sesame Sourcing Ltd",
      country: "Sudan / Ethiopia",
      category: "Agriculture",
      description: "Top exporter of premium washed white sesame seeds and oilseeds. Strict compliance with ISO 22000 quality standards.",
      products: [
        { id: "p5", name: "Washed Pure White Humera Sesame Seeds", price: "1650", minOrder: "18 Metric Tons" },
        { id: "p6", name: "Unrefined Sesame Bulk Extract Oil", price: "2400", minOrder: "8 Metric Tons" }
      ],
      verificationBadge: true,
      rating: 4.7,
      exportCapability: "8,000 Metric Tons capacity. Shipped via Port of Sudan."
    },
    {
      id: "sup_4",
      companyName: "Kivu Premium Coffee Cooperative",
      country: "Rwanda",
      category: "Wholesale",
      description: "Direct fair-trade cooperatives trading internationally prized high-altitude arabica beans. Wet-milled, sun dried.",
      products: [
        { id: "p7", name: "Fully Washed Arabica Green Beans (Grade Grade A)", price: "4800", minOrder: "10 Metric Tons" }
      ],
      verificationBadge: true,
      rating: 4.9,
      exportCapability: "250 Metric Tons monthly limit. Exported via Mombasa Port."
    },
    {
      id: "sup_5",
      companyName: "West-Coast Sawn Timber & Hardwood",
      country: "Cameroon",
      category: "Natural Resources",
      description: "Sustainably harvested hardwoods, specialized high-durability logs, and structural mahogany sawn timber blocks.",
      products: [
        { id: "p8", name: "Sawn Mahogany Timber Blocks (Kiln Dried)", price: "950", minOrder: "25 Cubic Meters" }
      ],
      verificationBadge: false,
      rating: 4.2,
      exportCapability: "9,000 cubic meters annually. Shipped from Port of Douala."
    }
  ]);

  // Request for Quotation (RFQ) Workspace
  const [rfqs, setRfqs] = useState<RequestForQuotation[]>(() => {
    return JSON.parse(localStorage.getItem('breccia_rfqs') || '[]');
  });

  const [rfqProduct, setRfqProduct] = useState('');
  const [rfqCategory, setRfqCategory] = useState('Agriculture');
  const [rfqQty, setRfqQty] = useState('');
  const [rfqTerms, setRfqTerms] = useState('');
  const [rfqTargetPrice, setRfqTargetPrice] = useState('');
  const [rfqSuccess, setRfqSuccess] = useState('');

  // AI assistant integration
  const [aiPrompt, setAiPrompt] = useState('Compare Ghanaian and Nigerian cocoa beans exporting regulations and standard SGS moisture thresholds.');
  const [aiResponse, setAiResponse] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  const handleCreateRFQ = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rfqProduct || !rfqQty) return;

    const newRfq: RequestForQuotation = {
      id: 'rfq_' + Math.random().toString(36).substring(2, 9),
      importerName: "Global Trade Corp Inc.",
      importerEmail: "importer@breccia.com",
      productName: rfqProduct,
      category: rfqCategory,
      quantity: rfqQty,
      targetPrice: rfqTargetPrice || undefined,
      details: rfqTerms,
      status: 'pending',
      responses: [
        { supplierName: "Olam Cocoa Ventures Ltd", quotePrice: `$${parseFloat(rfqTargetPrice || '1000') * 0.95} per unit`, timeline: "25 Days to port" }
      ]
    };

    const updatedRfqs = [newRfq, ...rfqs];
    setRfqs(updatedRfqs);
    localStorage.setItem('breccia_rfqs', JSON.stringify(updatedRfqs));

    setRfqProduct('');
    setRfqQty('');
    setRfqTerms('');
    setRfqTargetPrice('');
    setRfqSuccess('Your Request for Quotation (RFQ) has been published successfully! Suppliers matched near Lagos and Tema.');
    setTimeout(() => setRfqSuccess(''), 4000);
  };

  const handleQueryAI = async () => {
    if (!aiPrompt) return;
    setAiLoading(true);
    setAiResponse('');
    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: aiPrompt, type: "sourcing" }),
      });
      const data = await response.json();
      setAiResponse(data.text || "No response received.");
    } catch (err) {
      setAiResponse("Fallback Sourcing Advice: To export raw agricultural products like Cocoa or Shea, ensure a certified phytosanitary inspection sheet is issued. Moisture level must strictly remain below 7.5% to avoid vessel rot.");
    } finally {
      setAiLoading(false);
    }
  };

  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch = supplier.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          supplier.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          supplier.country.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || supplier.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const sortedSuppliers = [...filteredSuppliers].sort((a, b) => {
    if (sortCriterion === 'price') {
      const priceA = parseFloat(a.products[0]?.price || '0');
      const priceB = parseFloat(b.products[0]?.price || '0');
      return priceA - priceB;
    } else if (sortCriterion === 'rating') {
      return b.rating - a.rating;
    } else if (sortCriterion === 'verification') {
      return (b.verificationBadge ? 1 : 0) - (a.verificationBadge ? 1 : 0);
    }
    return 0;
  });

  return (
    <div className="space-y-12 px-2" id="marketplace-explorer">
      {selectedSupplierProfile && (
          <SupplierProfileDisplay supplier={selectedSupplierProfile} onClose={() => setSelectedSupplierProfile(null)} />
      )}
      {/* QR Scanner Overlay */}
      {showScanner && (
        <div className="fixed inset-0 z-50 bg-black/90 p-4 flex items-center justify-center">
            <div className="relative w-full max-w-md aspect-square bg-black border-2 border-gold-accent/50 rounded-2xl overflow-hidden">
                <Scanner 
                    onResult={(result) => {
                        if (result) {
                            console.log('Scanned:', result);
                            alert(`Scanned: ${result.getText()}`);
                            setShowScanner(false);
                        }
                    }}
                    onError={(err) => console.error(err)}
                    styles={{ container: { width: '100%', height: '100%' } }}
                />
                <button 
                  onClick={() => setShowScanner(false)}
                  className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full z-10"
                >
                  <X className="w-6 h-6"/>
                </button>
            </div>
        </div>
      )}
      
      {/* Title block */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="text-gold-accent font-mono text-[10px] tracking-widest uppercase font-bold">DIRECTORY & SOURCING STATION</span>
          <h2 className="font-display font-bold text-2xl md:text-3xl text-gold-gradient mt-1">
            EXPLORE AFRICAN TRADE OPPORTUNITIES
          </h2>
          <p className="text-zinc-400 text-xs mt-1">
            Secure international B2B transactions with premium verified African exporters utilizing fully audited escrow protection.
          </p>
        </div>
        
        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2">
          {['All', 'Agriculture', 'Manufacturing', 'Natural Resources', 'Wholesale'].map(tab => (
            <button
              key={tab}
              onClick={() => setSelectedCategory(tab)}
              className={`px-4 py-2 text-[10px] font-mono tracking-widest font-semibold border rounded-lg transition-all ${
                selectedCategory === tab 
                  ? 'bg-gold-gradient border-transparent text-black font-bold' 
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              {tab.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Main Sourcing + Exporters Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Exporters and Products (8 columns) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Header Controls */}
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search bar */}
            <div className="relative flex-1 flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  placeholder="Search by country, exporter name, or commodity (e.g., Cocoa, Cotton, sun-dried beans)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 px-11 py-3.5 rounded-lg text-xs font-medium focus:outline-none focus:border-gold-accent"
                />
              </div>
              <button 
                onClick={() => setShowScanner(true)}
                className="bg-neutral-900 border border-neutral-800 p-3.5 rounded-lg text-gold-accent hover:border-gold-accent transition-colors"
                title="Scan Supplier QR"
              >
                <QrCode className="w-5 h-5" />
              </button>
            </div>
            {/* Currency Selector */}
            <div className="flex-shrink-0">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="bg-neutral-900 border border-neutral-800 text-gold-accent font-mono text-xs font-bold px-4 py-3.5 rounded-lg focus:outline-none focus:border-gold-accent transition-colors cursor-pointer w-full md:w-auto text-center"
              >
                {Object.keys(currencySymbols).map(cur => (
                  <option key={cur} value={cur}>{cur} ({currencySymbols[cur as keyof typeof currencySymbols]})</option>
                ))}
              </select>
            </div>
            {/* Sort Selector */}
            <div className="flex-shrink-0">
              <select
                value={sortCriterion}
                onChange={(e) => setSortCriterion(e.target.value as any)}
                className="bg-neutral-900 border border-neutral-800 text-gold-accent font-mono text-xs font-bold px-4 py-3.5 rounded-lg focus:outline-none focus:border-gold-accent transition-colors cursor-pointer w-full md:w-auto text-center"
              >
                <option value="default">Sort: Default</option>
                <option value="price">Sort: Price (Low-High)</option>
                <option value="rating">Sort: Rating</option>
                <option value="verification">Sort: Verified Status</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {sortedSuppliers.length === 0 ? (
               <div className="py-20 flex flex-col items-center justify-center text-center text-zinc-500 border border-neutral-850 border-dashed rounded-xl bg-neutral-900/5 font-mono text-xs space-y-4">
                 <div className="w-16 h-16 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800">
                   <Search className="w-8 h-8 text-neutral-600" />
                 </div>
                 <span className="block font-bold text-white max-w-xs mx-auto">No Exporters Found</span>
               </div>
            ) : sortedSuppliers.map(supplier => {
              return (
                <div 
                  key={supplier.id}
                  className="glass-panel p-6 rounded-2xl border border-gold-400/10 space-y-4 hover:border-gold-accent/20 transition-all"
                  id={`supplier-profile-${supplier.id}`}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2.5">
                        <h4 className="font-display font-bold text-stone-200 text-base">{supplier.companyName}</h4>
                        <button 
                            onClick={() => setSelectedSupplierProfile(supplier)}
                            className="p-1 text-gold-accent hover:text-white"
                            title="View Supplier Profile"
                        >
                            <Info className="w-3.5 h-3.5" />
                        </button>
                        {supplier.verificationBadge ? (
                          <span className="flex items-center gap-1 text-[9px] font-semibold text-emerald-400 bg-emerald-500/5 px-2 py-0.5 border border-emerald-500/20 rounded-full">
                            <ShieldCheck className="w-3 h-3" />
                            VERIFIED SUPPLIER
                          </span>
                        ) : (
                          <span className="text-[9px] text-zinc-500 bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800">
                            PENDING COMPLIANCE
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-400 mt-0.5">
                        <span>📍 {supplier.country}</span>
                        <span>🏷️ {supplier.category}</span>
                        <span className="flex items-center gap-1 text-gold-accent font-semibold">
                          <Star className="w-3.5 h-3.5 fill-gold-accent" />
                          {supplier.rating} / 5.0
                        </span>
                      </div>
                    </div>
                    
                    <span className="text-[9px] font-mono tracking-wider bg-neutral-900 border border-neutral-850 px-2.5 py-1 rounded text-zinc-400">
                      ID: {supplier.id.toUpperCase()}
                    </span>
                  </div>

                  <p className="text-stone-400 text-xs leading-relaxed font-sans mt-2">
                    {supplier.description}
                  </p>

                  <div className="p-3 bg-neutral-900/40 rounded-lg border border-neutral-850 text-[10px] font-mono flex justify-between items-center text-zinc-400">
                    <span>🛳️ EXPORT LOGISTICS CAPABILITY:</span>
                    <span className="text-white font-semibold">{supplier.exportCapability}</span>
                  </div>

                  {/* Exporter Catalog */}
                  <div className="space-y-3 pt-2">
                    <div className="text-[10px] font-mono tracking-widest text-neutral-400 font-bold uppercase border-b border-neutral-900 pb-1.5">Direct Commodities Listed:</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {supplier.products.map(prod => {
                        const convertedPrice = (parseFloat(prod.price) * currencyRates[currency]).toLocaleString(undefined, { maximumFractionDigits: 0 });
                        return (
                          <div key={prod.id} className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-850 hover:border-gold-accent/15 flex flex-col justify-between gap-3">
                            <div>
                              <span className="block font-medium text-stone-100 text-xs">{prod.name}</span>
                              <span className="block text-[10px] font-mono text-zinc-500 mt-1">Min Order: {prod.minOrder}</span>
                            </div>
                            <div className="flex justify-between items-center pt-2 border-t border-neutral-900">
                              <div>
                                <span className="block text-[8px] font-mono text-zinc-500 uppercase">Estimated Value:</span>
                                <span className="text-gold-accent font-mono font-bold text-xs">{currencySymbols[currency]}{convertedPrice} <span className="text-[10px] font-normal text-stone-400">/ Ton equivalent</span></span>
                              </div>
                              <button
                                onClick={() => onStartEscrow(
                                  supplier.companyName, 
                                  parseFloat(prod.price) * (prod.minOrder.includes('Metric') ? 5 : 1),
                                  `Fulfillment of Bulk ${prod.name}. Cargo compliance standard SGS inspection issued in ports of export prior to release.`
                                )}
                                className="px-3.5 py-2 rounded font-mono text-[10px] font-bold text-black bg-gold-gradient hover:opacity-90 active:scale-95 transition-all cursor-pointer"
                              >
                                BOOK ESCROW &rarr;
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Trade RFQ Workspace + AI Sourcing Assistant (4 columns) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Sourcing Assistant */}
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-900 pb-3">
              <div className="w-8 h-8 rounded-lg bg-gold-accent/10 border border-gold-accent/30 flex items-center justify-center">
                <Bot className="w-4 h-4 text-gold-accent animate-pulse" />
              </div>
              <div>
                <h4 className="font-display font-extrabold text-sm text-stone-200">AI EXPORT ADVISOR</h4>
                <p className="text-[9px] font-mono text-neutral-500 uppercase tracking-widest mt-0.5">Powered by Gemini 3.5</p>
              </div>
            </div>

            <p className="text-[11px] text-zinc-400 leading-normal">
              Get immediate legal advice and analysis of African export customs, moisture targets, phytosanitary requirements, or shipping timelines.
            </p>

            <div className="relative">
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                rows={3}
                placeholder="What parameters of international agriculture export should I verify for Sierra Leone or Kenya cocoa beans?"
                className="w-full bg-neutral-950 border border-neutral-800 text-[11px] rounded-lg p-3 text-white focus:outline-none focus:border-gold-accent"
              />
              <button
                onClick={handleQueryAI}
                disabled={aiLoading}
                className="absolute right-2.5 bottom-3.5 p-1.5 rounded-md bg-gold-gradient text-black hover:opacity-90 transition-all flex items-center justify-center"
              >
                {aiLoading ? <span className="block border-2 border-black border-t-transparent animate-spin w-4.5 h-4.5 rounded-full"></span> : <Send className="w-3.5 h-3.5" />}
              </button>
            </div>

            {aiResponse && (
              <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800 text-[10px] text-stone-200 font-sans leading-relaxed max-h-56 overflow-y-auto whitespace-pre-line text-left">
                {aiResponse}
              </div>
            )}
          </div>

          {/* Sourcing RFQ */}
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4">
            <div className="border-b border-neutral-900 pb-3">
              <h4 className="font-display font-extrabold text-sm text-stone-200">SUBMIT BULK RFQ</h4>
              <p className="text-[9px] font-mono text-neutral-500 uppercase">Match instantly with thousands of verified Exporters</p>
            </div>

            {rfqSuccess && (
              <div className="p-2.5 bg-gold-500/5 text-gold-accent border border-gold-500/20 text-[10px] font-mono rounded text-center">
                {rfqSuccess}
              </div>
            )}

            <form onSubmit={handleCreateRFQ} className="space-y-3.5">
              <div>
                <label className="block text-[9px] font-mono text-neutral-400 uppercase font-semibold mb-1">Target Commodity *</label>
                <input
                  type="text"
                  required
                  value={rfqProduct}
                  onChange={(e) => setRfqProduct(e.target.value)}
                  placeholder="e.g. 50 Tons Ghanaian Raw Cocoa Beans"
                  className="w-full bg-neutral-950 border border-neutral-800 px-3 py-2 text-xs rounded-lg text-white font-medium focus:outline-none focus:border-gold-accent"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[9px] font-mono text-neutral-400 uppercase font-semibold mb-1">Category</label>
                  <select
                    value={rfqCategory}
                    onChange={(e) => setRfqCategory(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 px-3 py-2 text-xs rounded-lg text-zinc-400 font-medium focus:outline-none focus:border-gold-accent"
                  >
                    <option value="Agriculture">Agriculture</option>
                    <option value="Manufacturing">Manufacturing</option>
                    <option value="Natural Resources">Minerals</option>
                    <option value="Wholesale">Wholesale</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] font-mono text-neutral-400 uppercase font-semibold mb-1">Target Price (USD)</label>
                  <input
                    type="number"
                    value={rfqTargetPrice}
                    onChange={(e) => setRfqTargetPrice(e.target.value)}
                    placeholder="e.g. 15000"
                    className="w-full bg-neutral-950 border border-neutral-800 px-3 py-2 text-xs rounded-lg text-white font-medium focus:outline-none focus:border-gold-accent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-mono text-neutral-400 uppercase font-semibold mb-1">Total Weight / Quantity *</label>
                <input
                  type="text"
                  required
                  value={rfqQty}
                  onChange={(e) => setRfqQty(e.target.value)}
                  placeholder="e.g. 25 Metric Tons"
                  className="w-full bg-neutral-950 border border-neutral-800 px-3 py-2 text-xs rounded-lg text-white font-medium focus:outline-none focus:border-gold-accent"
                />
              </div>

              <div>
                <label className="block text-[9px] font-mono text-neutral-400 uppercase font-semibold mb-1">Fulfillment Conditions & Standards</label>
                <textarea
                  value={rfqTerms}
                  onChange={(e) => setRfqTerms(e.target.value)}
                  rows={2}
                  placeholder="Describe required moisture, organic certification standards, or dock delivery timelines..."
                  className="w-full bg-neutral-950 border border-neutral-800 p-2.5 text-xs rounded-lg text-white focus:outline-none focus:border-gold-accent"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded bg-gold-gradient text-black text-xs font-mono font-bold tracking-widest hover:opacity-95"
              >
                BROADCAST RFQ NOW
              </button>
            </form>
          </div>

          {/* Live broadcasts feed */}
          <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 space-y-4">
            <div className="border-b border-neutral-900 pb-2.5">
              <span className="text-[10px] font-mono text-gold-accent uppercase tracking-wider font-bold">● Active Commercial RFQs</span>
            </div>
            
            <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {rfqs.length === 0 ? (
                <div className="text-[10px] font-mono text-neutral-500 text-center py-4">No custom broker RFQs running yet. Submit a form above to broadcast.</div>
              ) : (
                rfqs.map(rf => (
                  <div key={rf.id} className="p-3 bg-neutral-900/60 border border-neutral-850 rounded-lg text-[10px] font-mono space-y-1.5 text-left">
                    <div className="flex justify-between items-start">
                      <span className="text-white font-semibold line-clamp-1">{rf.productName}</span>
                      <span className="text-[9px] text-zinc-500 uppercase">{rf.status}</span>
                    </div>
                    <div className="flex justify-between text-neutral-500">
                      <span>Qty: {rf.quantity}</span>
                      <span>Target: ${rf.targetPrice || "N/A"}</span>
                    </div>
                    
                    {rf.responses && rf.responses.map((resp, i) => (
                      <div key={i} className="mt-2 pt-1.5 border-t border-neutral-850 bg-neutral-950 p-1.5 rounded flex items-center justify-between text-[9px] text-gold-accent">
                        <span>Matched: {resp.supplierName}</span>
                        <span className="font-bold">{resp.quotePrice}</span>
                      </div>
                    ))}
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
