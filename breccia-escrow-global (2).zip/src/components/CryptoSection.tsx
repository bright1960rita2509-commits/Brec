/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bitcoin, Coins, Key, Landmark, CreditCard, ArrowRight, CheckCircle2, RotateCw, Copy, Smartphone } from 'lucide-react';

interface CryptoSectionProps {
  onFundSuccess?: (amount: number, coin: string) => void;
  escrowId?: string;
  targetAmount?: number;
}

export default function CryptoSection({ onFundSuccess, escrowId, targetAmount = 5000 }: CryptoSectionProps) {
  const [selectedCoin, setSelectedCoin] = useState<string | null>(null);
  const [amount, setAmount] = useState<string>(targetAmount.toString());
  const [copied, setCopied] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'select' | 'address' | 'checking' | 'completed'>('select');
  const [confirmations, setConfirmations] = useState(0);

  const testAddresses: Record<string, string> = {
    BTC: 'bc1qfkm92epgmdmep5q5qgqg6df9y3z65s69n7zpq8',
    ETH: '0x07421BaeD3a033333333330337194A2D87EE71D2',
    USDT: 'TYY8p9h999F44783ffasdaAAssssSSeeeeeRRr',
    BNB: '0x07421BaeD3a033333333330337194A2D87EE71D2'
  };

  const cryptos = [
    {
      id: "BTC",
      name: "Bitcoin (BTC)",
      network: "BTC Mainnet",
      color: "from-amber-500/20 to-amber-600/5",
      borderColor: "group-hover:border-amber-500/40",
      textColor: "text-amber-500"
    },
    {
      id: "ETH",
      name: "Ethereum (ETH)",
      network: "ERC-20 Network",
      color: "from-blue-500/20 to-blue-600/5",
      borderColor: "group-hover:border-blue-500/40",
      textColor: "text-blue-400"
    },
    {
      id: "USDT",
      name: "USDT (TRC20)",
      network: "TRC-20 Network",
      color: "from-emerald-500/20 to-emerald-600/5",
      borderColor: "group-hover:border-emerald-500/40",
      textColor: "text-emerald-400"
    },
    {
      id: "BNB",
      name: "Binance Coin (BNB)",
      network: "BEP-20 Network",
      color: "from-yellow-500/20 to-yellow-600/5",
      borderColor: "group-hover:border-yellow-500/40",
      textColor: "text-yellow-400"
    }
  ];

  const handlePay = (coinId: string) => {
    setSelectedCoin(coinId);
    setPaymentStep('address');
  };

  const handleCopy = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConfirmCheck = () => {
    setPaymentStep('checking');
    setConfirmations(0);
    const interval = setInterval(() => {
      setConfirmations(prev => {
        if (prev >= 3) {
          clearInterval(interval);
          setTimeout(() => {
            setPaymentStep('completed');
            if (onFundSuccess) {
              onFundSuccess(parseFloat(amount) || 2500, selectedCoin || 'USDT');
            }
          }, 800);
          return 3;
        }
        return prev + 1;
      });
    }, 1000);
  };

  return (
    <div className="w-full glass-panel p-6 md:p-8 rounded-3xl border border-gold-400/10" id="crypto-payment-module">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* Left Explanation column (85% standard, alternative options highlighted) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-400/5 border border-gold-400/20 text-[10px] font-mono tracking-wider text-gold-accent uppercase font-semibold">
            <Coins className="w-3.5 h-3.5" />
            Flexible Settlement
          </div>
          <h3 className="font-display font-bold text-xl md:text-2xl text-gold-gradient uppercase tracking-wide">
            Pay with Cryptocurrency
          </h3>
          <p className="text-zinc-400 text-xs leading-relaxed font-sans">
            Breccia supports decentralized digital currency settlements to protect cross-border exporters from fiat liquidity crunches. Transactions are secured in physical custody or escrow contracts before final clearance.
          </p>

          <div className="pt-2">
            <div className="text-[10px] font-mono text-neutral-500 uppercase font-semibold tracking-wider mb-2">Alternative Traditional Funding Methods:</div>
            <div className="grid grid-cols-3 gap-2">
              <div className="flex items-center gap-1.5 p-2 rounded-lg bg-neutral-900/60 border border-neutral-800 text-[10px] font-mono text-zinc-400">
                <Landmark className="w-3 h-3 text-gold-accent" />
                Bank Transfer
              </div>
              <div className="flex items-center gap-1.5 p-2 rounded-lg bg-neutral-900/60 border border-neutral-800 text-[10px] font-mono text-zinc-400">
                <CreditCard className="w-3 h-3 text-gold-accent" />
                Debit Cards
              </div>
              <div className="flex items-center gap-1.5 p-2 rounded-lg bg-neutral-900/60 border border-neutral-800 text-[10px] font-mono text-zinc-400">
                <Smartphone className="w-3 h-3 text-gold-accent" />
                Mobile Money
              </div>
            </div>
          </div>
        </div>

        {/* Right interaction column */}
        <div className="lg:col-span-8 bg-neutral-950 p-6 rounded-2xl border border-neutral-800">
          
          {paymentStep === 'select' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-neutral-900">
                <span className="text-xs font-mono text-zinc-400">Select standard escrow token to query rate:</span>
                <span className="text-[10px] font-mono text-gold-accent">No Conversion Fees Charged</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cryptos.map(coin => {
                  return (
                    <div 
                      key={coin.id}
                      onClick={() => handlePay(coin.id)}
                      className={`group p-4 rounded-xl bg-neutral-900/40 border border-neutral-800 hover:bg-[#000] hover:border-gold-accent/40 cursor-pointer transition-all`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-gradient-to-br ${coin.color} border border-neutral-800 group-hover:border-gold-accent/20`}>
                            {coin.id === 'BTC' ? (
                              <Bitcoin className={`w-5 h-5 text-amber-500`} />
                            ) : (
                              <Coins className={`w-5 h-5 ${coin.textColor}`} />
                            )}
                          </div>
                          <div>
                            <span className="block font-display font-bold text-xs text-white">{coin.name}</span>
                            <span className="block text-[10px] text-neutral-500 font-mono mt-0.5">{coin.network}</span>
                          </div>
                        </div>
                        <button className="px-3.5 py-1.5 bg-neutral-950 group-hover:bg-gold-gradient text-neutral-400 group-hover:text-black hover:opacity-90 font-semibold text-[10px] font-mono tracking-wider rounded border border-neutral-800 group-hover:border-transparent transition-all">
                          FUND ESCROW
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {paymentStep === 'address' && selectedCoin && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-900">
                <span className="text-xs font-mono text-zinc-400">Escrow Security Deposit: <span className="text-gold-accent font-bold font-sans">{selectedCoin}</span></span>
                <button
                  onClick={() => setPaymentStep('select')}
                  className="text-[10px] text-neutral-500 hover:text-gold-accent font-mono"
                >
                  &larr; Choose Other Asset
                </button>
              </div>

              <div className="bg-neutral-900/40 p-4 rounded-xl border border-neutral-800 space-y-3">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-neutral-950 p-3 rounded-lg border border-neutral-850">
                  <div className="font-mono text-[10px] text-neutral-500 uppercase tracking-widest">Escrow Specific Contract:</div>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter deposit USD equivalent"
                    className="bg-neutral-900 text-xs font-mono text-white rounded border border-neutral-800 px-3 py-1.5 focus:outline-none focus:border-gold-accent max-w-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-mono text-neutral-400 tracking-wider">TRANSFER EXACT TARGET ADDRESS Below:</label>
                  <div className="flex items-center gap-2">
                    <span className="flex-1 bg-neutral-950 py-2.5 px-3 rounded text-[10px] font-mono text-gold-accent select-all overflow-x-auto whitespace-nowrap border border-neutral-900">
                      {testAddresses[selectedCoin]}
                    </span>
                    <button
                      onClick={() => handleCopy(testAddresses[selectedCoin])}
                      className="p-2.5 rounded bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800 transition-colors"
                      title="Copy Address"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  {copied && (
                    <span className="text-[9px] text-gold-accent font-mono block text-right">Address Copied to clipboard!</span>
                  )}
                </div>

                <div className="p-3 bg-neutral-950 rounded border border-neutral-900 text-[10px] leading-relaxed text-zinc-500 font-mono">
                  ⚠️ Verify that you send ONLY <span className="text-white font-bold">{selectedCoin}</span> tokens to this verified address using the <span className="text-gold-accent font-bold font-sans">{cryptos.find(c => c.id === selectedCoin)?.network}</span> network. Funds sent via wrong relays are not retrievable.
                </div>
              </div>

              <button
                onClick={handleConfirmCheck}
                className="w-full py-2.5 rounded bg-gold-gradient text-black font-semibold text-xs font-mono tracking-widest uppercase hover:opacity-95"
              >
                PROCEED TO MEMPOOL MONITOR &rarr;
              </button>
            </div>
          )}

          {paymentStep === 'checking' && (
            <div className="py-8 text-center space-y-4">
              <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-2 border-dashed border-gold-accent/20 animate-spin"></div>
                <RotateCw className="w-6 h-6 text-gold-accent animate-spin" />
              </div>
              <div className="space-y-1">
                <h4 className="font-mono text-xs text-white uppercase tracking-wider font-bold">Querying Ledger Transaction</h4>
                <p className="text-[10px] font-mono text-neutral-500">Mempool sync index: Pending broadcast</p>
              </div>
              
              <div className="max-w-xs mx-auto bg-neutral-900 p-3 rounded-lg border border-neutral-800 space-y-2">
                <div className="flex justify-between text-[10px] font-mono text-neutral-400">
                  <span>Block Confirmations</span>
                  <span className="text-gold-accent font-bold">{confirmations} / 3</span>
                </div>
                <div className="w-full h-1 bg-neutral-950 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gold-gradient transition-all duration-1000"
                    style={{ width: `${(confirmations / 3) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          {paymentStep === 'completed' && selectedCoin && (
            <div className="py-8 text-center space-y-4 animate-fade-in">
              <div className="w-16 h-16 rounded-full bg-gold-accent/10 border border-gold-accent/40 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8 text-gold-accent" />
              </div>
              <div className="space-y-2">
                <h4 className="font-display font-bold text-lg text-gold-gradient">Escrow Vault Funded</h4>
                <p className="text-[11px] text-zinc-400 max-w-sm mx-auto leading-relaxed">
                  The equivalent of <span className="text-white font-bold font-mono">${parseFloat(amount).toLocaleString()} USD</span> has been successfully locked in Breccia Safe Custody under Escrow ID: <span className="text-amber-400 font-mono font-bold">BRC-{Math.random().toString(36).substring(4, 9).toUpperCase()}</span>.
                </p>
              </div>
              <button
                onClick={() => setPaymentStep('select')}
                className="px-6 py-2 rounded border border-neutral-800 text-neutral-400 hover:text-white font-mono text-[10px] tracking-widest uppercase transition-colors"
              >
                DISMISS MONITOR
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
