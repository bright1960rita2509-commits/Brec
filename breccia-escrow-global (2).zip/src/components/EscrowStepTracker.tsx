/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserPlus, FileEdit, Shield, CheckCircle, Package, Award, ArrowRight } from 'lucide-react';

export default function EscrowStepTracker() {
  const steps = [
    {
      number: 1,
      icon: UserPlus,
      title: "Create Account",
      desc: "Sign up and verify your corporate identity via automated KYC checklists."
    },
    {
      number: 2,
      icon: FileEdit,
      title: "Create Transaction",
      desc: "Set mutual trade conditions details, deadline inspection days, and delivery targets."
    },
    {
      number: 3,
      icon: Shield,
      title: "Secure Escrow",
      desc: "Buyer funds the escrow vault (via bank, card, crypto, Rise, Paystack, Flutterwave, or Binance Pay). We secure funds safely."
    },
    {
      number: 4,
      icon: Package,
      title: "Completion",
      desc: "Seller ships the commodity bulk. Exporter uploads SGS grade certificates."
    },
    {
      number: 5,
      icon: CheckCircle,
      title: "Funds Released",
      desc: "Buyer inspects delivery, signs release, and Breccia instantly credits the Seller."
    },
    {
      number: 6,
      icon: Award,
      title: "Rate & Review",
      desc: "Share reviews, build verified supplier badge rating, and unlock cheaper trade lines."
    }
  ];

  return (
    <div className="w-full glass-panel p-8 md:p-12 rounded-3xl border border-gilded/10 shadow-lg" id="escrow-step-tracker-container">
      <div className="text-center mb-10">
        <span className="text-[10px] font-mono tracking-[0.3em] text-gold-accent uppercase font-bold">Safe Trade Protocol</span>
        <h3 className="font-display font-bold text-2xl md:text-3xl text-gold-gradient mt-2 uppercase tracking-wide">
          How Our Escrow Works
        </h3>
        <p className="text-stone-400 text-xs md:text-sm max-w-xl mx-auto mt-2">
          Review our step-by-step security framework, securing cross-border trade transactions for absolute financial protection.
        </p>
      </div>

      {/* Grid of Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 relative">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div key={step.number} className="relative group" id={`timeline-step-${step.number}`}>
              {/* Sequential connection indicator (only on desktop resolutions) */}
              {idx < steps.length - 1 && (
                <div className="absolute top-12 left-1/2 lg:left-full w-full h-[1px] border-t border-dashed border-gold-accent/25 hidden lg:block z-0 transform translate-x-3 -translate-y-1/2">
                </div>
              )}

              <div className="relative z-10 flex flex-col items-center text-center p-5 rounded-2xl bg-neutral-900/60 transition-all duration-300 border border-neutral-800 group-hover:border-gold-accent/30 group-hover:bg-neutral-900 shadow-sm">
                
                {/* Number Badge */}
                <div className="absolute top-3 left-3 w-5 h-5 rounded-full bg-neutral-950 flex items-center justify-center border border-neutral-800 text-[10px] font-mono text-gold-accent font-bold">
                  {step.number}
                </div>

                {/* Animated Light Spot */}
                <div className="w-16 h-16 rounded-2xl bg-neutral-950 flex items-center justify-center border border-gold-400/10 mb-4 group-hover:border-gold-accent/40 group-hover:bg-gold-accent/5 transition-all">
                  <Icon className="w-6 h-6 text-gold-accent" />
                </div>

                <h4 className="font-display font-bold text-sm text-stone-200 mt-2 select-none group-hover:text-gold-accent transition-colors">
                  {step.title}
                </h4>
                
                <p className="text-zinc-500 hover:text-zinc-400 transition-colors text-[11px] leading-relaxed mt-2 font-sans">
                  {step.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Mobile Flow Alert */}
      <div className="mt-8 flex justify-center items-center gap-2 text-[10px] font-mono text-gold-accent/70 lg:hidden">
        <span>Scroll to see sequential protocol</span>
        <ArrowRight className="w-3.5 h-3.5 animate-pulse" />
      </div>
    </div>
  );
}
