import React from 'react';
import { EscrowTransaction } from '../types';

interface PrintableSummaryProps {
  tx: EscrowTransaction;
  onClose: () => void;
  onPrint?: () => void;
}

export default function PrintableSummary({ tx, onClose, onPrint }: PrintableSummaryProps) {
  return (
    <div className="fixed inset-0 z-[200] bg-white p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto bg-white text-black font-serif">
        {/* Print Control Toolbar */}
        <div className="flex justify-between items-center mb-12 print:hidden pb-4 border-b border-black">
          <button onClick={onClose} className="px-4 py-2 bg-neutral-200 rounded">Close</button>
          <button onClick={() => { if(onPrint) onPrint(); window.print(); }} className="px-4 py-2 bg-black text-white rounded">Print / Save as PDF</button>
        </div>

        {/* Formal Document Layout */}
        <div className="border border-black p-12">
            <h1 className="text-3xl font-bold mb-2">ESCROW SETTLEMENT SUMMARY</h1>
            <p className="text-sm border-b border-black pb-4 mb-8">Ref: {tx.id}</p>

            <div className="grid grid-cols-2 gap-8 mb-12">
                <div>
                    <h3 className="font-bold">BUYER</h3>
                    <p>{tx.buyerName} ({tx.buyerId})</p>
                </div>
                <div>
                    <h3 className="font-bold">EXPORTER</h3>
                    <p>{tx.sellerName} ({tx.sellerId})</p>
                </div>
            </div>

            <div className="mb-12">
                <h3 className="font-bold border-b border-black">TRANSACTION DETAILS</h3>
                <div className="flex justify-between py-2 border-b border-neutral-200">
                    <span>Title</span>
                    <span className="font-semibold">{tx.title}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-neutral-200">
                    <span>Amount</span>
                    <span className="font-semibold">${tx.amount.toLocaleString()} {tx.currency}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-neutral-200">
                    <span>Payment Method</span>
                    <span className="font-semibold uppercase">{tx.paymentMethod}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-neutral-200">
                    <span>CreatedAt</span>
                    <span className="font-semibold">{tx.createdAt}</span>
                </div>
            </div>

            <div className="mb-12">
                <h3 className="font-bold border-b border-black mb-2">TERMS & CONDITIONS</h3>
                <p className="text-sm">{tx.terms}</p>
            </div>

            <div className="mt-24 text-center">
                <div className="w-48 border-t border-black mx-auto"></div>
                <p className="text-xs mt-2">Authorized Signature - Breccia Escrow Desk</p>
            </div>
        </div>
      </div>
    </div>
  );
}
