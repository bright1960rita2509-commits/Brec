/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Twitter, Facebook, Linkedin, ArrowRight, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (section: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail('');
    setTimeout(() => setSubscribed(false), 5000);
  };

  return (
    <footer className="w-full bg-[#050505] border-t border-gilded/15 pt-16 pb-8 px-6 md:px-12 text-left" id="footer-root">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-10">
        
        {/* Company info (2 columns) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="cursor-pointer flex items-center gap-2" onClick={() => onNavigate('home')}>
            <div className="w-8 h-8 rounded-lg bg-gold-accent/15 border border-gold-400/20 flex items-center justify-center">
              <Shield className="w-4.5 h-4.5 text-gold-accent" />
            </div>
            <span className="font-display font-bold text-lg tracking-wider text-gold-accent">BRECCIA</span>
          </div>
          <p className="text-zinc-500 text-xs leading-relaxed max-w-xs font-sans">
            Breccia is a next-generation escrow and trade platform built for Africa and the future of global sourcing and digital settlements.
          </p>
          <div className="flex gap-4 text-zinc-600 hover:text-zinc-500 pt-2">
            <Twitter className="w-4 h-4 hover:text-gold-accent cursor-pointer transition-colors" />
            <Facebook className="w-4 h-4 hover:text-gold-accent cursor-pointer transition-colors" />
            <Linkedin className="w-4 h-4 hover:text-gold-accent cursor-pointer transition-colors" />
          </div>
        </div>

        {/* Company links */}
        <div className="space-y-4">
          <h5 className="font-display font-extrabold text-[10px] uppercase text-stone-200 tracking-wider">Company</h5>
          <div className="flex flex-col gap-2.5 text-xs text-zinc-500 font-sans">
            <button onClick={() => onNavigate('about')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">About Us</button>
            <button onClick={() => onNavigate('about')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Careers</button>
            <button onClick={() => onNavigate('about')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Press</button>
            <button onClick={() => onNavigate('contact')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Contact Us</button>
          </div>
        </div>

        {/* Services */}
        <div className="space-y-4">
          <h5 className="font-display font-extrabold text-[10px] uppercase text-stone-200 tracking-wider">Services</h5>
          <div className="flex flex-col gap-2.5 text-xs text-zinc-500 font-sans">
            <button onClick={() => onNavigate('escrow-promo')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Escrow Services</button>
            <button onClick={() => onNavigate('marketplace')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Trade Marketplace</button>
            <button onClick={() => onNavigate('escrow-promo')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Crypto Payments</button>
            <button onClick={() => onNavigate('marketplace')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Supplier Verification</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Dispute Resolution</button>
          </div>
        </div>

        {/* Support */}
        <div className="space-y-4">
          <h5 className="font-display font-extrabold text-[10px] uppercase text-stone-200 tracking-wider">Support</h5>
          <div className="flex flex-col gap-2.5 text-xs text-zinc-500 font-sans">
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Help Center</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">FAQ</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Terms of Service</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Privacy Policy</button>
          </div>
        </div>

        {/* Legal */}
        <div className="space-y-4">
          <h5 className="font-display font-extrabold text-[10px] uppercase text-stone-200 tracking-wider">Legal</h5>
          <div className="flex flex-col gap-2.5 text-xs text-zinc-500 font-sans">
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">AML Policy</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">KYC Policy</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Refund Policy</button>
            <button onClick={() => onNavigate('faq')} className="hover:text-gold-accent text-left transition-colors cursor-pointer">Compliance</button>
          </div>
        </div>

      </div>

      {/* Subscription area */}
      <div className="max-w-7xl mx-auto border-t border-neutral-900 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left space-y-1">
          <span className="block font-display font-bold text-stone-200 text-xs uppercase tracking-wider">Stay Updated</span>
          <span className="block text-[11px] text-zinc-500 font-sans">Subscribe to our newsletter for intelligence reports on Africa logistics and tariffs.</span>
        </div>

        <div className="w-full max-w-sm">
          {subscribed ? (
            <div className="flex items-center gap-2 p-2 px-3 border border-gold-400/20 bg-gold-400/5 text-gold-accent text-[11px] font-mono rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
              Corporate subscription verified! Standard briefings activated.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex gap-2 w-full">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter corporate email..."
                className="flex-1 bg-neutral-950 border border-neutral-850 py-2 px-3 text-xs text-white rounded-lg focus:outline-none focus:border-gold-accent font-mono"
              />
              <button
                type="submit"
                className="p-2 px-4 rounded-lg bg-gold-gradient hover:opacity-95 text-black font-semibold text-xs font-mono active:scale-95 transition-all flex items-center justify-center cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-neutral-900/60 mt-8 pt-4 flex flex-col md:flex-row justify-between text-[10px] font-mono text-zinc-650 tracking-wider text-center md:text-left gap-4">
        <span>© 2026 Breccia. All rights reserved. Registered legal custodian partner.</span>
        <span>Secured Cross-Border B2B Ledger Settlement Node</span>
      </div>
    </footer>
  );
}
