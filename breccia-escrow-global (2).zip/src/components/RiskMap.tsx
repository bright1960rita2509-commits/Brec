import React from 'react';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

// Mock geographical data based on dispute locations
const riskData = [
  { lat: 5.6037, lng: -0.1870, city: 'Accra', disputes: 5 },
  { lat: 6.5244, lng: 3.3792, city: 'Lagos', disputes: 12 },
  { lat: 4.7709, lng: 7.0134, city: 'Port Harcourt', disputes: 3 },
];

export default function RiskMap() {
  if (!hasValidKey) {
    return (
      <div className="glass-panel p-4 rounded-xl border border-neutral-800 bg-neutral-950 text-neutral-400 text-xs font-mono text-center">
        Google Maps API Key Required for Risk Visualization.
      </div>
    );
  }

  return (
    <APIProvider apiKey={API_KEY} version="weekly">
      <Map
        defaultCenter={{lat: 6.0, lng: 2.0}}
        defaultZoom={5}
        mapId="RISK_MAP_ID"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{width: '100%', height: '300px'}}
        disableDefaultUI={true}
      >
        {riskData.map((data, index) => (
          <AdvancedMarker key={index} position={{lat: data.lat, lng: data.lng}} title={`Disputes: ${data.disputes}`}>
            <Pin background={data.disputes > 10 ? '#ef4444' : '#fbbf24'} glyphColor="#000" />
          </AdvancedMarker>
        ))}
      </Map>
    </APIProvider>
  );
}
