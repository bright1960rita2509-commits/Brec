import React, { useState, useEffect } from 'react';
import { ShieldCheck, ShieldAlert, BrainCircuit, AlertTriangle } from 'lucide-react';
import { EscrowTransaction } from '../types';

interface Props {
  transaction: EscrowTransaction;
}

export default function TrustScoreWidget({ transaction }: Props) {
  const [loading, setLoading] = useState(true);
  const [score, setScore] = useState(0);
  const [risk, setRisk] = useState<'LOW' | 'MODERATE' | 'HIGH'>('LOW');
  const [factors, setFactors] = useState<string[]>([]);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      // Generate deterministic pseudo-random pseudo-score for demo
      const amountMod = transaction.amount % 100;
      let calculatedScore = 85 + (amountMod % 12) - (transaction.sellerName.length % 5);
      
      if (calculatedScore > 99) calculatedScore = 98;
      if (calculatedScore < 50) calculatedScore = 72;
      
      setScore(calculatedScore);
      
      if (calculatedScore >= 85) {
        setRisk('LOW');
        setFactors(['Verified supplier history', 'Stable regional market', 'Standard cargo value']);
      } else if (calculatedScore >= 70) {
        setRisk('MODERATE');
        setFactors(['New trade corridor', 'High cargo volume', 'Adequate liquidity']);
      } else {
        setRisk('HIGH');
        setFactors(['Unverified port logs', 'Price volatility detected', 'First-time counterparties']);
      }
      
      setLoading(false);
    }, 2000 + Math.random() * 1000);

    return () => clearTimeout(timer);
  }, [transaction]);

  if (loading) {
    return (
      <div className="w-full bg-neutral-900 border border-neutral-850 rounded-lg p-3 my-4 flex items-center justify-between overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700 animate-pulse">
            <BrainCircuit className="w-4 h-4 text-gold-accent opacity-50" />
          </div>
          <div className="space-y-1.5">
            <div className="h-3 w-32 bg-neutral-800 rounded animate-pulse"></div>
            <div className="h-2 w-48 bg-neutral-800/50 rounded animate-pulse"></div>
          </div>
        </div>
        <div className="h-6 w-16 bg-neutral-800 rounded animate-pulse"></div>
      </div>
    );
  }

  const isLow = risk === 'LOW';
  const isMod = risk === 'MODERATE';
  const colorClass = isLow ? 'text-emerald-400' : isMod ? 'text-amber-400' : 'text-rose-400';
  const bgColor = isLow ? 'bg-emerald-400/10' : isMod ? 'bg-amber-400/10' : 'bg-rose-400/10';
  const borderColor = isLow ? 'border-emerald-400/20' : isMod ? 'border-amber-400/20' : 'border-rose-400/20';
  const Icon = isLow ? ShieldCheck : isMod ? AlertTriangle : ShieldAlert;

  return (
    <div className="w-full bg-neutral-950 border border-neutral-900 rounded-lg p-3.5 my-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <div className="flex items-start gap-3">
          <div className={`w-9 h-9 rounded-full shrink-0 flex items-center justify-center border ${bgColor} ${borderColor} ${colorClass}`}>
            <Icon className="w-4 h-4" />
          </div>
          <div>
            <h5 className="text-xs font-bold text-white flex items-center gap-1.5 font-mono">
              <BrainCircuit className="w-3 h-3 text-gold-accent" />
              AI RISK ASSESSMENT
              <span className={`px-2 py-0.5 rounded text-[8px] tracking-wider uppercase font-bold border ${bgColor} ${borderColor} ${colorClass}`}>
                {risk} RISK
              </span>
            </h5>
            <ul className="mt-1.5 space-y-1">
              {factors.map((f, i) => (
                <li key={i} className="text-[10px] text-zinc-400 flex items-center gap-1.5">
                  <div className="w-1 h-1 rounded-full bg-zinc-600"></div>
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="text-right shrink-0 bg-neutral-900 p-2.5 rounded-md border border-neutral-800 min-w-[100px]">
          <span className="block text-[9px] text-zinc-500 font-mono tracking-wider uppercase mb-1">Trust Score</span>
          <div className="flex items-baseline justify-end gap-1">
            <span className={`font-mono text-2xl font-black ${colorClass}`}>{score}</span>
            <span className="text-xs text-zinc-500">/100</span>
          </div>
        </div>

      </div>
    </div>
  );
}
