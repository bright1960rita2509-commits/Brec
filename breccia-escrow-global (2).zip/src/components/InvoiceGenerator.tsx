import React, { useState, useRef } from 'react';
import { FileText, Download, ShieldCheck, Printer, FileOutput } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { EscrowTransaction } from '../types';

interface InvoiceGeneratorProps {
  transactions: EscrowTransaction[];
}

export default function InvoiceGenerator({ transactions }: InvoiceGeneratorProps) {
  const completedTxs = transactions.filter(t => t.status === 'completed' || t.status === 'funded' || t.status === 'dispatched');
  const [selectedTxId, setSelectedTxId] = useState<string>('');
  const [taxRate, setTaxRate] = useState<number>(0);

  const selectedTx = completedTxs.find(t => t.id === selectedTxId);

  const taxAmount = selectedTx ? selectedTx.amount * (taxRate / 100) : 0;
  const totalAmount = selectedTx ? selectedTx.amount + taxAmount : 0;
  
  const handleDownload = () => {
    // In a real app, this would use jsPDF or a backend service like pdfmake
    toast.success("Invoice generated and downloaded as PDF.");
  };

  return (
    <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4 shadow-xl" id="invoice-generator-widget">
      <div className="border-b border-neutral-900 pb-3 flex justify-between items-center">
        <div>
          <span className="text-[9px] font-mono tracking-widest text-gold-accent font-bold uppercase block">Billing & Compliance</span>
          <h4 className="font-display font-medium text-stone-200 text-sm mt-0.5 uppercase flex items-center gap-2">
            <FileOutput className="w-4 h-4" />
            Trade Invoice Generator
          </h4>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Select Active/Completed Trade</label>
          <select
            value={selectedTxId}
            onChange={(e) => setSelectedTxId(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white focus:outline-none focus:border-gold-accent"
          >
            <option value="">-- Choose Transaction --</option>
            {completedTxs.map(tx => (
              <option key={tx.id} value={tx.id}>{tx.id} - {tx.title}</option>
            ))}
          </select>
        </div>

        {selectedTx ? (
          <div className="space-y-4 pt-2">
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Applicable Tax Rate (%)</label>
              <input
                type="number"
                min="0"
                step="0.1"
                value={taxRate}
                onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
                className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white focus:outline-none"
              />
            </div>

            {/* Print Area Preview */}
            <div className="mt-4 p-6 bg-white rounded-lg text-black font-sans shadow-inner relative" id="invoice-preview">
               <div className="absolute top-0 right-0 p-3 opacity-20 pointer-events-none">
                  <ShieldCheck className="w-24 h-24 text-gray-500" />
               </div>
               
               <div className="flex justify-between items-start border-b border-gray-300 pb-4 mb-4">
                 <div>
                    <h2 className="text-2xl font-black font-display tracking-wider text-gray-900 uppercase">INVOICE</h2>
                    <p className="text-xs text-gray-500 font-mono mt-1">REF: INV-{selectedTx.id}</p>
                 </div>
                 <div className="text-right">
                    <span className="font-bold text-lg tracking-widest text-gray-800">BRECCIA</span>
                    <p className="text-[10px] text-gray-600 font-mono mt-0.5">Secure Escrow Platform</p>
                    <p className="text-[10px] text-gray-400 font-mono">Date: {new Date().toLocaleDateString()}</p>
                 </div>
               </div>

               <div className="grid grid-cols-2 gap-4 mb-6">
                 <div>
                   <h5 className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Billed To (Importer)</h5>
                   <p className="text-xs font-semibold text-gray-800">{selectedTx.buyerName}</p>
                   <p className="text-[10px] text-gray-600 mt-1">ID: {selectedTx.buyerId}</p>
                 </div>
                 <div className="text-right">
                   <h5 className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Exporter / Supplier</h5>
                   <p className="text-xs font-semibold text-gray-800">{selectedTx.sellerName}</p>
                   <p className="text-[10px] text-gray-600 mt-1">ID: {selectedTx.sellerId}</p>
                 </div>
               </div>

               <table className="w-full mb-6 text-left">
                 <thead>
                   <tr className="border-b border-gray-300 text-[10px] uppercase tracking-wider text-gray-500">
                     <th className="pb-2 font-semibold">Description</th>
                     <th className="pb-2 font-semibold text-right">Amount</th>
                   </tr>
                 </thead>
                 <tbody className="text-xs">
                   <tr className="border-b border-gray-100">
                     <td className="py-3 font-medium text-gray-800">{selectedTx.title} <br/><span className="text-[9px] font-normal text-gray-500">{selectedTx.terms}</span></td>
                     <td className="py-3 text-right font-mono">${selectedTx.amount.toLocaleString()}</td>
                   </tr>
                 </tbody>
               </table>

               <div className="flex justify-end border-t-2 border-gray-800 pt-4">
                 <div className="w-1/2 space-y-2 text-xs font-mono">
                   <div className="flex justify-between text-gray-600">
                     <span>Subtotal:</span>
                     <span>${selectedTx.amount.toLocaleString()}</span>
                   </div>
                   <div className="flex justify-between text-gray-600">
                     <span>Tax ({taxRate}%):</span>
                     <span>${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                   </div>
                   <div className="flex justify-between font-bold text-gray-900 text-sm pt-2 border-t border-gray-300">
                     <span>Grand Total ({selectedTx.currency}):</span>
                     <span>${totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                   </div>
                 </div>
               </div>

               <div className="mt-8 pt-4 border-t border-gray-200 text-center text-[9px] text-gray-500 font-sans">
                 This is a computer generated invoice powered by Breccia Cross-Border Escrow protocol. <br/>
                 Transaction Date: {selectedTx.updatedAt} | Status: {selectedTx.status.toUpperCase()}
               </div>
            </div>
            
            <div className="flex gap-3 justify-end pt-2">
               <button onClick={() => window.print()} className="px-4 py-2 border border-neutral-700 text-neutral-300 text-[10px] font-mono tracking-widest font-bold rounded flex items-center gap-2 hover:bg-neutral-800 transition-colors">
                  <Printer className="w-3.5 h-3.5" />
                  PRINT
               </button>
               <button onClick={handleDownload} className="px-4 py-2 bg-gold-gradient text-black text-[10px] font-mono tracking-widest font-bold rounded flex items-center gap-2 hover:opacity-90 transition-opacity transition-shadow shadow-md shadow-gold-glow cursor-pointer">
                  <Download className="w-3.5 h-3.5" />
                  DOWNLOAD PDF
               </button>
            </div>
          </div>
        ) : (
          <div className="py-6 text-center text-zinc-600 text-xs font-mono border border-neutral-850/50 rounded-lg bg-neutral-900/20">
            Select a cleared or funded transaction to preview its corporate invoice.
          </div>
        )}
      </div>
    </div>
  );
}
