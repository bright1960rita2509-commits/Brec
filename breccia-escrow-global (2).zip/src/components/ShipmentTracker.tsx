import React, { useState } from 'react';
import { Truck, MapPin, PackageCheck, Anchor, CheckCircle, PackageSearch } from 'lucide-react';
import { EscrowTransaction } from '../types';

interface ShipmentTrackerProps {
  transactions: EscrowTransaction[];
  onUpdateTracking: (txId: string, trackingNumber: string, carrier: string) => void;
}

export default function ShipmentTracker({ transactions, onUpdateTracking }: ShipmentTrackerProps) {
  const [selectedTxId, setSelectedTxId] = useState<string>('');
  const [trackingInput, setTrackingInput] = useState<string>('');
  const [carrierInput, setCarrierInput] = useState<string>('');

  const activeTx = transactions.find(t => t.id === selectedTxId);

  // Status mapping for progress bar
  const statusSteps = ['unfunded', 'funded', 'dispatched', 'delivered', 'completed'];
  
  const getStepStatus = (step: string, currentStatus: string) => {
    const currentIndex = statusSteps.indexOf(currentStatus === 'disputed' ? 'dispatched' : currentStatus);
    const stepIndex = statusSteps.indexOf(step);
    
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'pending';
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTx && trackingInput) {
      onUpdateTracking(activeTx.id, trackingInput, carrierInput || 'Unknown Carrier');
      setTrackingInput('');
      setCarrierInput('');
    }
  };

  return (
    <div className="glass-panel p-5 rounded-2xl border border-gold-400/10 text-left space-y-4" id="shipment-tracker-widget">
      <div className="border-b border-neutral-900 pb-3">
        <span className="text-[9px] font-mono tracking-widest text-gold-accent font-bold uppercase block">Logistics</span>
        <h4 className="font-display font-medium text-stone-200 text-sm mt-0.5 uppercase flex items-center gap-2">
          <Truck className="w-4 h-4" />
          Shipment Tracker
        </h4>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-mono text-neutral-400 uppercase font-semibold mb-1">Select Active Trade</label>
          <select
            value={selectedTxId}
            onChange={(e) => setSelectedTxId(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-850 p-2 text-xs rounded text-white focus:outline-none focus:border-gold-accent"
          >
            <option value="">-- Choose Transaction --</option>
            {transactions.filter(t => t.status !== 'cancelled').map(tx => (
              <option key={tx.id} value={tx.id}>{tx.id} - {tx.title}</option>
            ))}
          </select>
        </div>

        {activeTx ? (
          <div className="space-y-6 pt-2">
            {/* Enter tracking details if none exists or update existing */}
            <form onSubmit={handleUpdate} className="bg-neutral-900/50 p-3 rounded-lg border border-neutral-850 space-y-3">
              <h5 className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest mb-2 flex items-center gap-1.5"><PackageSearch className="w-3.5 h-3.5" /> Track Cargo</h5>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <input
                    type="text"
                    value={carrierInput}
                    onChange={(e) => setCarrierInput(e.target.value)}
                    placeholder={activeTx.shippingCarrier || "Enter Carrier (e.g. Maersk)"}
                    className="w-full bg-neutral-950 border border-neutral-800 text-xs px-2.5 py-1.5 rounded text-white focus:outline-none focus:border-gold-500/50"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    value={trackingInput}
                    onChange={(e) => setTrackingInput(e.target.value)}
                    placeholder={activeTx.shippingTrackingNumber || "Tracking Number"}
                    className="w-full bg-neutral-950 border border-neutral-800 text-xs px-2.5 py-1.5 rounded text-white focus:outline-none focus:border-gold-500/50"
                    required
                  />
                </div>
              </div>
              <button type="submit" className="w-full py-1.5 bg-neutral-800 hover:bg-neutral-700 text-zinc-300 text-[10px] font-mono uppercase font-bold rounded transition-colors">
                Update Tracking parameters
              </button>
            </form>

            <div className="space-y-4">
               {/* Carrier details */}
              {(activeTx.shippingTrackingNumber || activeTx.shippingTrackingUrl) && (
                <div className="flex justify-between items-center text-xs font-mono bg-neutral-950 p-2.5 rounded border border-neutral-850">
                   <div className="flex items-center gap-2">
                      <Anchor className="w-4 h-4 text-gold-accent" />
                      <span className="text-zinc-300">{activeTx.shippingCarrier || 'Sea Carrier'}</span>
                   </div>
                   <span className="text-gold-accent font-bold tracking-wider">{activeTx.shippingTrackingNumber || activeTx.shippingTrackingUrl}</span>
                </div>
              )}

              {/* Progress Bar */}
              <div className="relative pt-2">
                <div className="absolute top-4 left-0 w-full h-0.5 bg-neutral-800" />
                <div className="relative flex justify-between items-center z-10">
                  {statusSteps.map((step, idx) => {
                    const status = getStepStatus(step, activeTx.status);
                    return (
                      <div key={idx} className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full mb-1 border-2 flex items-center justify-center
                          ${status === 'completed' ? 'bg-emerald-400 border-emerald-400' : 
                            status === 'current' ? 'bg-gold-accent border-gold-accent shadow shadow-gold-glow' : 
                            'bg-neutral-950 border-neutral-700'}
                        `}>
                          {status === 'completed' && <CheckCircle className="w-2 h-2 text-black" />}
                        </div>
                        <span className={`text-[8px] font-mono uppercase tracking-tighter
                          ${status === 'completed' ? 'text-emerald-400' : status === 'current' ? 'text-gold-accent font-bold' : 'text-neutral-600'}
                        `}>
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

          </div>
        ) : (
          <div className="py-6 text-center text-zinc-600 text-xs font-mono border border-neutral-850/50 rounded-lg bg-neutral-900/20">
            Select an active transaction to open shipment tracker.
          </div>
        )}
      </div>
    </div>
  );
}
