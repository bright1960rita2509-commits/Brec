/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Star, PhoneCall, Mail, MessageSquare, ShieldAlert, CheckCircle } from 'lucide-react';

export default function AboutContactFAQ() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactSuccess, setContactSuccess] = useState('');

  const testimonials = [
    {
      name: "Kwame Boateng",
      role: "Founder, West-Africa Cocoa Farms Co-op",
      text: "Breccia completely eliminated the 30-day payment lag from European wholesale buyers. Our cargo is loaded in Tema, SGS uploaded, and our money is released to clear our harvest loans safely.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces"
    },
    {
      name: "Sophia van der Meer",
      role: "Import Director, Dutch Confectionery GMBH",
      text: "Sourcing premium agricultural commodities from West Africa used to carry immense transactional risks. Breccia's smart physical moisture milestones and SGS escrow integration give us total capital security.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=faces"
    }
  ];

  const faqs = [
    {
      q: "How does Breccia secure physical trade deals?",
      a: "Breccia holds the buyer's payment in a legal escrow custody ledger. We do not release these funds to the exporter until physical delivery conditions (such as maritime B2B cargo load manifests or SGS inspection sheets) are uploaded and cleared."
    },
    {
      q: "Which payment networks are integrated?",
      a: "Breccia integrates international bank wire networks (SWIFT/SEPA), domestic African clearing houses (including NIBSS, Ghana Interbank Payment System, and Mobile Money networks), premium ledger assets (USDT, BTC, ETH), and digital platforms including Rise, Paystack, Flutterwave, and Binance Pay for instantaneous low-fee clearance."
    },
    {
      q: "How does the dispute resolution protocol work?",
      a: "If either party flags an issue—like delays at dock, or moisture targets violating standards—the funds are locked. A certified Breccia Dispute Resolution Officer intervenes, audits SGS inspection certificates or Bills of Lading, and adjudicates refunds accordingly."
    },
    {
      q: "What is the fee structure for B2B exporters?",
      a: "Our core escrow protection is a tier-based flat fee ranging from 0.4% to 1.5% of total transaction balance, depending on volume. Verified supplier badges and directory listings are completely transparent with no hidden cost."
    }
  ];

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess("Message dispatched safely! An Executive Account Director will reach out at your corporate email in less than 2 hours.");
    setTimeout(() => setContactSuccess(''), 4000);
  };

  return (
    <div className="space-y-16" id="about-contact-faq-root">
      
      {/* Why choose us + Testimonials */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center" id="value-proposition- testimonials">
        
        {/* Left (7 columns) - Why choose us */}
        <div className="lg:col-span-7 text-left space-y-6">
          <span className="text-[10px] font-mono tracking-[0.2em] text-gold-accent font-bold uppercase">Corporate Trust Shield</span>
          <h3 className="font-display font-medium text-2xl md:text-3xl text-gold-gradient uppercase tracking-wide">
            Why Capital Directors Choose Breccia
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1">
              <span className="font-display font-bold text-sm text-stone-200 block">✓ Secure Escrow Core</span>
              <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                Funds are held in high-grade custody vaults backed by bank partners and smart ledger safeguards.
              </p>
            </div>
            <div className="space-y-1">
              <span className="font-display font-bold text-sm text-stone-200 block">✓ Exporter Auditing KYC</span>
              <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                Exporters must submit proof of storage registries and undergo compliance checking before launching trade listings.
              </p>
            </div>
            <div className="space-y-1">
              <span className="font-display font-bold text-sm text-stone-200 block">✓ SGS Verification Sheets</span>
              <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                Release terms are mapped to third-party inspections, verifying grain grade, cocoa moisture, and log weight standards.
              </p>
            </div>
            <div className="space-y-1">
              <span className="font-display font-bold text-sm text-stone-200 block">✓ Interbank Multi-Currency Routing</span>
              <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                Clear USD, EUR, NGN, GHS, and stablecoins with real-time conversion rates and zero regulatory delays.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-gradient-to-r from-neutral-900 to-neutral-950 border border-gold-400/10 flex items-center gap-4">
            <ShieldAlert className="w-10 h-10 text-gold-accent flex-shrink-0" />
            <div>
              <span className="font-display font-bold text-xs text-stone-200 block">Your Security is Our Priority</span>
              <p className="text-[11px] text-zinc-500 font-sans mt-0.5">
                Breccia incorporates automated transaction scoring, AML sanction matching list lookups, and dispute resolution guarantees on every order.
              </p>
            </div>
          </div>
        </div>

        {/* Right (5 columns) - Testimonials */}
        <div className="lg:col-span-5 space-y-5">
          <div className="border-b border-neutral-900 pb-3 text-left">
            <span className="text-[10px] font-mono text-gold-accent uppercase font-bold tracking-widest block">Exporter Testimonials</span>
            <h4 className="font-display font-extrabold text-[#fff] text-lg uppercase mt-0.5">Protected Worldwide</h4>
          </div>

          <div className="space-y-4">
            {testimonials.map((test, i) => (
              <div key={i} className="glass-panel p-5 rounded-2xl border border-gold-400/5 text-left space-y-3">
                <div className="flex gap-1.5">
                  {[...Array(test.rating)].map((_, idx) => (
                    <Star key={idx} className="w-4.5 h-4.5 fill-gold-accent text-gold-accent" />
                  ))}
                </div>
                <p className="text-zinc-300 text-xs font-sans italic leading-relaxed">
                  &quot;{test.text}&quot;
                </p>
                <div className="flex items-center gap-3 pt-2 border-t border-neutral-900">
                  <img
                    referrerPolicy="no-referrer"
                    src={test.image}
                    alt={test.name}
                    className="w-8 h-8 rounded-full border border-gold-400/20 object-cover"
                  />
                  <div>
                    <span className="font-display font-bold text-stone-200 text-xs block">{test.name}</span>
                    <span className="text-[9px] font-mono text-neutral-500 uppercase block">{test.role}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* FAQ & Contact Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12" id="faq-contact-grids">
        
        {/* Left FAQ Accordion (7 columns) */}
        <div className="lg:col-span-7 text-left space-y-6">
          <div>
            <span className="text-[10px] font-mono tracking-[0.25em] text-gold-accent font-bold uppercase">Frequently Asked Questions</span>
            <h3 className="font-display font-medium text-2xl md:text-3xl text-gold-gradient mt-1 uppercase">
              Regulatory & Trade Support
            </h3>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div key={idx} className="glass-panel rounded-xl border border-gold-400/5 transition-all">
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full flex justify-between items-center p-4 text-left font-display font-bold text-xs md:text-sm text-stone-200 selection:bg-none cursor-pointer hover:neon-glow"
                  >
                    <span className="pr-4">{faq.q}</span>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-gold-accent" /> : <ChevronDown className="w-4 h-4 text-gold-accent" />}
                  </button>

                  {isOpen && (
                    <div className="p-4 pt-1 border-t border-neutral-900/60 text-[11px] md:text-xs leading-relaxed text-zinc-400 font-sans selection:bg-none">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Contact section (5 columns) */}
        <div className="lg:col-span-12 xl:col-span-5 text-left">
          <div className="glass-panel p-6 rounded-3xl border border-gold-400/10 space-y-4">
            <div>
              <h4 className="font-display font-extrabold text-stone-200 text-base uppercase">Connect with Exporter Desks</h4>
              <p className="text-[10px] font-mono text-neutral-500 mt-1">Ready to clear a custom agricultural vessel? Request specialized clearing lines.</p>
            </div>

            {contactSuccess && (
              <div className="p-3 bg-gold-400/5 border border-gold-400/25 rounded-md text-gold-accent text-xs font-mono text-center">
                {contactSuccess}
              </div>
            )}

            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-mono text-stone-500 uppercase font-semibold mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jean Dupont"
                    className="w-full bg-neutral-950 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-mono text-stone-500 uppercase font-semibold mb-1">Corporate Email</label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. Sourcing@agricorp.com"
                    className="w-full bg-neutral-950 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-mono text-stone-500 uppercase font-semibold mb-1">Target Exporter Category</label>
                <select className="w-full bg-neutral-950 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none text-zinc-400">
                  <option>Agriculture (Cocoa, Shea Butter, Cashew)</option>
                  <option>Manufacturing & Textile Bulk Sourcing</option>
                  <option>Mineral Resources Sourcing</option>
                  <option>Wholesale B2B Consumer Goods</option>
                </select>
              </div>

              <div>
                <label className="block text-[9px] font-mono text-stone-500 uppercase font-semibold mb-1">Estimated Yearly Trade Volume (USD)</label>
                <select className="w-full bg-neutral-950 border border-neutral-800 text-xs px-3 py-2 rounded focus:outline-none text-zinc-400">
                  <option>$50k - $250k USD</option>
                  <option>$250k - $1M USD</option>
                  <option>Over $1M USD yearly</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded bg-gold-gradient text-black font-semibold text-xs tracking-wider font-mono hover:opacity-95 text-center cursor-pointer"
              >
                REQUEST EXPORT INTRO &rarr;
              </button>
            </form>

            <div className="pt-3 border-t border-neutral-900 grid grid-cols-3 gap-2 text-center text-[10px] text-zinc-500 font-mono">
              <div>
                <PhoneCall className="w-4 h-4 text-gold-accent mx-auto mb-1" />
                <span>+234 1 800-BRECCIA</span>
              </div>
              <div>
                <Mail className="w-4 h-4 text-gold-accent mx-auto mb-1" />
                <span>desk@breccia.com</span>
              </div>
              <div>
                <MessageSquare className="w-4 h-4 text-gold-accent mx-auto mb-1" />
                <span>24/7 Portal Chat</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
