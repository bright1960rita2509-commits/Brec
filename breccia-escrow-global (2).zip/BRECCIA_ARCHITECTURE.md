# Breccia - Enterprise Backend Architecture & Specification

**Mission**: Secure Trade. Trusted Payments. Global Opportunities.

This document outlines the complete production-ready backend architecture for Breccia, designed for scalability across Africa and international markets using Node.js, NestJS, Prisma, PostgreSQL, Redis, Elasticsearch, RabbitMQ, and AWS.

---

## 1. High-Level System Architecture
Breccia operates on an event-driven microservices architecture hosted on AWS (EKS). 
- **API Gateway**: Route requests, handle rate limiting, SSL termination (AWS API Gateway / NGINX Ingress).
- **Compute**: NestJS Microservices running in Docker containers orchestrated by Kubernetes.
- **Database Layer**: AWS RDS PostgreSQL (Multi-AZ), Redis ElastiCache for caching/session, Elasticsearch for marketplace search.
- **Message Broker**: Amazon MQ (RabbitMQ) for asynchronous async communication (notifications, KYC processing, email).
- **Storage**: AWS S3 for document storage (KYC, Bills of Lading, etc.) with CloudFront CDN.

---

## 2. Microservice Architecture
The platform is split into bounded contexts:
1. **Auth Service**: JWT issuance, 2FA, session tracking, password resets.
2. **User & Identity Service**: Profiles, KYC/AML workflows, document processing.
3. **Escrow & Ledger Service**: The core transactional engine. Manages milestones, state machines, and fund allocation.
4. **Payment & Crypto Service**: Handles fiat gateways (Stripe, Flutterwave, Paystack) and crypto deposit monitoring via specialized nodes.
5. **Marketplace & Trade Service**: Catalogs, supplier search (Elasticsearch), RFQs.
6. **Communication Service**: Real-time messaging, notifications, push.
7. **Dispute & Admin Service**: Case management, refunds, audit logs.

---

## 3. Service Responsibilities
- **Auth Service**: Validates credentials, issues Refresh/Access tokens, blocks brute-force login attempts using Redis rate-limiting.
- **Identity Service**: Integrates with 3rd-party KYC (e.g., SmileID or Onfido). Manages business verification statuses.
- **Escrow Service**: Strictly enforces state transitions (Pending -> Funded -> Dispatched -> Completed). Prevents unauthorized fund releases.
- **Payment Service**: Listens to blockchain mempools for USDT/BTC deposits matching generated wallet addresses, confirms block confirmations.
- **Communication**: WebSockets (Socket.io) for live chat between Importer/Exporter and Arbitrators.

---

## 4. PostgreSQL Database Schema (ERD Overview)
- **Users**: id, email, password_hash, role, 2fa_enabled, status.
- **Profiles**: user_id, company_name, country, business_reg_number, kyc_status.
- **Escrows**: id, buyer_id, seller_id, amount, currency, status, created_at.
- **Milestones**: id, escrow_id, description, is_met, evidence_url.
- **Wallets**: id, user_id, currency, address, balance.
- **Transactions**: id, wallet_id, type (credit/debit), amount, status, tx_hash.
- **Disputes**: id, escrow_id, raised_by, reason, status, resolution, arbitrator_id.
- **Messages**: id, sender_id, receiver_id, escrow_id, content, read_at.

---

## 5. Prisma Models (Excerpt)

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum Role {
  BUYER
  SELLER
  SUPPLIER
  IMPORTER
  ADMIN
  COMPLIANCE
  ARBITRATOR
}

enum EscrowStatus {
  DRAFT
  PENDING_FUNDING
  FUNDED
  DISPATCHED
  INSPECTION
  COMPLETED
  DISPUTED
  REFUNDED
}

model User {
  id            String    @id @default(uuid())
  email         String    @unique
  passwordHash  String
  role          Role      @default(BUYER)
  kycStatus     String    @default("PENDING")
  createdAt     DateTime  @default(now())
  escrowsBought Escrow[]  @relation("BuyerEscrows")
  escrowsSold   Escrow[]  @relation("SellerEscrows")
}

model Escrow {
  id          String       @id @default(uuid())
  buyerId     String
  sellerId    String
  amount      Decimal
  currency    String
  status      EscrowStatus @default(DRAFT)
  terms       String
  buyer       User         @relation("BuyerEscrows", fields: [buyerId], references: [id])
  seller      User         @relation("SellerEscrows", fields: [sellerId], references: [id])
  milestones  Milestone[]
  createdAt   DateTime     @default(now())
}
```

---

## 6. API Specification (REST & WebSockets)
- `POST /api/v1/auth/register` - Create account.
- `POST /api/v1/users/kyc/upload` - Upload business registration (multipart/form-data).
- `POST /api/v1/escrow/create` - Draft new escrow deal.
- `GET /api/v1/escrow/:id` - Fetch escrow details.
- `POST /api/v1/payments/crypto/generate-address` - Get USDT funding address.
- `PATCH /api/v1/escrow/:id/dispute` - Raise dispute.
- `GET /api/v1/marketplace/search?q=cocoa&country=GH` - ElasticSearch query.
- WebSocket `/chat` - Connect for dispute/trade messaging.

---

## 7. Escrow Workflow Diagrams
1. Buyer creates Escrow draft -> **DRAFT**
2. Seller accepts terms -> **PENDING_FUNDING**
3. Buyer transfers funds (Bank or Crypto) -> **FUNDED**
4. Seller uploads Bill of Lading / SGS Report -> **DISPATCHED**
5. Buyer inspects goods at destination port -> **INSPECTION**
6. Buyer approves release -> **COMPLETED** (Funds routed to Seller).

---

## 8. Payment Workflow Diagrams
**Crypto Funding**:
1. User requests to fund Escrow BRC-1002.
2. Payment service generates unique deposit address via RPC node.
3. System monitors memory pool.
4. Transaction hits 3 block confirmations -> Webhook fired to Escrow Service.
5. Escrow transitions to **FUNDED**.

---

## 9. Marketplace Workflow Diagrams
1. Supplier undergoes KYC/AML. Once approved, they populate catalog.
2. Elasticsearch indexes Supplier capabilities and products.
3. Importer searches "Grade A Shea Butter".
4. Results ranked by proximity, rating, and successful escrow count.
5. Importer clicks "Initiate Trade Request (RFQ)".

---

## 10. Security Architecture
- **JWT**: Short-lived (15 min) access tokens, HttpOnly secure cookie refresh tokens.
- **RBAC & ABAC**: NestJS Guards evaluate roles (User vs Admin) and attributes (Is the user the owner of this Escrow ID?).
- **Encryption**: AES-256 for PII at rest (RDS KMS), TLS 1.3 in transit.
- **API Defense**: Helmet.js for headers, express-rate-limit to prevent scraping/brute-force, class-validator to prevent NoSQL/SQL injections.

---

## 11. Folder Structure (NestJS Monorepo)
```
apps/
  api-gateway/
  auth-service/
  escrow-service/
  payment-service/
libs/
  database/ (Prisma schema)
  shared/ (DTOs, Enums, Guards)
  messaging/ (RabbitMQ interfaces)
```

---

## 12. NestJS Module Structure
```typescript
@Module({
  imports: [
    ConfigModule.forRoot(),
    DatabaseModule,
    RabbitMQModule,
    JwtModule.register({ secret: process.env.JWT_SECRET })
  ],
  controllers: [EscrowController],
  providers: [EscrowService, StateMachineProvider, S3UploadService],
})
export class EscrowModule {}
```

---

## 13. Redis Design
- **Session Cache**: Token blacklisting for logged-out users.
- **Idempotency**: Locking keys to prevent double-spending in the Escrow ledger (`lock:escrow_release:BRC_991`).
- **Rate Limiting**: IP-based request tracking.

---

## 14. RabbitMQ Design
- **Exchanges**: `trade_events` (Topic), `notification_events` (Fanout).
- **Queues**: `kyc_processing_queue`, `email_dispatch_queue`, `blockchain_confirm_queue`.
- **Flow**: Payment service publishes `escrow.funded` -> Notification service sends email; Escrow service updates DB.

---

## 15. AWS Infrastructure Design
- **VPC**: 3 Public Subnets (ALB, NAT Gateways), 3 Private Subnets (EKS Nodes, ECS), 3 Isolated Subnets (RDS, Redis).
- **EKS**: Amazon Elastic Kubernetes Service for running microservices.
- **RDS & ElastiCache**: Managed database layers.
- **WAF**: AWS Web Application Firewall for DDoS mitigation.

---

## 16. Docker Files
```dockerfile
# /apps/escrow-service/Dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npx prisma generate
RUN npm run build escrow-service

FROM node:18-alpine
WORKDIR /app
COPY --from=builder /app/dist/apps/escrow-service ./dist
COPY --from=builder /app/node_modules ./node_modules
ENV NODE_ENV=production
CMD ["node", "dist/main.js"]
```

---

## 17. Kubernetes Configuration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: escrow-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: escrow
  template:
    metadata:
      labels:
        app: escrow
    spec:
      containers:
      - name: escrow
        image: breccia/escrow-service:latest
        ports:
        - containerPort: 3000
        envFrom:
        - secretRef:
            name: breccia-secrets
```

---

## 18. CI/CD Pipeline (GitHub Actions)
- **On PR**: Linting (ESLint), Unit Tests (Jest), CodeQL Security Scan, Prisma formatting check.
- **On Merge to Main**: 
  1. Build Docker images.
  2. Push to AWS ECR.
  3. Run Prisma `db push` or migrations in staging.
  4. Trigger ArgoCD to update EKS manifests.

---

## 19. Monitoring Setup
- **Prometheus**: Scrapes metrics from `/metrics` on all NestJS pods (using `@willsoto/nestjs-prometheus`).
- **Grafana**: Dashboards monitoring API latency, Escrow volumes, RabbitMQ queue depths.
- **Sentry**: Captures unhandled backend exceptions in real-time.
- **ELK Stack/Datadog**: Aggregates container logs for distributed tracing.

---

## 20. Production Deployment Plan
1. **Phase 1 (Infrastructure Prep)**: Provision VPC, RDS endpoints, Redis, and EKS clusters via Terraform.
2. **Phase 2 (Configuration)**: Seed SecretsManager with Stripe keys, RPC Node credentials, JWT signatures.
3. **Phase 3 (Database Deployment)**: Apply Prisma migrations to provision all SQL tables.
4. **Phase 4 (Microservice Rollout)**: Deploy Auth and Identity services. Run E2E sanity checks. Deploy Escrow and Payment services.
5. **Phase 5 (DNS & DNS)**: Point Route53 to ingress ALB. Terminate TLS via ACM. Go Live.
