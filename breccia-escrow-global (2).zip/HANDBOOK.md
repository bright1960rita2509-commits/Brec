# Breccia Escrow Platform - User & Admin Handbook

## 1. Introduction
Breccia is a secure, multi-currency escrow platform designed to facilitate trust in complex transactions. This handbook outlines the key features implemented to streamline trade for users and provide robust control for platform administrators.

---

## 2. User Features

### 2.1 Digital Signature Agreement
To ensure mutual consent before funding, all parties must sign the transaction agreement.
- **Function**: Users sign (Digitally Sign Agreement) to commit to the terms.
- **Workflow**: Funds cannot be secured until all parties have signed.
- **Indicator**: The dashboard reflects the signing status for both buyer and seller.

### 2.2 Dispute Initiation
If a transaction faces issues (e.g., quality or misrepresentation), users can raise a formal dispute.
- **Function**: Allows users to attach a description of the issue.
- **Admin Visibility**: Disputes are automatically routed to the Admin for arbitration.

### 2.3 Specialized Workflow Templates
Breccia supports specialized workflows for different asset classes.
- **Domain/Digital Asset Transfer**: Features streamlined ownership verification specifically for domain names (requires registrar verification).

### 2.4 Multi-Currency & FX Support
Breccia supports global trade by handling multiple fiat and digital currencies.
- **Supported**: USD, EUR, GBP, JPY, NGN, GHS, ZAR, BTC, ETH.
- **Function**: Automatically handles currency conversions via our integrated Currency Service.

### 2.5 External Marketplace API
Allows users to view listings directly from integrated third-party platforms for easier trade initiation.

---

## 3. Admin Features & Guidelines (AdminPanel)

The AdminPanel is the central hub for managing disputes and ensuring trade integrity.

### 3.1 Dispute Management Lifecycle
Admin can manage disputes through the following stages:

| Stage | Admin Action | Description |
| :--- | :--- | :--- |
| **Evidence Gathering** | Request Evidence | Sends a notification to parties to provide proof (e.g., files, receipts, screenshots). |
| **Arbitrator Assessment** | To Assessment | Moves the case to the final review stage for an arbitration officer's judgment. |
| **Resolution** | Resolve Dispute | Finalize the case by refunding the importer or paying the exporter. |

### 3.2 Understanding Dispute Statuses
- **Evidence Gathering**: Active investigation; waiting on documentation from parties.
- **Arbitrator Assessment**: Under final review by an internal dispute officer.
- **Under Review/Open**: Initial intake status.

### 4. Admin Checklist for Dispute Resolution
1. Always verify the `raisedBy` and `reason` metadata on a dispute.
2. Use **Request Evidence** first to get clear facts from both parties.
3. Once all evidence is compiled, use **To Assessment** to trigger the final arbitration flow.
4. Finalize resolution based on assessment notes.
