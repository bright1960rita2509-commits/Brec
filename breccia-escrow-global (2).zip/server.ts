import { PrismaClient } from '@prisma/client';
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { walletService } from "./src/services/walletService";
import { ledgerService } from "./src/services/ledgerService";
import { paymentService } from "./src/services/paymentService";
import { escrowService } from "./src/services/escrowService";
import { kycService } from "./src/services/kycService";
import { logisticsService } from "./src/services/logisticsService";
import { disputeService } from "./src/services/disputeService";
import { handlePaymentWebhook } from "./src/api/webhooks";

const prisma = new PrismaClient();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini client lazily to avoid crashing on startup if key is missing helper
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // Return null or throw clear operational warning without crashing whole express server startup
      return null;
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  };

  // API Route - Get Smart Trade Consultations / Contract Drafting
  app.post("/api/gemini/advisor", async (req, res) => {
    try {
      const { prompt, type } = req.body;
      const ai = getGeminiClient();
      
      if (!ai) {
        return res.status(200).json({
          status: "success",
          text: `### Breccia Local Fallback Model\n\nBreccia is operating in secure offline standby mode (GEMINI_API_KEY is not configured in the Secrets panel yet).\n\n#### General Trade Advisory Guideline for: "${prompt.slice(0, 50)}..."\n1. **Always Require Escrow Protection**: When trading across West/East Africa (e.g. Nigeria, Ghana, Kenya), never send direct wire transfers before independent inspection.\n2. **Cargo Verification**: Use trusted inspection agencies like SGS or Bureau Veritas to verify weight and quality certificate standards before releasing Breccia escrow funds.\n3. **Trade Documents**: Ensure your Bill of Lading, Certificate of Origin, and Phytosanitary Certificate (for agriculture) are uploaded directly into your Breccia account to ensure AML/KYC safety.`
        });
      }

      let systemInstruction = "You are Breccia's Executive AI Trade Advisor. You assist buyers, suppliers, legal analysts, and cross-border importers. Be highly precise, professional, professional tone, avoiding conversational fluff. Format your response with beautiful Markdown headings, lists, and bold callouts.";
      
      if (type === "contract") {
        systemInstruction = "You are Breccia's Automated Legal Escrow Officer. Draft a formal, elite Standard Commercial Escrow Agreement. Include Title, Seller Obligations, Buyer Obligations, Specific Inspection Conditions, Disbursal Milestones, and Dispute Arbitration clauses based on the user's terms in clear professional language.";
      } else if (type === "sourcing") {
        systemInstruction = "You are Breccia's Expert Exporter Matching Agent. Based on the user's sourcing query, recommend realistic African sourcing categories (e.g., Nigerian Cocoa beans, Premium Shea Butter, Ghana Gold/Cocoa, Ethiopian Coffee, Egyptian Textiles). Specify typical shipping ports (Lagos, Tema, Mombasa), regulatory inspection needs, and recommended Breccia secure payments terms.";
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({
        status: "success",
        text: response.text
      });

    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({
        status: "error",
        message: error.message || "Failed to generate AI response"
      });
    }
  });

  // Mock server status / health check APIs
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // Payment API
  app.post("/api/payment/initiate", async (req, res) => {
    const { provider, amount, email, reference, userId } = req.body;
    let result;
    if (provider === 'paystack') {
       result = await paymentService.initiatePaystack(amount, email, reference);
    } else if (provider === 'flutterwave') {
       result = await paymentService.initiateFlutterwave(amount, email, reference);
    }
    res.json(result);
  });
  
  app.post("/api/webhooks/:provider", handlePaymentWebhook);

  // Wallet API
  app.post("/api/wallet/credit", async (req, res) => {
    try {
      const { userId, currency, amount, reference } = req.body;
      const wallet = await walletService.getWallet(userId, currency);
      if (!wallet) return res.status(404).json({ error: "Wallet not found" });

      await walletService.updateBalance(userId, currency, amount);
      await ledgerService.createEntry(wallet.id, amount, 'CREDIT', reference);
      
      res.json({ status: "success" });
    } catch (error) {
      res.status(500).json({ error: "Failed to credit wallet" });
    }
  });

  // Escrow API
  app.post("/api/escrow/create", async (req, res) => {
    try {
      const { buyerId, sellerId, amount, currency } = req.body;
      const tx = await escrowService.createTransaction(buyerId, sellerId, amount, currency);
      res.json(tx);
    } catch (error) {
      res.status(500).json({ error: "Failed to create escrow transaction" });
    }
  });

  app.get("/api/escrow", async (req, res) => {
    try {
      const transactions = await prisma.escrowTransaction.findMany();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch escrow transactions" });
    }
  });

  // KYC API
  app.post("/api/kyc/submit", async (req, res) => {
    try {
      const { userId, type, status, documentUrl } = req.body;
      const kyc = await kycService.updateVerification(userId, { type, status, documentUrl });
      res.json(kyc);
    } catch (error) {
      res.status(500).json({ error: "Failed to update KYC" });
    }
  });

  app.get("/api/kyc/status/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const kyc = await kycService.getStatus(userId);
      res.json(kyc);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch KYC status" });
    }
  });

  // Logistics API
  app.post("/api/logistics/shipment", async (req, res) => {
    try {
      const { orderId, trackingNumber, carrier } = req.body;
      const shipment = await logisticsService.createShipment(orderId, trackingNumber, carrier);
      res.json(shipment);
    } catch (error) {
      res.status(500).json({ error: "Failed to create shipment" });
    }
  });

  // Dispute API
  app.post("/api/disputes", async (req, res) => {
    try {
      const { complainantId, respondentId, evidence } = req.body;
      const dispute = await disputeService.createDispute(complainantId, respondentId, evidence);
      res.json(dispute);
    } catch (error) {
      res.status(500).json({ error: "Failed to create dispute" });
    }
  });

  // Serve static assets in production, or mount Vite middleware in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Breccia Full-Stack Server running on port ${PORT}`);
  });
}

startServer();
